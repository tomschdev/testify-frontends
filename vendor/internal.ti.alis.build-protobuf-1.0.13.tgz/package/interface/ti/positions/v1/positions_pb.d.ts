import * as jspb from 'google-protobuf'

import * as google_protobuf_field_mask_pb from 'google-protobuf/google/protobuf/field_mask_pb'; // proto import: "google/protobuf/field_mask.proto"
import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb'; // proto import: "google/protobuf/timestamp.proto"


export class Position extends jspb.Message {
  getName(): string;
  setName(value: string): Position;

  getTitle(): string;
  setTitle(value: string): Position;

  getDescription(): string;
  setDescription(value: string): Position;

  getEffectiveTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setEffectiveTime(value?: google_protobuf_timestamp_pb.Timestamp): Position;
  hasEffectiveTime(): boolean;
  clearEffectiveTime(): Position;

  getClosingTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setClosingTime(value?: google_protobuf_timestamp_pb.Timestamp): Position;
  hasClosingTime(): boolean;
  clearClosingTime(): Position;

  getState(): PositionState;
  setState(value: PositionState): Position;

  getRequirements(): Requirements | undefined;
  setRequirements(value?: Requirements): Position;
  hasRequirements(): boolean;
  clearRequirements(): Position;

  getCreateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreateTime(value?: google_protobuf_timestamp_pb.Timestamp): Position;
  hasCreateTime(): boolean;
  clearCreateTime(): Position;

  getUpdateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setUpdateTime(value?: google_protobuf_timestamp_pb.Timestamp): Position;
  hasUpdateTime(): boolean;
  clearUpdateTime(): Position;

  getEtag(): string;
  setEtag(value: string): Position;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Position.AsObject;
  static toObject(includeInstance: boolean, msg: Position): Position.AsObject;
  static serializeBinaryToWriter(message: Position, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Position;
  static deserializeBinaryFromReader(message: Position, reader: jspb.BinaryReader): Position;
}

export namespace Position {
  export type AsObject = {
    name: string,
    title: string,
    description: string,
    effectiveTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    closingTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    state: PositionState,
    requirements?: Requirements.AsObject,
    createTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    updateTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    etag: string,
  }
}

export class Requirements extends jspb.Message {
  getFiltersList(): Array<Filter>;
  setFiltersList(value: Array<Filter>): Requirements;
  clearFiltersList(): Requirements;
  addFilters(value?: Filter, index?: number): Filter;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Requirements.AsObject;
  static toObject(includeInstance: boolean, msg: Requirements): Requirements.AsObject;
  static serializeBinaryToWriter(message: Requirements, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Requirements;
  static deserializeBinaryFromReader(message: Requirements, reader: jspb.BinaryReader): Requirements;
}

export namespace Requirements {
  export type AsObject = {
    filtersList: Array<Filter.AsObject>,
  }
}

export class Filter extends jspb.Message {
  getNaturalLanguageCriteria(): string;
  setNaturalLanguageCriteria(value: string): Filter;

  getActive(): boolean;
  setActive(value: boolean): Filter;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Filter.AsObject;
  static toObject(includeInstance: boolean, msg: Filter): Filter.AsObject;
  static serializeBinaryToWriter(message: Filter, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Filter;
  static deserializeBinaryFromReader(message: Filter, reader: jspb.BinaryReader): Filter;
}

export namespace Filter {
  export type AsObject = {
    naturalLanguageCriteria: string,
    active: boolean,
  }
}

export class CreatePositionRequest extends jspb.Message {
  getParent(): string;
  setParent(value: string): CreatePositionRequest;

  getPosition(): Position | undefined;
  setPosition(value?: Position): CreatePositionRequest;
  hasPosition(): boolean;
  clearPosition(): CreatePositionRequest;

  getPositionId(): string;
  setPositionId(value: string): CreatePositionRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreatePositionRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreatePositionRequest): CreatePositionRequest.AsObject;
  static serializeBinaryToWriter(message: CreatePositionRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreatePositionRequest;
  static deserializeBinaryFromReader(message: CreatePositionRequest, reader: jspb.BinaryReader): CreatePositionRequest;
}

export namespace CreatePositionRequest {
  export type AsObject = {
    parent: string,
    position?: Position.AsObject,
    positionId: string,
  }
}

export class GetPositionRequest extends jspb.Message {
  getName(): string;
  setName(value: string): GetPositionRequest;

  getView(): PositionView;
  setView(value: PositionView): GetPositionRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): GetPositionRequest;
  hasReadMask(): boolean;
  clearReadMask(): GetPositionRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetPositionRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetPositionRequest): GetPositionRequest.AsObject;
  static serializeBinaryToWriter(message: GetPositionRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetPositionRequest;
  static deserializeBinaryFromReader(message: GetPositionRequest, reader: jspb.BinaryReader): GetPositionRequest;
}

export namespace GetPositionRequest {
  export type AsObject = {
    name: string,
    view: PositionView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class UpdatePositionRequest extends jspb.Message {
  getPosition(): Position | undefined;
  setPosition(value?: Position): UpdatePositionRequest;
  hasPosition(): boolean;
  clearPosition(): UpdatePositionRequest;

  getUpdateMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setUpdateMask(value?: google_protobuf_field_mask_pb.FieldMask): UpdatePositionRequest;
  hasUpdateMask(): boolean;
  clearUpdateMask(): UpdatePositionRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdatePositionRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdatePositionRequest): UpdatePositionRequest.AsObject;
  static serializeBinaryToWriter(message: UpdatePositionRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdatePositionRequest;
  static deserializeBinaryFromReader(message: UpdatePositionRequest, reader: jspb.BinaryReader): UpdatePositionRequest;
}

export namespace UpdatePositionRequest {
  export type AsObject = {
    position?: Position.AsObject,
    updateMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class ListPositionsRequest extends jspb.Message {
  getParent(): string;
  setParent(value: string): ListPositionsRequest;

  getPageSize(): number;
  setPageSize(value: number): ListPositionsRequest;

  getPageToken(): string;
  setPageToken(value: string): ListPositionsRequest;

  getView(): PositionView;
  setView(value: PositionView): ListPositionsRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): ListPositionsRequest;
  hasReadMask(): boolean;
  clearReadMask(): ListPositionsRequest;

  getFilter(): string;
  setFilter(value: string): ListPositionsRequest;

  getOrderBy(): string;
  setOrderBy(value: string): ListPositionsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListPositionsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListPositionsRequest): ListPositionsRequest.AsObject;
  static serializeBinaryToWriter(message: ListPositionsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListPositionsRequest;
  static deserializeBinaryFromReader(message: ListPositionsRequest, reader: jspb.BinaryReader): ListPositionsRequest;
}

export namespace ListPositionsRequest {
  export type AsObject = {
    parent: string,
    pageSize: number,
    pageToken: string,
    view: PositionView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
    orderBy: string,
  }
}

export class ListPositionsResponse extends jspb.Message {
  getPositionsList(): Array<Position>;
  setPositionsList(value: Array<Position>): ListPositionsResponse;
  clearPositionsList(): ListPositionsResponse;
  addPositions(value?: Position, index?: number): Position;

  getNextPageToken(): string;
  setNextPageToken(value: string): ListPositionsResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListPositionsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListPositionsResponse): ListPositionsResponse.AsObject;
  static serializeBinaryToWriter(message: ListPositionsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListPositionsResponse;
  static deserializeBinaryFromReader(message: ListPositionsResponse, reader: jspb.BinaryReader): ListPositionsResponse;
}

export namespace ListPositionsResponse {
  export type AsObject = {
    positionsList: Array<Position.AsObject>,
    nextPageToken: string,
  }
}

export class RevokePositionRequest extends jspb.Message {
  getName(): string;
  setName(value: string): RevokePositionRequest;

  getEtag(): string;
  setEtag(value: string): RevokePositionRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RevokePositionRequest.AsObject;
  static toObject(includeInstance: boolean, msg: RevokePositionRequest): RevokePositionRequest.AsObject;
  static serializeBinaryToWriter(message: RevokePositionRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RevokePositionRequest;
  static deserializeBinaryFromReader(message: RevokePositionRequest, reader: jspb.BinaryReader): RevokePositionRequest;
}

export namespace RevokePositionRequest {
  export type AsObject = {
    name: string,
    etag: string,
  }
}

export class FulfillPositionRequest extends jspb.Message {
  getName(): string;
  setName(value: string): FulfillPositionRequest;

  getEtag(): string;
  setEtag(value: string): FulfillPositionRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FulfillPositionRequest.AsObject;
  static toObject(includeInstance: boolean, msg: FulfillPositionRequest): FulfillPositionRequest.AsObject;
  static serializeBinaryToWriter(message: FulfillPositionRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FulfillPositionRequest;
  static deserializeBinaryFromReader(message: FulfillPositionRequest, reader: jspb.BinaryReader): FulfillPositionRequest;
}

export namespace FulfillPositionRequest {
  export type AsObject = {
    name: string,
    etag: string,
  }
}

export class SearchProfilesRequest extends jspb.Message {
  getName(): string;
  setName(value: string): SearchProfilesRequest;

  getPageSize(): number;
  setPageSize(value: number): SearchProfilesRequest;

  getPageToken(): string;
  setPageToken(value: string): SearchProfilesRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SearchProfilesRequest.AsObject;
  static toObject(includeInstance: boolean, msg: SearchProfilesRequest): SearchProfilesRequest.AsObject;
  static serializeBinaryToWriter(message: SearchProfilesRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SearchProfilesRequest;
  static deserializeBinaryFromReader(message: SearchProfilesRequest, reader: jspb.BinaryReader): SearchProfilesRequest;
}

export namespace SearchProfilesRequest {
  export type AsObject = {
    name: string,
    pageSize: number,
    pageToken: string,
  }
}

export class SearchProfilesResponse extends jspb.Message {
  getProfilesList(): Array<SearchProfilesResponse.MatchedProfile>;
  setProfilesList(value: Array<SearchProfilesResponse.MatchedProfile>): SearchProfilesResponse;
  clearProfilesList(): SearchProfilesResponse;
  addProfiles(value?: SearchProfilesResponse.MatchedProfile, index?: number): SearchProfilesResponse.MatchedProfile;

  getNextPageToken(): string;
  setNextPageToken(value: string): SearchProfilesResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SearchProfilesResponse.AsObject;
  static toObject(includeInstance: boolean, msg: SearchProfilesResponse): SearchProfilesResponse.AsObject;
  static serializeBinaryToWriter(message: SearchProfilesResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SearchProfilesResponse;
  static deserializeBinaryFromReader(message: SearchProfilesResponse, reader: jspb.BinaryReader): SearchProfilesResponse;
}

export namespace SearchProfilesResponse {
  export type AsObject = {
    profilesList: Array<SearchProfilesResponse.MatchedProfile.AsObject>,
    nextPageToken: string,
  }

  export class MatchedProfile extends jspb.Message {
    getProfilePublicKey(): string;
    setProfilePublicKey(value: string): MatchedProfile;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): MatchedProfile.AsObject;
    static toObject(includeInstance: boolean, msg: MatchedProfile): MatchedProfile.AsObject;
    static serializeBinaryToWriter(message: MatchedProfile, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): MatchedProfile;
    static deserializeBinaryFromReader(message: MatchedProfile, reader: jspb.BinaryReader): MatchedProfile;
  }

  export namespace MatchedProfile {
    export type AsObject = {
      profilePublicKey: string,
    }
  }

}

export enum PositionState { 
  POSITION_STATE_UNSPECIFIED = 0,
  POSITION_STATE_OPEN = 1,
  POSITION_STATE_REVOKED = 2,
  POSITION_STATE_FULFILLED = 3,
}
export enum PositionView { 
  POSITION_VIEW_UNSPECIFIED = 0,
  POSITION_VIEW_BASIC = 1,
  POSITION_VIEW_FULL = 2,
}