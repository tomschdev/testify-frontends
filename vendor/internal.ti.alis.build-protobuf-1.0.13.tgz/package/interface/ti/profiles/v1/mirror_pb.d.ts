import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb'; // proto import: "google/protobuf/timestamp.proto"
import * as interface_ti_positions_v1_positions_pb from '../../../../interface/ti/positions/v1/positions_pb'; // proto import: "interface/ti/positions/v1/positions.proto"


export class GetHederaAccountRequest extends jspb.Message {
  getAccountId(): string;
  setAccountId(value: string): GetHederaAccountRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetHederaAccountRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetHederaAccountRequest): GetHederaAccountRequest.AsObject;
  static serializeBinaryToWriter(message: GetHederaAccountRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetHederaAccountRequest;
  static deserializeBinaryFromReader(message: GetHederaAccountRequest, reader: jspb.BinaryReader): GetHederaAccountRequest;
}

export namespace GetHederaAccountRequest {
  export type AsObject = {
    accountId: string,
  }
}

export class HederaAccount extends jspb.Message {
  getAccountId(): string;
  setAccountId(value: string): HederaAccount;

  getPublicKey(): string;
  setPublicKey(value: string): HederaAccount;

  getEvmAddress(): string;
  setEvmAddress(value: string): HederaAccount;

  getHbarBalance(): number;
  setHbarBalance(value: number): HederaAccount;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): HederaAccount.AsObject;
  static toObject(includeInstance: boolean, msg: HederaAccount): HederaAccount.AsObject;
  static serializeBinaryToWriter(message: HederaAccount, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): HederaAccount;
  static deserializeBinaryFromReader(message: HederaAccount, reader: jspb.BinaryReader): HederaAccount;
}

export namespace HederaAccount {
  export type AsObject = {
    accountId: string,
    publicKey: string,
    evmAddress: string,
    hbarBalance: number,
  }
}

export class ListTokenHoldingsRequest extends jspb.Message {
  getAccountId(): string;
  setAccountId(value: string): ListTokenHoldingsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListTokenHoldingsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListTokenHoldingsRequest): ListTokenHoldingsRequest.AsObject;
  static serializeBinaryToWriter(message: ListTokenHoldingsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListTokenHoldingsRequest;
  static deserializeBinaryFromReader(message: ListTokenHoldingsRequest, reader: jspb.BinaryReader): ListTokenHoldingsRequest;
}

export namespace ListTokenHoldingsRequest {
  export type AsObject = {
    accountId: string,
  }
}

export class ListTokenHoldingsResponse extends jspb.Message {
  getHoldingsList(): Array<TokenHolding>;
  setHoldingsList(value: Array<TokenHolding>): ListTokenHoldingsResponse;
  clearHoldingsList(): ListTokenHoldingsResponse;
  addHoldings(value?: TokenHolding, index?: number): TokenHolding;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListTokenHoldingsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListTokenHoldingsResponse): ListTokenHoldingsResponse.AsObject;
  static serializeBinaryToWriter(message: ListTokenHoldingsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListTokenHoldingsResponse;
  static deserializeBinaryFromReader(message: ListTokenHoldingsResponse, reader: jspb.BinaryReader): ListTokenHoldingsResponse;
}

export namespace ListTokenHoldingsResponse {
  export type AsObject = {
    holdingsList: Array<TokenHolding.AsObject>,
  }
}

export class TokenHolding extends jspb.Message {
  getTokenId(): string;
  setTokenId(value: string): TokenHolding;

  getBalance(): number;
  setBalance(value: number): TokenHolding;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TokenHolding.AsObject;
  static toObject(includeInstance: boolean, msg: TokenHolding): TokenHolding.AsObject;
  static serializeBinaryToWriter(message: TokenHolding, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TokenHolding;
  static deserializeBinaryFromReader(message: TokenHolding, reader: jspb.BinaryReader): TokenHolding;
}

export namespace TokenHolding {
  export type AsObject = {
    tokenId: string,
    balance: number,
  }
}

export class GetTokenRequest extends jspb.Message {
  getTokenId(): string;
  setTokenId(value: string): GetTokenRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetTokenRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetTokenRequest): GetTokenRequest.AsObject;
  static serializeBinaryToWriter(message: GetTokenRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetTokenRequest;
  static deserializeBinaryFromReader(message: GetTokenRequest, reader: jspb.BinaryReader): GetTokenRequest;
}

export namespace GetTokenRequest {
  export type AsObject = {
    tokenId: string,
  }
}

export class Token extends jspb.Message {
  getTokenId(): string;
  setTokenId(value: string): Token;

  getName(): string;
  setName(value: string): Token;

  getSymbol(): string;
  setSymbol(value: string): Token;

  getType(): string;
  setType(value: string): Token;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Token.AsObject;
  static toObject(includeInstance: boolean, msg: Token): Token.AsObject;
  static serializeBinaryToWriter(message: Token, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Token;
  static deserializeBinaryFromReader(message: Token, reader: jspb.BinaryReader): Token;
}

export namespace Token {
  export type AsObject = {
    tokenId: string,
    name: string,
    symbol: string,
    type: string,
  }
}

export class ListCredentialsRequest extends jspb.Message {
  getAccountId(): string;
  setAccountId(value: string): ListCredentialsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListCredentialsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListCredentialsRequest): ListCredentialsRequest.AsObject;
  static serializeBinaryToWriter(message: ListCredentialsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListCredentialsRequest;
  static deserializeBinaryFromReader(message: ListCredentialsRequest, reader: jspb.BinaryReader): ListCredentialsRequest;
}

export namespace ListCredentialsRequest {
  export type AsObject = {
    accountId: string,
  }
}

export class ListCredentialsResponse extends jspb.Message {
  getCredentialsList(): Array<Credential>;
  setCredentialsList(value: Array<Credential>): ListCredentialsResponse;
  clearCredentialsList(): ListCredentialsResponse;
  addCredentials(value?: Credential, index?: number): Credential;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListCredentialsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListCredentialsResponse): ListCredentialsResponse.AsObject;
  static serializeBinaryToWriter(message: ListCredentialsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListCredentialsResponse;
  static deserializeBinaryFromReader(message: ListCredentialsResponse, reader: jspb.BinaryReader): ListCredentialsResponse;
}

export namespace ListCredentialsResponse {
  export type AsObject = {
    credentialsList: Array<Credential.AsObject>,
  }
}

export class Credential extends jspb.Message {
  getType(): string;
  setType(value: string): Credential;

  getIssuer(): string;
  setIssuer(value: string): Credential;

  getSubject(): string;
  setSubject(value: string): Credential;

  getTitle(): string;
  setTitle(value: string): Credential;

  getIssueTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setIssueTime(value?: google_protobuf_timestamp_pb.Timestamp): Credential;
  hasIssueTime(): boolean;
  clearIssueTime(): Credential;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Credential.AsObject;
  static toObject(includeInstance: boolean, msg: Credential): Credential.AsObject;
  static serializeBinaryToWriter(message: Credential, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Credential;
  static deserializeBinaryFromReader(message: Credential, reader: jspb.BinaryReader): Credential;
}

export namespace Credential {
  export type AsObject = {
    type: string,
    issuer: string,
    subject: string,
    title: string,
    issueTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }
}

export class ListPositionsRequest extends jspb.Message {
  getPageSize(): number;
  setPageSize(value: number): ListPositionsRequest;

  getPageToken(): string;
  setPageToken(value: string): ListPositionsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListPositionsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListPositionsRequest): ListPositionsRequest.AsObject;
  static serializeBinaryToWriter(message: ListPositionsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListPositionsRequest;
  static deserializeBinaryFromReader(message: ListPositionsRequest, reader: jspb.BinaryReader): ListPositionsRequest;
}

export namespace ListPositionsRequest {
  export type AsObject = {
    pageSize: number,
    pageToken: string,
  }
}

export class ListPositionsResponse extends jspb.Message {
  getPositionsList(): Array<interface_ti_positions_v1_positions_pb.Position>;
  setPositionsList(value: Array<interface_ti_positions_v1_positions_pb.Position>): ListPositionsResponse;
  clearPositionsList(): ListPositionsResponse;
  addPositions(value?: interface_ti_positions_v1_positions_pb.Position, index?: number): interface_ti_positions_v1_positions_pb.Position;

  getNextPageToken(): string;
  setNextPageToken(value: string): ListPositionsResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListPositionsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListPositionsResponse): ListPositionsResponse.AsObject;
  static serializeBinaryToWriter(message: ListPositionsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListPositionsResponse;
  static deserializeBinaryFromReader(message: ListPositionsResponse, reader: jspb.BinaryReader): ListPositionsResponse;
}

export namespace ListPositionsResponse {
  export type AsObject = {
    positionsList: Array<interface_ti_positions_v1_positions_pb.Position.AsObject>,
    nextPageToken: string,
  }
}

export class SearchProfilesRequest extends jspb.Message {
  getPosition(): string;
  setPosition(value: string): SearchProfilesRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SearchProfilesRequest.AsObject;
  static toObject(includeInstance: boolean, msg: SearchProfilesRequest): SearchProfilesRequest.AsObject;
  static serializeBinaryToWriter(message: SearchProfilesRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SearchProfilesRequest;
  static deserializeBinaryFromReader(message: SearchProfilesRequest, reader: jspb.BinaryReader): SearchProfilesRequest;
}

export namespace SearchProfilesRequest {
  export type AsObject = {
    position: string,
  }
}

export class SearchProfilesResponse extends jspb.Message {
  getProfilesList(): Array<SearchProfilesResponse.ProfileEligibility>;
  setProfilesList(value: Array<SearchProfilesResponse.ProfileEligibility>): SearchProfilesResponse;
  clearProfilesList(): SearchProfilesResponse;
  addProfiles(value?: SearchProfilesResponse.ProfileEligibility, index?: number): SearchProfilesResponse.ProfileEligibility;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SearchProfilesResponse.AsObject;
  static toObject(includeInstance: boolean, msg: SearchProfilesResponse): SearchProfilesResponse.AsObject;
  static serializeBinaryToWriter(message: SearchProfilesResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SearchProfilesResponse;
  static deserializeBinaryFromReader(message: SearchProfilesResponse, reader: jspb.BinaryReader): SearchProfilesResponse;
}

export namespace SearchProfilesResponse {
  export type AsObject = {
    profilesList: Array<SearchProfilesResponse.ProfileEligibility.AsObject>,
  }

  export class ProfileEligibility extends jspb.Message {
    getUser(): string;
    setUser(value: string): ProfileEligibility;

    getHederaAccountAddress(): string;
    setHederaAccountAddress(value: string): ProfileEligibility;

    getEligible(): boolean;
    setEligible(value: boolean): ProfileEligibility;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): ProfileEligibility.AsObject;
    static toObject(includeInstance: boolean, msg: ProfileEligibility): ProfileEligibility.AsObject;
    static serializeBinaryToWriter(message: ProfileEligibility, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): ProfileEligibility;
    static deserializeBinaryFromReader(message: ProfileEligibility, reader: jspb.BinaryReader): ProfileEligibility;
  }

  export namespace ProfileEligibility {
    export type AsObject = {
      user: string,
      hederaAccountAddress: string,
      eligible: boolean,
    }
  }

}
