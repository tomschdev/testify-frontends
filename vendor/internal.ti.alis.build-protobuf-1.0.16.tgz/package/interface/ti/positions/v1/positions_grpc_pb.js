// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('@grpc/grpc-js');
var interface_ti_positions_v1_positions_pb = require('../../../../interface/ti/positions/v1/positions_pb.js');
var google_protobuf_field_mask_pb = require('google-protobuf/google/protobuf/field_mask_pb.js');
var google_protobuf_timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb.js');

function serialize_interface_ti_positions_v1_CreatePositionRequest(arg) {
  if (!(arg instanceof interface_ti_positions_v1_positions_pb.CreatePositionRequest)) {
    throw new Error('Expected argument of type interface.ti.positions.v1.CreatePositionRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_positions_v1_CreatePositionRequest(buffer_arg) {
  return interface_ti_positions_v1_positions_pb.CreatePositionRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_positions_v1_FulfillPositionRequest(arg) {
  if (!(arg instanceof interface_ti_positions_v1_positions_pb.FulfillPositionRequest)) {
    throw new Error('Expected argument of type interface.ti.positions.v1.FulfillPositionRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_positions_v1_FulfillPositionRequest(buffer_arg) {
  return interface_ti_positions_v1_positions_pb.FulfillPositionRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_positions_v1_GetPositionRequest(arg) {
  if (!(arg instanceof interface_ti_positions_v1_positions_pb.GetPositionRequest)) {
    throw new Error('Expected argument of type interface.ti.positions.v1.GetPositionRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_positions_v1_GetPositionRequest(buffer_arg) {
  return interface_ti_positions_v1_positions_pb.GetPositionRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_positions_v1_ListPositionsRequest(arg) {
  if (!(arg instanceof interface_ti_positions_v1_positions_pb.ListPositionsRequest)) {
    throw new Error('Expected argument of type interface.ti.positions.v1.ListPositionsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_positions_v1_ListPositionsRequest(buffer_arg) {
  return interface_ti_positions_v1_positions_pb.ListPositionsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_positions_v1_ListPositionsResponse(arg) {
  if (!(arg instanceof interface_ti_positions_v1_positions_pb.ListPositionsResponse)) {
    throw new Error('Expected argument of type interface.ti.positions.v1.ListPositionsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_positions_v1_ListPositionsResponse(buffer_arg) {
  return interface_ti_positions_v1_positions_pb.ListPositionsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_positions_v1_Position(arg) {
  if (!(arg instanceof interface_ti_positions_v1_positions_pb.Position)) {
    throw new Error('Expected argument of type interface.ti.positions.v1.Position');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_positions_v1_Position(buffer_arg) {
  return interface_ti_positions_v1_positions_pb.Position.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_positions_v1_RevokePositionRequest(arg) {
  if (!(arg instanceof interface_ti_positions_v1_positions_pb.RevokePositionRequest)) {
    throw new Error('Expected argument of type interface.ti.positions.v1.RevokePositionRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_positions_v1_RevokePositionRequest(buffer_arg) {
  return interface_ti_positions_v1_positions_pb.RevokePositionRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_positions_v1_SearchProfilesRequest(arg) {
  if (!(arg instanceof interface_ti_positions_v1_positions_pb.SearchProfilesRequest)) {
    throw new Error('Expected argument of type interface.ti.positions.v1.SearchProfilesRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_positions_v1_SearchProfilesRequest(buffer_arg) {
  return interface_ti_positions_v1_positions_pb.SearchProfilesRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_positions_v1_SearchProfilesResponse(arg) {
  if (!(arg instanceof interface_ti_positions_v1_positions_pb.SearchProfilesResponse)) {
    throw new Error('Expected argument of type interface.ti.positions.v1.SearchProfilesResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_positions_v1_SearchProfilesResponse(buffer_arg) {
  return interface_ti_positions_v1_positions_pb.SearchProfilesResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_positions_v1_UpdatePositionRequest(arg) {
  if (!(arg instanceof interface_ti_positions_v1_positions_pb.UpdatePositionRequest)) {
    throw new Error('Expected argument of type interface.ti.positions.v1.UpdatePositionRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_positions_v1_UpdatePositionRequest(buffer_arg) {
  return interface_ti_positions_v1_positions_pb.UpdatePositionRequest.deserializeBinary(new Uint8Array(buffer_arg));
}


// PositionsService manages Position resources.
//
// A Position is a job requirement published by an Organisation (the issuer /
// employer role in the Testify model). It is the "Post" of the implementation
// reference, renamed to Position.
//
// A Position is a child of the Organisation that owns it
// (organisations/*/positions/*); access is therefore governed by the parent
// Organisation's IAM policy, so this service exposes no per-Position IAM methods.
//
// Lifecycle. A Position moves through the states OPEN -> {REVOKED | FULFILLED}
// (see PositionState). The service is the owner of these transitions and
// publishes create / update / revoke / fulfill events to the shared HCS position
// topic, embedding the Position's id in every message so a Position's state can
// be reconstructed by replaying that topic in order. Because REVOKED is the
// terminal "closed" state, there is no soft-delete: a Position is revoked, not
// deleted.
var PositionsServiceService = exports.PositionsServiceService = {
  // Creates a new position under an organisation. Publishes a create event.
createPosition: {
    path: '/interface.ti.positions.v1.PositionsService/CreatePosition',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_positions_v1_positions_pb.CreatePositionRequest,
    responseType: interface_ti_positions_v1_positions_pb.Position,
    requestSerialize: serialize_interface_ti_positions_v1_CreatePositionRequest,
    requestDeserialize: deserialize_interface_ti_positions_v1_CreatePositionRequest,
    responseSerialize: serialize_interface_ti_positions_v1_Position,
    responseDeserialize: deserialize_interface_ti_positions_v1_Position,
  },
  // Gets a position by its resource name.
getPosition: {
    path: '/interface.ti.positions.v1.PositionsService/GetPosition',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_positions_v1_positions_pb.GetPositionRequest,
    responseType: interface_ti_positions_v1_positions_pb.Position,
    requestSerialize: serialize_interface_ti_positions_v1_GetPositionRequest,
    requestDeserialize: deserialize_interface_ti_positions_v1_GetPositionRequest,
    responseSerialize: serialize_interface_ti_positions_v1_Position,
    responseDeserialize: deserialize_interface_ti_positions_v1_Position,
  },
  // Updates a position. Publishes an update event. Terminal positions
// (REVOKED, FULFILLED) cannot be updated.
updatePosition: {
    path: '/interface.ti.positions.v1.PositionsService/UpdatePosition',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_positions_v1_positions_pb.UpdatePositionRequest,
    responseType: interface_ti_positions_v1_positions_pb.Position,
    requestSerialize: serialize_interface_ti_positions_v1_UpdatePositionRequest,
    requestDeserialize: deserialize_interface_ti_positions_v1_UpdatePositionRequest,
    responseSerialize: serialize_interface_ti_positions_v1_Position,
    responseDeserialize: deserialize_interface_ti_positions_v1_Position,
  },
  // Lists the positions of an organisation.
listPositions: {
    path: '/interface.ti.positions.v1.PositionsService/ListPositions',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_positions_v1_positions_pb.ListPositionsRequest,
    responseType: interface_ti_positions_v1_positions_pb.ListPositionsResponse,
    requestSerialize: serialize_interface_ti_positions_v1_ListPositionsRequest,
    requestDeserialize: deserialize_interface_ti_positions_v1_ListPositionsRequest,
    responseSerialize: serialize_interface_ti_positions_v1_ListPositionsResponse,
    responseDeserialize: deserialize_interface_ti_positions_v1_ListPositionsResponse,
  },
  // Revokes an open position, transitioning it to REVOKED. Publishes a revoke
// event. Used when the organisation withdraws a position.
revokePosition: {
    path: '/interface.ti.positions.v1.PositionsService/RevokePosition',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_positions_v1_positions_pb.RevokePositionRequest,
    responseType: interface_ti_positions_v1_positions_pb.Position,
    requestSerialize: serialize_interface_ti_positions_v1_RevokePositionRequest,
    requestDeserialize: deserialize_interface_ti_positions_v1_RevokePositionRequest,
    responseSerialize: serialize_interface_ti_positions_v1_Position,
    responseDeserialize: deserialize_interface_ti_positions_v1_Position,
  },
  // Fulfils an open position, transitioning it to FULFILLED. Publishes a fulfil
// event. Used when the position has been filled.
fulfillPosition: {
    path: '/interface.ti.positions.v1.PositionsService/FulfillPosition',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_positions_v1_positions_pb.FulfillPositionRequest,
    responseType: interface_ti_positions_v1_positions_pb.Position,
    requestSerialize: serialize_interface_ti_positions_v1_FulfillPositionRequest,
    requestDeserialize: deserialize_interface_ti_positions_v1_FulfillPositionRequest,
    responseSerialize: serialize_interface_ti_positions_v1_Position,
    responseDeserialize: deserialize_interface_ti_positions_v1_Position,
  },
  // Returns the profiles whose credentials satisfy a position's active filters.
//
// The service compiles the position's active Filters (AND-combined) into a
// Spanner query, executes it against synced credential data, and returns the
// matching profiles. This is the candidate-screening (KYCC/KYJR) surface.
searchProfiles: {
    path: '/interface.ti.positions.v1.PositionsService/SearchProfiles',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_positions_v1_positions_pb.SearchProfilesRequest,
    responseType: interface_ti_positions_v1_positions_pb.SearchProfilesResponse,
    requestSerialize: serialize_interface_ti_positions_v1_SearchProfilesRequest,
    requestDeserialize: deserialize_interface_ti_positions_v1_SearchProfilesRequest,
    responseSerialize: serialize_interface_ti_positions_v1_SearchProfilesResponse,
    responseDeserialize: deserialize_interface_ti_positions_v1_SearchProfilesResponse,
  },
};

exports.PositionsServiceClient = grpc.makeGenericClientConstructor(PositionsServiceService, 'PositionsService');