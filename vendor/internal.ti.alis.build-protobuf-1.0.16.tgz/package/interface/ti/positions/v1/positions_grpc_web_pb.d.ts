import * as grpcWeb from 'grpc-web';

import * as interface_ti_positions_v1_positions_pb from '../../../../interface/ti/positions/v1/positions_pb'; // proto import: "interface/ti/positions/v1/positions.proto"


export class PositionsServiceClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  createPosition(
    request: interface_ti_positions_v1_positions_pb.CreatePositionRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_positions_v1_positions_pb.Position) => void
  ): grpcWeb.ClientReadableStream<interface_ti_positions_v1_positions_pb.Position>;

  getPosition(
    request: interface_ti_positions_v1_positions_pb.GetPositionRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_positions_v1_positions_pb.Position) => void
  ): grpcWeb.ClientReadableStream<interface_ti_positions_v1_positions_pb.Position>;

  updatePosition(
    request: interface_ti_positions_v1_positions_pb.UpdatePositionRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_positions_v1_positions_pb.Position) => void
  ): grpcWeb.ClientReadableStream<interface_ti_positions_v1_positions_pb.Position>;

  listPositions(
    request: interface_ti_positions_v1_positions_pb.ListPositionsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_positions_v1_positions_pb.ListPositionsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_positions_v1_positions_pb.ListPositionsResponse>;

  revokePosition(
    request: interface_ti_positions_v1_positions_pb.RevokePositionRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_positions_v1_positions_pb.Position) => void
  ): grpcWeb.ClientReadableStream<interface_ti_positions_v1_positions_pb.Position>;

  fulfillPosition(
    request: interface_ti_positions_v1_positions_pb.FulfillPositionRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_positions_v1_positions_pb.Position) => void
  ): grpcWeb.ClientReadableStream<interface_ti_positions_v1_positions_pb.Position>;

  searchProfiles(
    request: interface_ti_positions_v1_positions_pb.SearchProfilesRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_positions_v1_positions_pb.SearchProfilesResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_positions_v1_positions_pb.SearchProfilesResponse>;

}

export class PositionsServicePromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  createPosition(
    request: interface_ti_positions_v1_positions_pb.CreatePositionRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_positions_v1_positions_pb.Position>;

  getPosition(
    request: interface_ti_positions_v1_positions_pb.GetPositionRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_positions_v1_positions_pb.Position>;

  updatePosition(
    request: interface_ti_positions_v1_positions_pb.UpdatePositionRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_positions_v1_positions_pb.Position>;

  listPositions(
    request: interface_ti_positions_v1_positions_pb.ListPositionsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_positions_v1_positions_pb.ListPositionsResponse>;

  revokePosition(
    request: interface_ti_positions_v1_positions_pb.RevokePositionRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_positions_v1_positions_pb.Position>;

  fulfillPosition(
    request: interface_ti_positions_v1_positions_pb.FulfillPositionRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_positions_v1_positions_pb.Position>;

  searchProfiles(
    request: interface_ti_positions_v1_positions_pb.SearchProfilesRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_positions_v1_positions_pb.SearchProfilesResponse>;

}
