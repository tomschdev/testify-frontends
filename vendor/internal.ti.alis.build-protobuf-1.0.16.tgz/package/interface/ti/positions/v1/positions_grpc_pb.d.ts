// GENERATED CODE -- DO NOT EDIT!

// package: interface.ti.positions.v1
// file: interface/ti/positions/v1/positions.proto

import * as interface_ti_positions_v1_positions_pb from "../../../../interface/ti/positions/v1/positions_pb";
import * as grpc from "@grpc/grpc-js";

interface IPositionsServiceService extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
  createPosition: grpc.MethodDefinition<interface_ti_positions_v1_positions_pb.CreatePositionRequest, interface_ti_positions_v1_positions_pb.Position>;
  getPosition: grpc.MethodDefinition<interface_ti_positions_v1_positions_pb.GetPositionRequest, interface_ti_positions_v1_positions_pb.Position>;
  updatePosition: grpc.MethodDefinition<interface_ti_positions_v1_positions_pb.UpdatePositionRequest, interface_ti_positions_v1_positions_pb.Position>;
  listPositions: grpc.MethodDefinition<interface_ti_positions_v1_positions_pb.ListPositionsRequest, interface_ti_positions_v1_positions_pb.ListPositionsResponse>;
  revokePosition: grpc.MethodDefinition<interface_ti_positions_v1_positions_pb.RevokePositionRequest, interface_ti_positions_v1_positions_pb.Position>;
  fulfillPosition: grpc.MethodDefinition<interface_ti_positions_v1_positions_pb.FulfillPositionRequest, interface_ti_positions_v1_positions_pb.Position>;
  searchProfiles: grpc.MethodDefinition<interface_ti_positions_v1_positions_pb.SearchProfilesRequest, interface_ti_positions_v1_positions_pb.SearchProfilesResponse>;
}

export const PositionsServiceService: IPositionsServiceService;

export interface IPositionsServiceServer extends grpc.UntypedServiceImplementation {
  createPosition: grpc.handleUnaryCall<interface_ti_positions_v1_positions_pb.CreatePositionRequest, interface_ti_positions_v1_positions_pb.Position>;
  getPosition: grpc.handleUnaryCall<interface_ti_positions_v1_positions_pb.GetPositionRequest, interface_ti_positions_v1_positions_pb.Position>;
  updatePosition: grpc.handleUnaryCall<interface_ti_positions_v1_positions_pb.UpdatePositionRequest, interface_ti_positions_v1_positions_pb.Position>;
  listPositions: grpc.handleUnaryCall<interface_ti_positions_v1_positions_pb.ListPositionsRequest, interface_ti_positions_v1_positions_pb.ListPositionsResponse>;
  revokePosition: grpc.handleUnaryCall<interface_ti_positions_v1_positions_pb.RevokePositionRequest, interface_ti_positions_v1_positions_pb.Position>;
  fulfillPosition: grpc.handleUnaryCall<interface_ti_positions_v1_positions_pb.FulfillPositionRequest, interface_ti_positions_v1_positions_pb.Position>;
  searchProfiles: grpc.handleUnaryCall<interface_ti_positions_v1_positions_pb.SearchProfilesRequest, interface_ti_positions_v1_positions_pb.SearchProfilesResponse>;
}

export class PositionsServiceClient extends grpc.Client {
  constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
  createPosition(argument: interface_ti_positions_v1_positions_pb.CreatePositionRequest, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  createPosition(argument: interface_ti_positions_v1_positions_pb.CreatePositionRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  createPosition(argument: interface_ti_positions_v1_positions_pb.CreatePositionRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  getPosition(argument: interface_ti_positions_v1_positions_pb.GetPositionRequest, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  getPosition(argument: interface_ti_positions_v1_positions_pb.GetPositionRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  getPosition(argument: interface_ti_positions_v1_positions_pb.GetPositionRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  updatePosition(argument: interface_ti_positions_v1_positions_pb.UpdatePositionRequest, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  updatePosition(argument: interface_ti_positions_v1_positions_pb.UpdatePositionRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  updatePosition(argument: interface_ti_positions_v1_positions_pb.UpdatePositionRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  listPositions(argument: interface_ti_positions_v1_positions_pb.ListPositionsRequest, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.ListPositionsResponse>): grpc.ClientUnaryCall;
  listPositions(argument: interface_ti_positions_v1_positions_pb.ListPositionsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.ListPositionsResponse>): grpc.ClientUnaryCall;
  listPositions(argument: interface_ti_positions_v1_positions_pb.ListPositionsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.ListPositionsResponse>): grpc.ClientUnaryCall;
  revokePosition(argument: interface_ti_positions_v1_positions_pb.RevokePositionRequest, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  revokePosition(argument: interface_ti_positions_v1_positions_pb.RevokePositionRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  revokePosition(argument: interface_ti_positions_v1_positions_pb.RevokePositionRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  fulfillPosition(argument: interface_ti_positions_v1_positions_pb.FulfillPositionRequest, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  fulfillPosition(argument: interface_ti_positions_v1_positions_pb.FulfillPositionRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  fulfillPosition(argument: interface_ti_positions_v1_positions_pb.FulfillPositionRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.Position>): grpc.ClientUnaryCall;
  searchProfiles(argument: interface_ti_positions_v1_positions_pb.SearchProfilesRequest, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.SearchProfilesResponse>): grpc.ClientUnaryCall;
  searchProfiles(argument: interface_ti_positions_v1_positions_pb.SearchProfilesRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.SearchProfilesResponse>): grpc.ClientUnaryCall;
  searchProfiles(argument: interface_ti_positions_v1_positions_pb.SearchProfilesRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_positions_v1_positions_pb.SearchProfilesResponse>): grpc.ClientUnaryCall;
}