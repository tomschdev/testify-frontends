import * as jspb from 'google-protobuf'

import * as google_protobuf_duration_pb from 'google-protobuf/google/protobuf/duration_pb'; // proto import: "google/protobuf/duration.proto"


export class Config extends jspb.Message {
  getAuthProviders(): Config.AuthProviders | undefined;
  setAuthProviders(value?: Config.AuthProviders): Config;
  hasAuthProviders(): boolean;
  clearAuthProviders(): Config;

  getRedirectUrisList(): Array<string>;
  setRedirectUrisList(value: Array<string>): Config;
  clearRedirectUrisList(): Config;
  addRedirectUris(value: string, index?: number): Config;

  getSignedInDuration(): google_protobuf_duration_pb.Duration | undefined;
  setSignedInDuration(value?: google_protobuf_duration_pb.Duration): Config;
  hasSignedInDuration(): boolean;
  clearSignedInDuration(): Config;

  getSelfSignupDomainsList(): Array<string>;
  setSelfSignupDomainsList(value: Array<string>): Config;
  clearSelfSignupDomainsList(): Config;
  addSelfSignupDomains(value: string, index?: number): Config;

  getScopesMap(): jspb.Map<string, Config.Scope>;
  clearScopesMap(): Config;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Config.AsObject;
  static toObject(includeInstance: boolean, msg: Config): Config.AsObject;
  static serializeBinaryToWriter(message: Config, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Config;
  static deserializeBinaryFromReader(message: Config, reader: jspb.BinaryReader): Config;
}

export namespace Config {
  export type AsObject = {
    authProviders?: Config.AuthProviders.AsObject,
    redirectUrisList: Array<string>,
    signedInDuration?: google_protobuf_duration_pb.Duration.AsObject,
    selfSignupDomainsList: Array<string>,
    scopesMap: Array<[string, Config.Scope.AsObject]>,
  }

  export class AuthProviders extends jspb.Message {
    getGoogle(): OauthProvider | undefined;
    setGoogle(value?: OauthProvider): AuthProviders;
    hasGoogle(): boolean;
    clearGoogle(): AuthProviders;

    getMicrosoft(): OauthProvider | undefined;
    setMicrosoft(value?: OauthProvider): AuthProviders;
    hasMicrosoft(): boolean;
    clearMicrosoft(): AuthProviders;

    getEmail(): EmailAuthProvider | undefined;
    setEmail(value?: EmailAuthProvider): AuthProviders;
    hasEmail(): boolean;
    clearEmail(): AuthProviders;

    getLinkedin(): OauthProvider | undefined;
    setLinkedin(value?: OauthProvider): AuthProviders;
    hasLinkedin(): boolean;
    clearLinkedin(): AuthProviders;

    getApple(): AppleAuthProvider | undefined;
    setApple(value?: AppleAuthProvider): AuthProviders;
    hasApple(): boolean;
    clearApple(): AuthProviders;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): AuthProviders.AsObject;
    static toObject(includeInstance: boolean, msg: AuthProviders): AuthProviders.AsObject;
    static serializeBinaryToWriter(message: AuthProviders, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): AuthProviders;
    static deserializeBinaryFromReader(message: AuthProviders, reader: jspb.BinaryReader): AuthProviders;
  }

  export namespace AuthProviders {
    export type AsObject = {
      google?: OauthProvider.AsObject,
      microsoft?: OauthProvider.AsObject,
      email?: EmailAuthProvider.AsObject,
      linkedin?: OauthProvider.AsObject,
      apple?: AppleAuthProvider.AsObject,
    }
  }


  export class Scope extends jspb.Message {
    getId(): string;
    setId(value: string): Scope;

    getDescription(): string;
    setDescription(value: string): Scope;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Scope.AsObject;
    static toObject(includeInstance: boolean, msg: Scope): Scope.AsObject;
    static serializeBinaryToWriter(message: Scope, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Scope;
    static deserializeBinaryFromReader(message: Scope, reader: jspb.BinaryReader): Scope;
  }

  export namespace Scope {
    export type AsObject = {
      id: string,
      description: string,
    }
  }

}

export class OauthProvider extends jspb.Message {
  getClientId(): string;
  setClientId(value: string): OauthProvider;

  getClientSecret(): string;
  setClientSecret(value: string): OauthProvider;

  getDomainsList(): Array<string>;
  setDomainsList(value: Array<string>): OauthProvider;
  clearDomainsList(): OauthProvider;
  addDomains(value: string, index?: number): OauthProvider;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): OauthProvider.AsObject;
  static toObject(includeInstance: boolean, msg: OauthProvider): OauthProvider.AsObject;
  static serializeBinaryToWriter(message: OauthProvider, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): OauthProvider;
  static deserializeBinaryFromReader(message: OauthProvider, reader: jspb.BinaryReader): OauthProvider;
}

export namespace OauthProvider {
  export type AsObject = {
    clientId: string,
    clientSecret: string,
    domainsList: Array<string>,
  }
}

export class EmailAuthProvider extends jspb.Message {
  getFromEmail(): string;
  setFromEmail(value: string): EmailAuthProvider;

  getDomainsList(): Array<string>;
  setDomainsList(value: Array<string>): EmailAuthProvider;
  clearDomainsList(): EmailAuthProvider;
  addDomains(value: string, index?: number): EmailAuthProvider;

  getTemplateId(): string;
  setTemplateId(value: string): EmailAuthProvider;

  getSendgridApiKey(): string;
  setSendgridApiKey(value: string): EmailAuthProvider;

  getServerCase(): EmailAuthProvider.ServerCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): EmailAuthProvider.AsObject;
  static toObject(includeInstance: boolean, msg: EmailAuthProvider): EmailAuthProvider.AsObject;
  static serializeBinaryToWriter(message: EmailAuthProvider, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): EmailAuthProvider;
  static deserializeBinaryFromReader(message: EmailAuthProvider, reader: jspb.BinaryReader): EmailAuthProvider;
}

export namespace EmailAuthProvider {
  export type AsObject = {
    fromEmail: string,
    domainsList: Array<string>,
    templateId: string,
    sendgridApiKey: string,
  }

  export enum ServerCase { 
    SERVER_NOT_SET = 0,
    SENDGRID_API_KEY = 11,
  }
}

export class AppleAuthProvider extends jspb.Message {
  getTeamId(): string;
  setTeamId(value: string): AppleAuthProvider;

  getClientId(): string;
  setClientId(value: string): AppleAuthProvider;

  getClientSecret(): string;
  setClientSecret(value: string): AppleAuthProvider;

  getKeyId(): string;
  setKeyId(value: string): AppleAuthProvider;

  getDomainsList(): Array<string>;
  setDomainsList(value: Array<string>): AppleAuthProvider;
  clearDomainsList(): AppleAuthProvider;
  addDomains(value: string, index?: number): AppleAuthProvider;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AppleAuthProvider.AsObject;
  static toObject(includeInstance: boolean, msg: AppleAuthProvider): AppleAuthProvider.AsObject;
  static serializeBinaryToWriter(message: AppleAuthProvider, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AppleAuthProvider;
  static deserializeBinaryFromReader(message: AppleAuthProvider, reader: jspb.BinaryReader): AppleAuthProvider;
}

export namespace AppleAuthProvider {
  export type AsObject = {
    teamId: string,
    clientId: string,
    clientSecret: string,
    keyId: string,
    domainsList: Array<string>,
  }
}
