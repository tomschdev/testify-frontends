import * as jspb from 'google-protobuf'

import * as alis_open_iam_v1_iam_pb from '@open.alis.services/protobuf/alis/open/iam/v1/iam_pb'; // proto import: "alis/open/iam/v1/iam.proto"
import * as google_iam_v1_iam_policy_pb from '@alis-build/google-common-protos/google/iam/v1/iam_policy_pb'; // proto import: "google/iam/v1/iam_policy.proto"
import * as google_iam_v1_policy_pb from '@alis-build/google-common-protos/google/iam/v1/policy_pb'; // proto import: "google/iam/v1/policy.proto"
import * as google_longrunning_operations_pb from '@alis-build/google-common-protos/google/longrunning/operations_pb'; // proto import: "google/longrunning/operations.proto"
import * as google_protobuf_any_pb from 'google-protobuf/google/protobuf/any_pb'; // proto import: "google/protobuf/any.proto"
import * as google_protobuf_empty_pb from 'google-protobuf/google/protobuf/empty_pb'; // proto import: "google/protobuf/empty.proto"
import * as google_protobuf_field_mask_pb from 'google-protobuf/google/protobuf/field_mask_pb'; // proto import: "google/protobuf/field_mask.proto"
import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb'; // proto import: "google/protobuf/timestamp.proto"


export class User extends jspb.Message {
  getName(): string;
  setName(value: string): User;

  getEmail(): string;
  setEmail(value: string): User;

  getGivenName(): string;
  setGivenName(value: string): User;

  getFamilyName(): string;
  setFamilyName(value: string): User;

  getPicture(): string;
  setPicture(value: string): User;

  getContactNumber(): string;
  setContactNumber(value: string): User;

  getPosition(): string;
  setPosition(value: string): User;

  getEducation(): string;
  setEducation(value: string): User;

  getLinkedinUri(): string;
  setLinkedinUri(value: string): User;

  getVerifiedEmail(): boolean;
  setVerifiedEmail(value: boolean): User;

  getIdentityProvider(): IdentityProvider;
  setIdentityProvider(value: IdentityProvider): User;

  getGoogleGroup(): string;
  setGoogleGroup(value: string): User;

  getMetadata(): google_protobuf_any_pb.Any | undefined;
  setMetadata(value?: google_protobuf_any_pb.Any): User;
  hasMetadata(): boolean;
  clearMetadata(): User;

  getInternalMetadata(): google_protobuf_any_pb.Any | undefined;
  setInternalMetadata(value?: google_protobuf_any_pb.Any): User;
  hasInternalMetadata(): boolean;
  clearInternalMetadata(): User;

  getCreateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreateTime(value?: google_protobuf_timestamp_pb.Timestamp): User;
  hasCreateTime(): boolean;
  clearCreateTime(): User;

  getUpdateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setUpdateTime(value?: google_protobuf_timestamp_pb.Timestamp): User;
  hasUpdateTime(): boolean;
  clearUpdateTime(): User;

  getLastSignInTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setLastSignInTime(value?: google_protobuf_timestamp_pb.Timestamp): User;
  hasLastSignInTime(): boolean;
  clearLastSignInTime(): User;

  getLastRefreshTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setLastRefreshTime(value?: google_protobuf_timestamp_pb.Timestamp): User;
  hasLastRefreshTime(): boolean;
  clearLastRefreshTime(): User;

  getGoogleIdentity(): User.GoogleIdentity | undefined;
  setGoogleIdentity(value?: User.GoogleIdentity): User;
  hasGoogleIdentity(): boolean;
  clearGoogleIdentity(): User;

  getMicrosoftIdentity(): User.MicrosoftIdentity | undefined;
  setMicrosoftIdentity(value?: User.MicrosoftIdentity): User;
  hasMicrosoftIdentity(): boolean;
  clearMicrosoftIdentity(): User;

  getLinkedinIdentity(): User.LinkedinIdentity | undefined;
  setLinkedinIdentity(value?: User.LinkedinIdentity): User;
  hasLinkedinIdentity(): boolean;
  clearLinkedinIdentity(): User;

  getGroupIdsList(): Array<string>;
  setGroupIdsList(value: Array<string>): User;
  clearGroupIdsList(): User;
  addGroupIds(value: string, index?: number): User;

  getAppleIdentity(): User.AppleIdentity | undefined;
  setAppleIdentity(value?: User.AppleIdentity): User;
  hasAppleIdentity(): boolean;
  clearAppleIdentity(): User;

  getHederaAccountAddress(): string;
  setHederaAccountAddress(value: string): User;

  getPublicKey(): string;
  setPublicKey(value: string): User;

  getPrivateKey(): string;
  setPrivateKey(value: string): User;

  getProfile(): Profile | undefined;
  setProfile(value?: Profile): User;
  hasProfile(): boolean;
  clearProfile(): User;

  getAccountsMap(): jspb.Map<string, User.Account>;
  clearAccountsMap(): User;

  getEtag(): string;
  setEtag(value: string): User;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): User.AsObject;
  static toObject(includeInstance: boolean, msg: User): User.AsObject;
  static serializeBinaryToWriter(message: User, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): User;
  static deserializeBinaryFromReader(message: User, reader: jspb.BinaryReader): User;
}

export namespace User {
  export type AsObject = {
    name: string,
    email: string,
    givenName: string,
    familyName: string,
    picture: string,
    contactNumber: string,
    position: string,
    education: string,
    linkedinUri: string,
    verifiedEmail: boolean,
    identityProvider: IdentityProvider,
    googleGroup: string,
    metadata?: google_protobuf_any_pb.Any.AsObject,
    internalMetadata?: google_protobuf_any_pb.Any.AsObject,
    createTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    updateTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    lastSignInTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    lastRefreshTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    googleIdentity?: User.GoogleIdentity.AsObject,
    microsoftIdentity?: User.MicrosoftIdentity.AsObject,
    linkedinIdentity?: User.LinkedinIdentity.AsObject,
    groupIdsList: Array<string>,
    appleIdentity?: User.AppleIdentity.AsObject,
    hederaAccountAddress: string,
    publicKey: string,
    privateKey: string,
    profile?: Profile.AsObject,
    accountsMap: Array<[string, User.Account.AsObject]>,
    etag: string,
  }

  export class GoogleIdentity extends jspb.Message {
    getId(): string;
    setId(value: string): GoogleIdentity;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): GoogleIdentity.AsObject;
    static toObject(includeInstance: boolean, msg: GoogleIdentity): GoogleIdentity.AsObject;
    static serializeBinaryToWriter(message: GoogleIdentity, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): GoogleIdentity;
    static deserializeBinaryFromReader(message: GoogleIdentity, reader: jspb.BinaryReader): GoogleIdentity;
  }

  export namespace GoogleIdentity {
    export type AsObject = {
      id: string,
    }
  }


  export class MicrosoftIdentity extends jspb.Message {
    getId(): string;
    setId(value: string): MicrosoftIdentity;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): MicrosoftIdentity.AsObject;
    static toObject(includeInstance: boolean, msg: MicrosoftIdentity): MicrosoftIdentity.AsObject;
    static serializeBinaryToWriter(message: MicrosoftIdentity, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): MicrosoftIdentity;
    static deserializeBinaryFromReader(message: MicrosoftIdentity, reader: jspb.BinaryReader): MicrosoftIdentity;
  }

  export namespace MicrosoftIdentity {
    export type AsObject = {
      id: string,
    }
  }


  export class LinkedinIdentity extends jspb.Message {
    getId(): string;
    setId(value: string): LinkedinIdentity;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): LinkedinIdentity.AsObject;
    static toObject(includeInstance: boolean, msg: LinkedinIdentity): LinkedinIdentity.AsObject;
    static serializeBinaryToWriter(message: LinkedinIdentity, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): LinkedinIdentity;
    static deserializeBinaryFromReader(message: LinkedinIdentity, reader: jspb.BinaryReader): LinkedinIdentity;
  }

  export namespace LinkedinIdentity {
    export type AsObject = {
      id: string,
    }
  }


  export class AppleIdentity extends jspb.Message {
    getId(): string;
    setId(value: string): AppleIdentity;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): AppleIdentity.AsObject;
    static toObject(includeInstance: boolean, msg: AppleIdentity): AppleIdentity.AsObject;
    static serializeBinaryToWriter(message: AppleIdentity, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): AppleIdentity;
    static deserializeBinaryFromReader(message: AppleIdentity, reader: jspb.BinaryReader): AppleIdentity;
  }

  export namespace AppleIdentity {
    export type AsObject = {
      id: string,
    }
  }


  export class Account extends jspb.Message {
    getSeatsMap(): jspb.Map<number, User.Account.Seat>;
    clearSeatsMap(): Account;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Account.AsObject;
    static toObject(includeInstance: boolean, msg: Account): Account.AsObject;
    static serializeBinaryToWriter(message: Account, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Account;
    static deserializeBinaryFromReader(message: Account, reader: jspb.BinaryReader): Account;
  }

  export namespace Account {
    export type AsObject = {
      seatsMap: Array<[number, User.Account.Seat.AsObject]>,
    }

    export class Seat extends jspb.Message {
      getPlan(): number;
      setPlan(value: number): Seat;

      getSeat(): number;
      setSeat(value: number): Seat;

      serializeBinary(): Uint8Array;
      toObject(includeInstance?: boolean): Seat.AsObject;
      static toObject(includeInstance: boolean, msg: Seat): Seat.AsObject;
      static serializeBinaryToWriter(message: Seat, writer: jspb.BinaryWriter): void;
      static deserializeBinary(bytes: Uint8Array): Seat;
      static deserializeBinaryFromReader(message: Seat, reader: jspb.BinaryReader): Seat;
    }

    export namespace Seat {
      export type AsObject = {
        plan: number,
        seat: number,
      }
    }

  }

}

export class Profile extends jspb.Message {
  getXpCredentialsList(): Array<XPCredential>;
  setXpCredentialsList(value: Array<XPCredential>): Profile;
  clearXpCredentialsList(): Profile;
  addXpCredentials(value?: XPCredential, index?: number): XPCredential;

  getReputationCredentialsList(): Array<ReputationCredential>;
  setReputationCredentialsList(value: Array<ReputationCredential>): Profile;
  clearReputationCredentialsList(): Profile;
  addReputationCredentials(value?: ReputationCredential, index?: number): ReputationCredential;

  getXpTokensList(): Array<XPToken>;
  setXpTokensList(value: Array<XPToken>): Profile;
  clearXpTokensList(): Profile;
  addXpTokens(value?: XPToken, index?: number): XPToken;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Profile.AsObject;
  static toObject(includeInstance: boolean, msg: Profile): Profile.AsObject;
  static serializeBinaryToWriter(message: Profile, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Profile;
  static deserializeBinaryFromReader(message: Profile, reader: jspb.BinaryReader): Profile;
}

export namespace Profile {
  export type AsObject = {
    xpCredentialsList: Array<XPCredential.AsObject>,
    reputationCredentialsList: Array<ReputationCredential.AsObject>,
    xpTokensList: Array<XPToken.AsObject>,
  }
}

export class XPCredential extends jspb.Message {
  getIssuerPublicKey(): string;
  setIssuerPublicKey(value: string): XPCredential;

  getProfilePublicKey(): string;
  setProfilePublicKey(value: string): XPCredential;

  getHcsCredentialMessageHash(): string;
  setHcsCredentialMessageHash(value: string): XPCredential;

  getIssueTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setIssueTime(value?: google_protobuf_timestamp_pb.Timestamp): XPCredential;
  hasIssueTime(): boolean;
  clearIssueTime(): XPCredential;

  getState(): CredentialState;
  setState(value: CredentialState): XPCredential;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): XPCredential.AsObject;
  static toObject(includeInstance: boolean, msg: XPCredential): XPCredential.AsObject;
  static serializeBinaryToWriter(message: XPCredential, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): XPCredential;
  static deserializeBinaryFromReader(message: XPCredential, reader: jspb.BinaryReader): XPCredential;
}

export namespace XPCredential {
  export type AsObject = {
    issuerPublicKey: string,
    profilePublicKey: string,
    hcsCredentialMessageHash: string,
    issueTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    state: CredentialState,
  }
}

export class ReputationCredential extends jspb.Message {
  getIssuerPublicKey(): string;
  setIssuerPublicKey(value: string): ReputationCredential;

  getProfilePublicKey(): string;
  setProfilePublicKey(value: string): ReputationCredential;

  getHcsCredentialMessageHash(): string;
  setHcsCredentialMessageHash(value: string): ReputationCredential;

  getIssueTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setIssueTime(value?: google_protobuf_timestamp_pb.Timestamp): ReputationCredential;
  hasIssueTime(): boolean;
  clearIssueTime(): ReputationCredential;

  getState(): CredentialState;
  setState(value: CredentialState): ReputationCredential;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ReputationCredential.AsObject;
  static toObject(includeInstance: boolean, msg: ReputationCredential): ReputationCredential.AsObject;
  static serializeBinaryToWriter(message: ReputationCredential, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ReputationCredential;
  static deserializeBinaryFromReader(message: ReputationCredential, reader: jspb.BinaryReader): ReputationCredential;
}

export namespace ReputationCredential {
  export type AsObject = {
    issuerPublicKey: string,
    profilePublicKey: string,
    hcsCredentialMessageHash: string,
    issueTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    state: CredentialState,
  }
}

export class XPToken extends jspb.Message {
  getIssuerPublicKey(): string;
  setIssuerPublicKey(value: string): XPToken;

  getProfilePublicKey(): string;
  setProfilePublicKey(value: string): XPToken;

  getAmount(): number;
  setAmount(value: number): XPToken;

  getIssueTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setIssueTime(value?: google_protobuf_timestamp_pb.Timestamp): XPToken;
  hasIssueTime(): boolean;
  clearIssueTime(): XPToken;

  getState(): CredentialState;
  setState(value: CredentialState): XPToken;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): XPToken.AsObject;
  static toObject(includeInstance: boolean, msg: XPToken): XPToken.AsObject;
  static serializeBinaryToWriter(message: XPToken, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): XPToken;
  static deserializeBinaryFromReader(message: XPToken, reader: jspb.BinaryReader): XPToken;
}

export namespace XPToken {
  export type AsObject = {
    issuerPublicKey: string,
    profilePublicKey: string,
    amount: number,
    issueTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    state: CredentialState,
  }
}

export class Connector extends jspb.Message {
  getName(): string;
  setName(value: string): Connector;

  getDisplayName(): string;
  setDisplayName(value: string): Connector;

  getExternalUserId(): string;
  setExternalUserId(value: string): Connector;

  getAccessToken(): string;
  setAccessToken(value: string): Connector;

  getRefreshToken(): string;
  setRefreshToken(value: string): Connector;

  getExpiryTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setExpiryTime(value?: google_protobuf_timestamp_pb.Timestamp): Connector;
  hasExpiryTime(): boolean;
  clearExpiryTime(): Connector;

  getCreateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreateTime(value?: google_protobuf_timestamp_pb.Timestamp): Connector;
  hasCreateTime(): boolean;
  clearCreateTime(): Connector;

  getUpdateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setUpdateTime(value?: google_protobuf_timestamp_pb.Timestamp): Connector;
  hasUpdateTime(): boolean;
  clearUpdateTime(): Connector;

  getDeleteTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setDeleteTime(value?: google_protobuf_timestamp_pb.Timestamp): Connector;
  hasDeleteTime(): boolean;
  clearDeleteTime(): Connector;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Connector.AsObject;
  static toObject(includeInstance: boolean, msg: Connector): Connector.AsObject;
  static serializeBinaryToWriter(message: Connector, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Connector;
  static deserializeBinaryFromReader(message: Connector, reader: jspb.BinaryReader): Connector;
}

export namespace Connector {
  export type AsObject = {
    name: string,
    displayName: string,
    externalUserId: string,
    accessToken: string,
    refreshToken: string,
    expiryTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    createTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    updateTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    deleteTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }
}

export class CreateUserRequest extends jspb.Message {
  getUser(): User | undefined;
  setUser(value?: User): CreateUserRequest;
  hasUser(): boolean;
  clearUser(): CreateUserRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateUserRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateUserRequest): CreateUserRequest.AsObject;
  static serializeBinaryToWriter(message: CreateUserRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateUserRequest;
  static deserializeBinaryFromReader(message: CreateUserRequest, reader: jspb.BinaryReader): CreateUserRequest;
}

export namespace CreateUserRequest {
  export type AsObject = {
    user?: User.AsObject,
  }
}

export class GetUserRequest extends jspb.Message {
  getName(): string;
  setName(value: string): GetUserRequest;

  getView(): UserView;
  setView(value: UserView): GetUserRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): GetUserRequest;
  hasReadMask(): boolean;
  clearReadMask(): GetUserRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetUserRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetUserRequest): GetUserRequest.AsObject;
  static serializeBinaryToWriter(message: GetUserRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetUserRequest;
  static deserializeBinaryFromReader(message: GetUserRequest, reader: jspb.BinaryReader): GetUserRequest;
}

export namespace GetUserRequest {
  export type AsObject = {
    name: string,
    view: UserView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class UpdateUserRequest extends jspb.Message {
  getUser(): User | undefined;
  setUser(value?: User): UpdateUserRequest;
  hasUser(): boolean;
  clearUser(): UpdateUserRequest;

  getUpdateMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setUpdateMask(value?: google_protobuf_field_mask_pb.FieldMask): UpdateUserRequest;
  hasUpdateMask(): boolean;
  clearUpdateMask(): UpdateUserRequest;

  getAllowMissing(): boolean;
  setAllowMissing(value: boolean): UpdateUserRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateUserRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateUserRequest): UpdateUserRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateUserRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateUserRequest;
  static deserializeBinaryFromReader(message: UpdateUserRequest, reader: jspb.BinaryReader): UpdateUserRequest;
}

export namespace UpdateUserRequest {
  export type AsObject = {
    user?: User.AsObject,
    updateMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    allowMissing: boolean,
  }
}

export class DeleteUserRequest extends jspb.Message {
  getName(): string;
  setName(value: string): DeleteUserRequest;

  getEtag(): string;
  setEtag(value: string): DeleteUserRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteUserRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteUserRequest): DeleteUserRequest.AsObject;
  static serializeBinaryToWriter(message: DeleteUserRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteUserRequest;
  static deserializeBinaryFromReader(message: DeleteUserRequest, reader: jspb.BinaryReader): DeleteUserRequest;
}

export namespace DeleteUserRequest {
  export type AsObject = {
    name: string,
    etag: string,
  }
}

export class UndeleteUserRequest extends jspb.Message {
  getName(): string;
  setName(value: string): UndeleteUserRequest;

  getEtag(): string;
  setEtag(value: string): UndeleteUserRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UndeleteUserRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UndeleteUserRequest): UndeleteUserRequest.AsObject;
  static serializeBinaryToWriter(message: UndeleteUserRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UndeleteUserRequest;
  static deserializeBinaryFromReader(message: UndeleteUserRequest, reader: jspb.BinaryReader): UndeleteUserRequest;
}

export namespace UndeleteUserRequest {
  export type AsObject = {
    name: string,
    etag: string,
  }
}

export class ListUsersRequest extends jspb.Message {
  getPageSize(): number;
  setPageSize(value: number): ListUsersRequest;

  getPageToken(): string;
  setPageToken(value: string): ListUsersRequest;

  getView(): UserView;
  setView(value: UserView): ListUsersRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): ListUsersRequest;
  hasReadMask(): boolean;
  clearReadMask(): ListUsersRequest;

  getFilter(): string;
  setFilter(value: string): ListUsersRequest;

  getOrderBy(): string;
  setOrderBy(value: string): ListUsersRequest;

  getShowDeleted(): boolean;
  setShowDeleted(value: boolean): ListUsersRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListUsersRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListUsersRequest): ListUsersRequest.AsObject;
  static serializeBinaryToWriter(message: ListUsersRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListUsersRequest;
  static deserializeBinaryFromReader(message: ListUsersRequest, reader: jspb.BinaryReader): ListUsersRequest;
}

export namespace ListUsersRequest {
  export type AsObject = {
    pageSize: number,
    pageToken: string,
    view: UserView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
    orderBy: string,
    showDeleted: boolean,
  }
}

export class ListUsersResponse extends jspb.Message {
  getUsersList(): Array<User>;
  setUsersList(value: Array<User>): ListUsersResponse;
  clearUsersList(): ListUsersResponse;
  addUsers(value?: User, index?: number): User;

  getNextPageToken(): string;
  setNextPageToken(value: string): ListUsersResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListUsersResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListUsersResponse): ListUsersResponse.AsObject;
  static serializeBinaryToWriter(message: ListUsersResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListUsersResponse;
  static deserializeBinaryFromReader(message: ListUsersResponse, reader: jspb.BinaryReader): ListUsersResponse;
}

export namespace ListUsersResponse {
  export type AsObject = {
    usersList: Array<User.AsObject>,
    nextPageToken: string,
  }
}

export class BatchGetUsersRequest extends jspb.Message {
  getNamesList(): Array<string>;
  setNamesList(value: Array<string>): BatchGetUsersRequest;
  clearNamesList(): BatchGetUsersRequest;
  addNames(value: string, index?: number): BatchGetUsersRequest;

  getView(): UserView;
  setView(value: UserView): BatchGetUsersRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): BatchGetUsersRequest;
  hasReadMask(): boolean;
  clearReadMask(): BatchGetUsersRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchGetUsersRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchGetUsersRequest): BatchGetUsersRequest.AsObject;
  static serializeBinaryToWriter(message: BatchGetUsersRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchGetUsersRequest;
  static deserializeBinaryFromReader(message: BatchGetUsersRequest, reader: jspb.BinaryReader): BatchGetUsersRequest;
}

export namespace BatchGetUsersRequest {
  export type AsObject = {
    namesList: Array<string>,
    view: UserView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class BatchGetUsersResponse extends jspb.Message {
  getUsersList(): Array<User>;
  setUsersList(value: Array<User>): BatchGetUsersResponse;
  clearUsersList(): BatchGetUsersResponse;
  addUsers(value?: User, index?: number): User;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchGetUsersResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchGetUsersResponse): BatchGetUsersResponse.AsObject;
  static serializeBinaryToWriter(message: BatchGetUsersResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchGetUsersResponse;
  static deserializeBinaryFromReader(message: BatchGetUsersResponse, reader: jspb.BinaryReader): BatchGetUsersResponse;
}

export namespace BatchGetUsersResponse {
  export type AsObject = {
    usersList: Array<User.AsObject>,
  }
}

export class BatchDeleteUsersRequest extends jspb.Message {
  getRequestsList(): Array<DeleteUserRequest>;
  setRequestsList(value: Array<DeleteUserRequest>): BatchDeleteUsersRequest;
  clearRequestsList(): BatchDeleteUsersRequest;
  addRequests(value?: DeleteUserRequest, index?: number): DeleteUserRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchDeleteUsersRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchDeleteUsersRequest): BatchDeleteUsersRequest.AsObject;
  static serializeBinaryToWriter(message: BatchDeleteUsersRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchDeleteUsersRequest;
  static deserializeBinaryFromReader(message: BatchDeleteUsersRequest, reader: jspb.BinaryReader): BatchDeleteUsersRequest;
}

export namespace BatchDeleteUsersRequest {
  export type AsObject = {
    requestsList: Array<DeleteUserRequest.AsObject>,
  }
}

export class BatchDeleteUsersResponse extends jspb.Message {
  getUsersList(): Array<User>;
  setUsersList(value: Array<User>): BatchDeleteUsersResponse;
  clearUsersList(): BatchDeleteUsersResponse;
  addUsers(value?: User, index?: number): User;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchDeleteUsersResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchDeleteUsersResponse): BatchDeleteUsersResponse.AsObject;
  static serializeBinaryToWriter(message: BatchDeleteUsersResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchDeleteUsersResponse;
  static deserializeBinaryFromReader(message: BatchDeleteUsersResponse, reader: jspb.BinaryReader): BatchDeleteUsersResponse;
}

export namespace BatchDeleteUsersResponse {
  export type AsObject = {
    usersList: Array<User.AsObject>,
  }
}

export class StreamUsersRequest extends jspb.Message {
  getView(): UserView;
  setView(value: UserView): StreamUsersRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): StreamUsersRequest;
  hasReadMask(): boolean;
  clearReadMask(): StreamUsersRequest;

  getFilter(): string;
  setFilter(value: string): StreamUsersRequest;

  getOrderBy(): string;
  setOrderBy(value: string): StreamUsersRequest;

  getShowDeleted(): boolean;
  setShowDeleted(value: boolean): StreamUsersRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StreamUsersRequest.AsObject;
  static toObject(includeInstance: boolean, msg: StreamUsersRequest): StreamUsersRequest.AsObject;
  static serializeBinaryToWriter(message: StreamUsersRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StreamUsersRequest;
  static deserializeBinaryFromReader(message: StreamUsersRequest, reader: jspb.BinaryReader): StreamUsersRequest;
}

export namespace StreamUsersRequest {
  export type AsObject = {
    view: UserView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
    orderBy: string,
    showDeleted: boolean,
  }
}

export class RetrieveUserByEmailRequest extends jspb.Message {
  getEmail(): string;
  setEmail(value: string): RetrieveUserByEmailRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): RetrieveUserByEmailRequest;
  hasReadMask(): boolean;
  clearReadMask(): RetrieveUserByEmailRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RetrieveUserByEmailRequest.AsObject;
  static toObject(includeInstance: boolean, msg: RetrieveUserByEmailRequest): RetrieveUserByEmailRequest.AsObject;
  static serializeBinaryToWriter(message: RetrieveUserByEmailRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RetrieveUserByEmailRequest;
  static deserializeBinaryFromReader(message: RetrieveUserByEmailRequest, reader: jspb.BinaryReader): RetrieveUserByEmailRequest;
}

export namespace RetrieveUserByEmailRequest {
  export type AsObject = {
    email: string,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class BatchRetrieveMaskedUsersRequest extends jspb.Message {
  getUsersList(): Array<string>;
  setUsersList(value: Array<string>): BatchRetrieveMaskedUsersRequest;
  clearUsersList(): BatchRetrieveMaskedUsersRequest;
  addUsers(value: string, index?: number): BatchRetrieveMaskedUsersRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): BatchRetrieveMaskedUsersRequest;
  hasReadMask(): boolean;
  clearReadMask(): BatchRetrieveMaskedUsersRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchRetrieveMaskedUsersRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchRetrieveMaskedUsersRequest): BatchRetrieveMaskedUsersRequest.AsObject;
  static serializeBinaryToWriter(message: BatchRetrieveMaskedUsersRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchRetrieveMaskedUsersRequest;
  static deserializeBinaryFromReader(message: BatchRetrieveMaskedUsersRequest, reader: jspb.BinaryReader): BatchRetrieveMaskedUsersRequest;
}

export namespace BatchRetrieveMaskedUsersRequest {
  export type AsObject = {
    usersList: Array<string>,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class BatchRetrieveMaskedUsersResponse extends jspb.Message {
  getMaskedUsersList(): Array<MaskedUser>;
  setMaskedUsersList(value: Array<MaskedUser>): BatchRetrieveMaskedUsersResponse;
  clearMaskedUsersList(): BatchRetrieveMaskedUsersResponse;
  addMaskedUsers(value?: MaskedUser, index?: number): MaskedUser;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchRetrieveMaskedUsersResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchRetrieveMaskedUsersResponse): BatchRetrieveMaskedUsersResponse.AsObject;
  static serializeBinaryToWriter(message: BatchRetrieveMaskedUsersResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchRetrieveMaskedUsersResponse;
  static deserializeBinaryFromReader(message: BatchRetrieveMaskedUsersResponse, reader: jspb.BinaryReader): BatchRetrieveMaskedUsersResponse;
}

export namespace BatchRetrieveMaskedUsersResponse {
  export type AsObject = {
    maskedUsersList: Array<MaskedUser.AsObject>,
  }
}

export class LookupUserRequest extends jspb.Message {
  getSearchText(): string;
  setSearchText(value: string): LookupUserRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LookupUserRequest.AsObject;
  static toObject(includeInstance: boolean, msg: LookupUserRequest): LookupUserRequest.AsObject;
  static serializeBinaryToWriter(message: LookupUserRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LookupUserRequest;
  static deserializeBinaryFromReader(message: LookupUserRequest, reader: jspb.BinaryReader): LookupUserRequest;
}

export namespace LookupUserRequest {
  export type AsObject = {
    searchText: string,
  }
}

export class LookupUserResponse extends jspb.Message {
  getResultsList(): Array<LookupUserResponse.Result>;
  setResultsList(value: Array<LookupUserResponse.Result>): LookupUserResponse;
  clearResultsList(): LookupUserResponse;
  addResults(value?: LookupUserResponse.Result, index?: number): LookupUserResponse.Result;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LookupUserResponse.AsObject;
  static toObject(includeInstance: boolean, msg: LookupUserResponse): LookupUserResponse.AsObject;
  static serializeBinaryToWriter(message: LookupUserResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LookupUserResponse;
  static deserializeBinaryFromReader(message: LookupUserResponse, reader: jspb.BinaryReader): LookupUserResponse;
}

export namespace LookupUserResponse {
  export type AsObject = {
    resultsList: Array<LookupUserResponse.Result.AsObject>,
  }

  export class Result extends jspb.Message {
    getUser(): string;
    setUser(value: string): Result;

    getDisplayName(): string;
    setDisplayName(value: string): Result;

    getMaskedEmail(): string;
    setMaskedEmail(value: string): Result;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Result.AsObject;
    static toObject(includeInstance: boolean, msg: Result): Result.AsObject;
    static serializeBinaryToWriter(message: Result, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Result;
    static deserializeBinaryFromReader(message: Result, reader: jspb.BinaryReader): Result;
  }

  export namespace Result {
    export type AsObject = {
      user: string,
      displayName: string,
      maskedEmail: string,
    }
  }

}

export class RetrieveMaskedUsersRequest extends jspb.Message {
  getPageSize(): number;
  setPageSize(value: number): RetrieveMaskedUsersRequest;

  getPageToken(): string;
  setPageToken(value: string): RetrieveMaskedUsersRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): RetrieveMaskedUsersRequest;
  hasReadMask(): boolean;
  clearReadMask(): RetrieveMaskedUsersRequest;

  getFilter(): string;
  setFilter(value: string): RetrieveMaskedUsersRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RetrieveMaskedUsersRequest.AsObject;
  static toObject(includeInstance: boolean, msg: RetrieveMaskedUsersRequest): RetrieveMaskedUsersRequest.AsObject;
  static serializeBinaryToWriter(message: RetrieveMaskedUsersRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RetrieveMaskedUsersRequest;
  static deserializeBinaryFromReader(message: RetrieveMaskedUsersRequest, reader: jspb.BinaryReader): RetrieveMaskedUsersRequest;
}

export namespace RetrieveMaskedUsersRequest {
  export type AsObject = {
    pageSize: number,
    pageToken: string,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
  }
}

export class RetrieveMaskedUsersResponse extends jspb.Message {
  getUsersList(): Array<MaskedUser>;
  setUsersList(value: Array<MaskedUser>): RetrieveMaskedUsersResponse;
  clearUsersList(): RetrieveMaskedUsersResponse;
  addUsers(value?: MaskedUser, index?: number): MaskedUser;

  getNextPageToken(): string;
  setNextPageToken(value: string): RetrieveMaskedUsersResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RetrieveMaskedUsersResponse.AsObject;
  static toObject(includeInstance: boolean, msg: RetrieveMaskedUsersResponse): RetrieveMaskedUsersResponse.AsObject;
  static serializeBinaryToWriter(message: RetrieveMaskedUsersResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RetrieveMaskedUsersResponse;
  static deserializeBinaryFromReader(message: RetrieveMaskedUsersResponse, reader: jspb.BinaryReader): RetrieveMaskedUsersResponse;
}

export namespace RetrieveMaskedUsersResponse {
  export type AsObject = {
    usersList: Array<MaskedUser.AsObject>,
    nextPageToken: string,
  }
}

export class RetrieveMaskedUserRequest extends jspb.Message {
  getUser(): string;
  setUser(value: string): RetrieveMaskedUserRequest;

  getEmail(): string;
  setEmail(value: string): RetrieveMaskedUserRequest;

  getIdentifierCase(): RetrieveMaskedUserRequest.IdentifierCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RetrieveMaskedUserRequest.AsObject;
  static toObject(includeInstance: boolean, msg: RetrieveMaskedUserRequest): RetrieveMaskedUserRequest.AsObject;
  static serializeBinaryToWriter(message: RetrieveMaskedUserRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RetrieveMaskedUserRequest;
  static deserializeBinaryFromReader(message: RetrieveMaskedUserRequest, reader: jspb.BinaryReader): RetrieveMaskedUserRequest;
}

export namespace RetrieveMaskedUserRequest {
  export type AsObject = {
    user: string,
    email: string,
  }

  export enum IdentifierCase { 
    IDENTIFIER_NOT_SET = 0,
    USER = 1,
    EMAIL = 2,
  }
}

export class MaskedUser extends jspb.Message {
  getName(): string;
  setName(value: string): MaskedUser;

  getCreateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreateTime(value?: google_protobuf_timestamp_pb.Timestamp): MaskedUser;
  hasCreateTime(): boolean;
  clearCreateTime(): MaskedUser;

  getUpdateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setUpdateTime(value?: google_protobuf_timestamp_pb.Timestamp): MaskedUser;
  hasUpdateTime(): boolean;
  clearUpdateTime(): MaskedUser;

  getMaskedEmail(): string;
  setMaskedEmail(value: string): MaskedUser;

  getIdentityProvider(): IdentityProvider;
  setIdentityProvider(value: IdentityProvider): MaskedUser;

  getGivenName(): string;
  setGivenName(value: string): MaskedUser;

  getFamilyName(): string;
  setFamilyName(value: string): MaskedUser;

  getPicture(): string;
  setPicture(value: string): MaskedUser;

  getPosition(): string;
  setPosition(value: string): MaskedUser;

  getEducation(): string;
  setEducation(value: string): MaskedUser;

  getLinkedinUri(): string;
  setLinkedinUri(value: string): MaskedUser;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MaskedUser.AsObject;
  static toObject(includeInstance: boolean, msg: MaskedUser): MaskedUser.AsObject;
  static serializeBinaryToWriter(message: MaskedUser, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MaskedUser;
  static deserializeBinaryFromReader(message: MaskedUser, reader: jspb.BinaryReader): MaskedUser;
}

export namespace MaskedUser {
  export type AsObject = {
    name: string,
    createTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    updateTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    maskedEmail: string,
    identityProvider: IdentityProvider,
    givenName: string,
    familyName: string,
    picture: string,
    position: string,
    education: string,
    linkedinUri: string,
  }
}

export class EditUserInfoRequest extends jspb.Message {
  getUser(): string;
  setUser(value: string): EditUserInfoRequest;

  getGivenName(): string;
  setGivenName(value: string): EditUserInfoRequest;

  getFamilyName(): string;
  setFamilyName(value: string): EditUserInfoRequest;

  getPicture(): string;
  setPicture(value: string): EditUserInfoRequest;

  getContactNumber(): string;
  setContactNumber(value: string): EditUserInfoRequest;

  getPosition(): string;
  setPosition(value: string): EditUserInfoRequest;

  getEducation(): string;
  setEducation(value: string): EditUserInfoRequest;

  getLinkedinUri(): string;
  setLinkedinUri(value: string): EditUserInfoRequest;

  getUpdateMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setUpdateMask(value?: google_protobuf_field_mask_pb.FieldMask): EditUserInfoRequest;
  hasUpdateMask(): boolean;
  clearUpdateMask(): EditUserInfoRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): EditUserInfoRequest.AsObject;
  static toObject(includeInstance: boolean, msg: EditUserInfoRequest): EditUserInfoRequest.AsObject;
  static serializeBinaryToWriter(message: EditUserInfoRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): EditUserInfoRequest;
  static deserializeBinaryFromReader(message: EditUserInfoRequest, reader: jspb.BinaryReader): EditUserInfoRequest;
}

export namespace EditUserInfoRequest {
  export type AsObject = {
    user: string,
    givenName: string,
    familyName: string,
    picture: string,
    contactNumber: string,
    position: string,
    education: string,
    linkedinUri: string,
    updateMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class EditUserMetadataRequest extends jspb.Message {
  getUser(): string;
  setUser(value: string): EditUserMetadataRequest;

  getMetadata(): google_protobuf_any_pb.Any | undefined;
  setMetadata(value?: google_protobuf_any_pb.Any): EditUserMetadataRequest;
  hasMetadata(): boolean;
  clearMetadata(): EditUserMetadataRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): EditUserMetadataRequest.AsObject;
  static toObject(includeInstance: boolean, msg: EditUserMetadataRequest): EditUserMetadataRequest.AsObject;
  static serializeBinaryToWriter(message: EditUserMetadataRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): EditUserMetadataRequest;
  static deserializeBinaryFromReader(message: EditUserMetadataRequest, reader: jspb.BinaryReader): EditUserMetadataRequest;
}

export namespace EditUserMetadataRequest {
  export type AsObject = {
    user: string,
    metadata?: google_protobuf_any_pb.Any.AsObject,
  }
}

export class RetrieveMyUserRequest extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RetrieveMyUserRequest.AsObject;
  static toObject(includeInstance: boolean, msg: RetrieveMyUserRequest): RetrieveMyUserRequest.AsObject;
  static serializeBinaryToWriter(message: RetrieveMyUserRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RetrieveMyUserRequest;
  static deserializeBinaryFromReader(message: RetrieveMyUserRequest, reader: jspb.BinaryReader): RetrieveMyUserRequest;
}

export namespace RetrieveMyUserRequest {
  export type AsObject = {
  }
}

export class EditMyInfoRequest extends jspb.Message {
  getGivenName(): string;
  setGivenName(value: string): EditMyInfoRequest;

  getFamilyName(): string;
  setFamilyName(value: string): EditMyInfoRequest;

  getPicture(): string;
  setPicture(value: string): EditMyInfoRequest;

  getContactNumber(): string;
  setContactNumber(value: string): EditMyInfoRequest;

  getPosition(): string;
  setPosition(value: string): EditMyInfoRequest;

  getEducation(): string;
  setEducation(value: string): EditMyInfoRequest;

  getLinkedinUri(): string;
  setLinkedinUri(value: string): EditMyInfoRequest;

  getUpdateMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setUpdateMask(value?: google_protobuf_field_mask_pb.FieldMask): EditMyInfoRequest;
  hasUpdateMask(): boolean;
  clearUpdateMask(): EditMyInfoRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): EditMyInfoRequest.AsObject;
  static toObject(includeInstance: boolean, msg: EditMyInfoRequest): EditMyInfoRequest.AsObject;
  static serializeBinaryToWriter(message: EditMyInfoRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): EditMyInfoRequest;
  static deserializeBinaryFromReader(message: EditMyInfoRequest, reader: jspb.BinaryReader): EditMyInfoRequest;
}

export namespace EditMyInfoRequest {
  export type AsObject = {
    givenName: string,
    familyName: string,
    picture: string,
    contactNumber: string,
    position: string,
    education: string,
    linkedinUri: string,
    updateMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class EditMyMetadataRequest extends jspb.Message {
  getMetadata(): google_protobuf_any_pb.Any | undefined;
  setMetadata(value?: google_protobuf_any_pb.Any): EditMyMetadataRequest;
  hasMetadata(): boolean;
  clearMetadata(): EditMyMetadataRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): EditMyMetadataRequest.AsObject;
  static toObject(includeInstance: boolean, msg: EditMyMetadataRequest): EditMyMetadataRequest.AsObject;
  static serializeBinaryToWriter(message: EditMyMetadataRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): EditMyMetadataRequest;
  static deserializeBinaryFromReader(message: EditMyMetadataRequest, reader: jspb.BinaryReader): EditMyMetadataRequest;
}

export namespace EditMyMetadataRequest {
  export type AsObject = {
    metadata?: google_protobuf_any_pb.Any.AsObject,
  }
}

export class RemoveMyUserRequest extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RemoveMyUserRequest.AsObject;
  static toObject(includeInstance: boolean, msg: RemoveMyUserRequest): RemoveMyUserRequest.AsObject;
  static serializeBinaryToWriter(message: RemoveMyUserRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RemoveMyUserRequest;
  static deserializeBinaryFromReader(message: RemoveMyUserRequest, reader: jspb.BinaryReader): RemoveMyUserRequest;
}

export namespace RemoveMyUserRequest {
  export type AsObject = {
  }
}

export class SyncToGoogleGroupRequest extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SyncToGoogleGroupRequest.AsObject;
  static toObject(includeInstance: boolean, msg: SyncToGoogleGroupRequest): SyncToGoogleGroupRequest.AsObject;
  static serializeBinaryToWriter(message: SyncToGoogleGroupRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SyncToGoogleGroupRequest;
  static deserializeBinaryFromReader(message: SyncToGoogleGroupRequest, reader: jspb.BinaryReader): SyncToGoogleGroupRequest;
}

export namespace SyncToGoogleGroupRequest {
  export type AsObject = {
  }
}

export class SyncToGoogleGroupResponse extends jspb.Message {
  getNrAdded(): number;
  setNrAdded(value: number): SyncToGoogleGroupResponse;

  getNrRemoved(): number;
  setNrRemoved(value: number): SyncToGoogleGroupResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SyncToGoogleGroupResponse.AsObject;
  static toObject(includeInstance: boolean, msg: SyncToGoogleGroupResponse): SyncToGoogleGroupResponse.AsObject;
  static serializeBinaryToWriter(message: SyncToGoogleGroupResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SyncToGoogleGroupResponse;
  static deserializeBinaryFromReader(message: SyncToGoogleGroupResponse, reader: jspb.BinaryReader): SyncToGoogleGroupResponse;
}

export namespace SyncToGoogleGroupResponse {
  export type AsObject = {
    nrAdded: number,
    nrRemoved: number,
  }
}

export class SetUserPictureRequest extends jspb.Message {
  getUser(): string;
  setUser(value: string): SetUserPictureRequest;

  getData(): Uint8Array | string;
  getData_asU8(): Uint8Array;
  getData_asB64(): string;
  setData(value: Uint8Array | string): SetUserPictureRequest;

  getMimeType(): string;
  setMimeType(value: string): SetUserPictureRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SetUserPictureRequest.AsObject;
  static toObject(includeInstance: boolean, msg: SetUserPictureRequest): SetUserPictureRequest.AsObject;
  static serializeBinaryToWriter(message: SetUserPictureRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SetUserPictureRequest;
  static deserializeBinaryFromReader(message: SetUserPictureRequest, reader: jspb.BinaryReader): SetUserPictureRequest;
}

export namespace SetUserPictureRequest {
  export type AsObject = {
    user: string,
    data: Uint8Array | string,
    mimeType: string,
  }
}

export class SetUserPictureResponse extends jspb.Message {
  getPublicUri(): string;
  setPublicUri(value: string): SetUserPictureResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SetUserPictureResponse.AsObject;
  static toObject(includeInstance: boolean, msg: SetUserPictureResponse): SetUserPictureResponse.AsObject;
  static serializeBinaryToWriter(message: SetUserPictureResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SetUserPictureResponse;
  static deserializeBinaryFromReader(message: SetUserPictureResponse, reader: jspb.BinaryReader): SetUserPictureResponse;
}

export namespace SetUserPictureResponse {
  export type AsObject = {
    publicUri: string,
  }
}

export class CreateConnectorRequest extends jspb.Message {
  getParent(): string;
  setParent(value: string): CreateConnectorRequest;

  getConnector(): Connector | undefined;
  setConnector(value?: Connector): CreateConnectorRequest;
  hasConnector(): boolean;
  clearConnector(): CreateConnectorRequest;

  getConnectorId(): string;
  setConnectorId(value: string): CreateConnectorRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateConnectorRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateConnectorRequest): CreateConnectorRequest.AsObject;
  static serializeBinaryToWriter(message: CreateConnectorRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateConnectorRequest;
  static deserializeBinaryFromReader(message: CreateConnectorRequest, reader: jspb.BinaryReader): CreateConnectorRequest;
}

export namespace CreateConnectorRequest {
  export type AsObject = {
    parent: string,
    connector?: Connector.AsObject,
    connectorId: string,
  }
}

export class GetConnectorRequest extends jspb.Message {
  getName(): string;
  setName(value: string): GetConnectorRequest;

  getView(): ConnectorView;
  setView(value: ConnectorView): GetConnectorRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): GetConnectorRequest;
  hasReadMask(): boolean;
  clearReadMask(): GetConnectorRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetConnectorRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetConnectorRequest): GetConnectorRequest.AsObject;
  static serializeBinaryToWriter(message: GetConnectorRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetConnectorRequest;
  static deserializeBinaryFromReader(message: GetConnectorRequest, reader: jspb.BinaryReader): GetConnectorRequest;
}

export namespace GetConnectorRequest {
  export type AsObject = {
    name: string,
    view: ConnectorView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class UpdateConnectorRequest extends jspb.Message {
  getConnector(): Connector | undefined;
  setConnector(value?: Connector): UpdateConnectorRequest;
  hasConnector(): boolean;
  clearConnector(): UpdateConnectorRequest;

  getUpdateMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setUpdateMask(value?: google_protobuf_field_mask_pb.FieldMask): UpdateConnectorRequest;
  hasUpdateMask(): boolean;
  clearUpdateMask(): UpdateConnectorRequest;

  getAllowMissing(): boolean;
  setAllowMissing(value: boolean): UpdateConnectorRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateConnectorRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateConnectorRequest): UpdateConnectorRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateConnectorRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateConnectorRequest;
  static deserializeBinaryFromReader(message: UpdateConnectorRequest, reader: jspb.BinaryReader): UpdateConnectorRequest;
}

export namespace UpdateConnectorRequest {
  export type AsObject = {
    connector?: Connector.AsObject,
    updateMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    allowMissing: boolean,
  }
}

export class DeleteConnectorRequest extends jspb.Message {
  getName(): string;
  setName(value: string): DeleteConnectorRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteConnectorRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteConnectorRequest): DeleteConnectorRequest.AsObject;
  static serializeBinaryToWriter(message: DeleteConnectorRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteConnectorRequest;
  static deserializeBinaryFromReader(message: DeleteConnectorRequest, reader: jspb.BinaryReader): DeleteConnectorRequest;
}

export namespace DeleteConnectorRequest {
  export type AsObject = {
    name: string,
  }
}

export class UndeleteConnectorRequest extends jspb.Message {
  getName(): string;
  setName(value: string): UndeleteConnectorRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UndeleteConnectorRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UndeleteConnectorRequest): UndeleteConnectorRequest.AsObject;
  static serializeBinaryToWriter(message: UndeleteConnectorRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UndeleteConnectorRequest;
  static deserializeBinaryFromReader(message: UndeleteConnectorRequest, reader: jspb.BinaryReader): UndeleteConnectorRequest;
}

export namespace UndeleteConnectorRequest {
  export type AsObject = {
    name: string,
  }
}

export class ListConnectorsRequest extends jspb.Message {
  getParent(): string;
  setParent(value: string): ListConnectorsRequest;

  getPageSize(): number;
  setPageSize(value: number): ListConnectorsRequest;

  getPageToken(): string;
  setPageToken(value: string): ListConnectorsRequest;

  getView(): ConnectorView;
  setView(value: ConnectorView): ListConnectorsRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): ListConnectorsRequest;
  hasReadMask(): boolean;
  clearReadMask(): ListConnectorsRequest;

  getFilter(): string;
  setFilter(value: string): ListConnectorsRequest;

  getOrderBy(): string;
  setOrderBy(value: string): ListConnectorsRequest;

  getShowDeleted(): boolean;
  setShowDeleted(value: boolean): ListConnectorsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListConnectorsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListConnectorsRequest): ListConnectorsRequest.AsObject;
  static serializeBinaryToWriter(message: ListConnectorsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListConnectorsRequest;
  static deserializeBinaryFromReader(message: ListConnectorsRequest, reader: jspb.BinaryReader): ListConnectorsRequest;
}

export namespace ListConnectorsRequest {
  export type AsObject = {
    parent: string,
    pageSize: number,
    pageToken: string,
    view: ConnectorView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
    orderBy: string,
    showDeleted: boolean,
  }
}

export class ListConnectorsResponse extends jspb.Message {
  getConnectorsList(): Array<Connector>;
  setConnectorsList(value: Array<Connector>): ListConnectorsResponse;
  clearConnectorsList(): ListConnectorsResponse;
  addConnectors(value?: Connector, index?: number): Connector;

  getNextPageToken(): string;
  setNextPageToken(value: string): ListConnectorsResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListConnectorsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListConnectorsResponse): ListConnectorsResponse.AsObject;
  static serializeBinaryToWriter(message: ListConnectorsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListConnectorsResponse;
  static deserializeBinaryFromReader(message: ListConnectorsResponse, reader: jspb.BinaryReader): ListConnectorsResponse;
}

export namespace ListConnectorsResponse {
  export type AsObject = {
    connectorsList: Array<Connector.AsObject>,
    nextPageToken: string,
  }
}

export class BatchCreateConnectorsRequest extends jspb.Message {
  getParent(): string;
  setParent(value: string): BatchCreateConnectorsRequest;

  getRequestsList(): Array<CreateConnectorRequest>;
  setRequestsList(value: Array<CreateConnectorRequest>): BatchCreateConnectorsRequest;
  clearRequestsList(): BatchCreateConnectorsRequest;
  addRequests(value?: CreateConnectorRequest, index?: number): CreateConnectorRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchCreateConnectorsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchCreateConnectorsRequest): BatchCreateConnectorsRequest.AsObject;
  static serializeBinaryToWriter(message: BatchCreateConnectorsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchCreateConnectorsRequest;
  static deserializeBinaryFromReader(message: BatchCreateConnectorsRequest, reader: jspb.BinaryReader): BatchCreateConnectorsRequest;
}

export namespace BatchCreateConnectorsRequest {
  export type AsObject = {
    parent: string,
    requestsList: Array<CreateConnectorRequest.AsObject>,
  }
}

export class BatchCreateConnectorsResponse extends jspb.Message {
  getConnectorsList(): Array<Connector>;
  setConnectorsList(value: Array<Connector>): BatchCreateConnectorsResponse;
  clearConnectorsList(): BatchCreateConnectorsResponse;
  addConnectors(value?: Connector, index?: number): Connector;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchCreateConnectorsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchCreateConnectorsResponse): BatchCreateConnectorsResponse.AsObject;
  static serializeBinaryToWriter(message: BatchCreateConnectorsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchCreateConnectorsResponse;
  static deserializeBinaryFromReader(message: BatchCreateConnectorsResponse, reader: jspb.BinaryReader): BatchCreateConnectorsResponse;
}

export namespace BatchCreateConnectorsResponse {
  export type AsObject = {
    connectorsList: Array<Connector.AsObject>,
  }
}

export class BatchGetConnectorsRequest extends jspb.Message {
  getParent(): string;
  setParent(value: string): BatchGetConnectorsRequest;

  getNamesList(): Array<string>;
  setNamesList(value: Array<string>): BatchGetConnectorsRequest;
  clearNamesList(): BatchGetConnectorsRequest;
  addNames(value: string, index?: number): BatchGetConnectorsRequest;

  getView(): ConnectorView;
  setView(value: ConnectorView): BatchGetConnectorsRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): BatchGetConnectorsRequest;
  hasReadMask(): boolean;
  clearReadMask(): BatchGetConnectorsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchGetConnectorsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchGetConnectorsRequest): BatchGetConnectorsRequest.AsObject;
  static serializeBinaryToWriter(message: BatchGetConnectorsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchGetConnectorsRequest;
  static deserializeBinaryFromReader(message: BatchGetConnectorsRequest, reader: jspb.BinaryReader): BatchGetConnectorsRequest;
}

export namespace BatchGetConnectorsRequest {
  export type AsObject = {
    parent: string,
    namesList: Array<string>,
    view: ConnectorView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class BatchGetConnectorsResponse extends jspb.Message {
  getConnectorsList(): Array<Connector>;
  setConnectorsList(value: Array<Connector>): BatchGetConnectorsResponse;
  clearConnectorsList(): BatchGetConnectorsResponse;
  addConnectors(value?: Connector, index?: number): Connector;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchGetConnectorsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchGetConnectorsResponse): BatchGetConnectorsResponse.AsObject;
  static serializeBinaryToWriter(message: BatchGetConnectorsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchGetConnectorsResponse;
  static deserializeBinaryFromReader(message: BatchGetConnectorsResponse, reader: jspb.BinaryReader): BatchGetConnectorsResponse;
}

export namespace BatchGetConnectorsResponse {
  export type AsObject = {
    connectorsList: Array<Connector.AsObject>,
  }
}

export class BatchUpdateConnectorsRequest extends jspb.Message {
  getParent(): string;
  setParent(value: string): BatchUpdateConnectorsRequest;

  getRequestsList(): Array<UpdateConnectorRequest>;
  setRequestsList(value: Array<UpdateConnectorRequest>): BatchUpdateConnectorsRequest;
  clearRequestsList(): BatchUpdateConnectorsRequest;
  addRequests(value?: UpdateConnectorRequest, index?: number): UpdateConnectorRequest;

  getUpdateMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setUpdateMask(value?: google_protobuf_field_mask_pb.FieldMask): BatchUpdateConnectorsRequest;
  hasUpdateMask(): boolean;
  clearUpdateMask(): BatchUpdateConnectorsRequest;

  getAllowMissing(): boolean;
  setAllowMissing(value: boolean): BatchUpdateConnectorsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchUpdateConnectorsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchUpdateConnectorsRequest): BatchUpdateConnectorsRequest.AsObject;
  static serializeBinaryToWriter(message: BatchUpdateConnectorsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchUpdateConnectorsRequest;
  static deserializeBinaryFromReader(message: BatchUpdateConnectorsRequest, reader: jspb.BinaryReader): BatchUpdateConnectorsRequest;
}

export namespace BatchUpdateConnectorsRequest {
  export type AsObject = {
    parent: string,
    requestsList: Array<UpdateConnectorRequest.AsObject>,
    updateMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    allowMissing: boolean,
  }
}

export class BatchUpdateConnectorsResponse extends jspb.Message {
  getConnectorsList(): Array<Connector>;
  setConnectorsList(value: Array<Connector>): BatchUpdateConnectorsResponse;
  clearConnectorsList(): BatchUpdateConnectorsResponse;
  addConnectors(value?: Connector, index?: number): Connector;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchUpdateConnectorsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchUpdateConnectorsResponse): BatchUpdateConnectorsResponse.AsObject;
  static serializeBinaryToWriter(message: BatchUpdateConnectorsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchUpdateConnectorsResponse;
  static deserializeBinaryFromReader(message: BatchUpdateConnectorsResponse, reader: jspb.BinaryReader): BatchUpdateConnectorsResponse;
}

export namespace BatchUpdateConnectorsResponse {
  export type AsObject = {
    connectorsList: Array<Connector.AsObject>,
  }
}

export class BatchDeleteConnectorsRequest extends jspb.Message {
  getParent(): string;
  setParent(value: string): BatchDeleteConnectorsRequest;

  getRequestsList(): Array<DeleteConnectorRequest>;
  setRequestsList(value: Array<DeleteConnectorRequest>): BatchDeleteConnectorsRequest;
  clearRequestsList(): BatchDeleteConnectorsRequest;
  addRequests(value?: DeleteConnectorRequest, index?: number): DeleteConnectorRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchDeleteConnectorsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchDeleteConnectorsRequest): BatchDeleteConnectorsRequest.AsObject;
  static serializeBinaryToWriter(message: BatchDeleteConnectorsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchDeleteConnectorsRequest;
  static deserializeBinaryFromReader(message: BatchDeleteConnectorsRequest, reader: jspb.BinaryReader): BatchDeleteConnectorsRequest;
}

export namespace BatchDeleteConnectorsRequest {
  export type AsObject = {
    parent: string,
    requestsList: Array<DeleteConnectorRequest.AsObject>,
  }
}

export class BatchDeleteConnectorsResponse extends jspb.Message {
  getConnectorsList(): Array<Connector>;
  setConnectorsList(value: Array<Connector>): BatchDeleteConnectorsResponse;
  clearConnectorsList(): BatchDeleteConnectorsResponse;
  addConnectors(value?: Connector, index?: number): Connector;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchDeleteConnectorsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchDeleteConnectorsResponse): BatchDeleteConnectorsResponse.AsObject;
  static serializeBinaryToWriter(message: BatchDeleteConnectorsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchDeleteConnectorsResponse;
  static deserializeBinaryFromReader(message: BatchDeleteConnectorsResponse, reader: jspb.BinaryReader): BatchDeleteConnectorsResponse;
}

export namespace BatchDeleteConnectorsResponse {
  export type AsObject = {
    connectorsList: Array<Connector.AsObject>,
  }
}

export class BatchUndeleteConnectorsRequest extends jspb.Message {
  getParent(): string;
  setParent(value: string): BatchUndeleteConnectorsRequest;

  getRequestsList(): Array<UndeleteConnectorRequest>;
  setRequestsList(value: Array<UndeleteConnectorRequest>): BatchUndeleteConnectorsRequest;
  clearRequestsList(): BatchUndeleteConnectorsRequest;
  addRequests(value?: UndeleteConnectorRequest, index?: number): UndeleteConnectorRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchUndeleteConnectorsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchUndeleteConnectorsRequest): BatchUndeleteConnectorsRequest.AsObject;
  static serializeBinaryToWriter(message: BatchUndeleteConnectorsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchUndeleteConnectorsRequest;
  static deserializeBinaryFromReader(message: BatchUndeleteConnectorsRequest, reader: jspb.BinaryReader): BatchUndeleteConnectorsRequest;
}

export namespace BatchUndeleteConnectorsRequest {
  export type AsObject = {
    parent: string,
    requestsList: Array<UndeleteConnectorRequest.AsObject>,
  }
}

export class BatchUndeleteConnectorsResponse extends jspb.Message {
  getConnectorsList(): Array<Connector>;
  setConnectorsList(value: Array<Connector>): BatchUndeleteConnectorsResponse;
  clearConnectorsList(): BatchUndeleteConnectorsResponse;
  addConnectors(value?: Connector, index?: number): Connector;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchUndeleteConnectorsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchUndeleteConnectorsResponse): BatchUndeleteConnectorsResponse.AsObject;
  static serializeBinaryToWriter(message: BatchUndeleteConnectorsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchUndeleteConnectorsResponse;
  static deserializeBinaryFromReader(message: BatchUndeleteConnectorsResponse, reader: jspb.BinaryReader): BatchUndeleteConnectorsResponse;
}

export namespace BatchUndeleteConnectorsResponse {
  export type AsObject = {
    connectorsList: Array<Connector.AsObject>,
  }
}

export class StreamConnectorsRequest extends jspb.Message {
  getParent(): string;
  setParent(value: string): StreamConnectorsRequest;

  getView(): ConnectorView;
  setView(value: ConnectorView): StreamConnectorsRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): StreamConnectorsRequest;
  hasReadMask(): boolean;
  clearReadMask(): StreamConnectorsRequest;

  getFilter(): string;
  setFilter(value: string): StreamConnectorsRequest;

  getOrderBy(): string;
  setOrderBy(value: string): StreamConnectorsRequest;

  getShowDeleted(): boolean;
  setShowDeleted(value: boolean): StreamConnectorsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StreamConnectorsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: StreamConnectorsRequest): StreamConnectorsRequest.AsObject;
  static serializeBinaryToWriter(message: StreamConnectorsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StreamConnectorsRequest;
  static deserializeBinaryFromReader(message: StreamConnectorsRequest, reader: jspb.BinaryReader): StreamConnectorsRequest;
}

export namespace StreamConnectorsRequest {
  export type AsObject = {
    parent: string,
    view: ConnectorView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
    orderBy: string,
    showDeleted: boolean,
  }
}

export class FetchAccessTokenRequest extends jspb.Message {
  getConnector(): string;
  setConnector(value: string): FetchAccessTokenRequest;

  getForceRefresh(): boolean;
  setForceRefresh(value: boolean): FetchAccessTokenRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FetchAccessTokenRequest.AsObject;
  static toObject(includeInstance: boolean, msg: FetchAccessTokenRequest): FetchAccessTokenRequest.AsObject;
  static serializeBinaryToWriter(message: FetchAccessTokenRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FetchAccessTokenRequest;
  static deserializeBinaryFromReader(message: FetchAccessTokenRequest, reader: jspb.BinaryReader): FetchAccessTokenRequest;
}

export namespace FetchAccessTokenRequest {
  export type AsObject = {
    connector: string,
    forceRefresh: boolean,
  }
}

export class FetchAccessTokenResponse extends jspb.Message {
  getAccessToken(): string;
  setAccessToken(value: string): FetchAccessTokenResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FetchAccessTokenResponse.AsObject;
  static toObject(includeInstance: boolean, msg: FetchAccessTokenResponse): FetchAccessTokenResponse.AsObject;
  static serializeBinaryToWriter(message: FetchAccessTokenResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FetchAccessTokenResponse;
  static deserializeBinaryFromReader(message: FetchAccessTokenResponse, reader: jspb.BinaryReader): FetchAccessTokenResponse;
}

export namespace FetchAccessTokenResponse {
  export type AsObject = {
    accessToken: string,
  }
}

export class AuthorizeConnectorRequest extends jspb.Message {
  getConnector(): string;
  setConnector(value: string): AuthorizeConnectorRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AuthorizeConnectorRequest.AsObject;
  static toObject(includeInstance: boolean, msg: AuthorizeConnectorRequest): AuthorizeConnectorRequest.AsObject;
  static serializeBinaryToWriter(message: AuthorizeConnectorRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AuthorizeConnectorRequest;
  static deserializeBinaryFromReader(message: AuthorizeConnectorRequest, reader: jspb.BinaryReader): AuthorizeConnectorRequest;
}

export namespace AuthorizeConnectorRequest {
  export type AsObject = {
    connector: string,
  }
}

export class AuthorizeConnectorMetadata extends jspb.Message {
  getConnector(): string;
  setConnector(value: string): AuthorizeConnectorMetadata;

  getProgressNotes(): string;
  setProgressNotes(value: string): AuthorizeConnectorMetadata;

  getAuthCodeUrl(): string;
  setAuthCodeUrl(value: string): AuthorizeConnectorMetadata;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AuthorizeConnectorMetadata.AsObject;
  static toObject(includeInstance: boolean, msg: AuthorizeConnectorMetadata): AuthorizeConnectorMetadata.AsObject;
  static serializeBinaryToWriter(message: AuthorizeConnectorMetadata, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AuthorizeConnectorMetadata;
  static deserializeBinaryFromReader(message: AuthorizeConnectorMetadata, reader: jspb.BinaryReader): AuthorizeConnectorMetadata;
}

export namespace AuthorizeConnectorMetadata {
  export type AsObject = {
    connector: string,
    progressNotes: string,
    authCodeUrl: string,
  }
}

export class AuthorizeConnectorResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AuthorizeConnectorResponse.AsObject;
  static toObject(includeInstance: boolean, msg: AuthorizeConnectorResponse): AuthorizeConnectorResponse.AsObject;
  static serializeBinaryToWriter(message: AuthorizeConnectorResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AuthorizeConnectorResponse;
  static deserializeBinaryFromReader(message: AuthorizeConnectorResponse, reader: jspb.BinaryReader): AuthorizeConnectorResponse;
}

export namespace AuthorizeConnectorResponse {
  export type AsObject = {
  }
}

export class RevokeConnectorRequest extends jspb.Message {
  getConnector(): string;
  setConnector(value: string): RevokeConnectorRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RevokeConnectorRequest.AsObject;
  static toObject(includeInstance: boolean, msg: RevokeConnectorRequest): RevokeConnectorRequest.AsObject;
  static serializeBinaryToWriter(message: RevokeConnectorRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RevokeConnectorRequest;
  static deserializeBinaryFromReader(message: RevokeConnectorRequest, reader: jspb.BinaryReader): RevokeConnectorRequest;
}

export namespace RevokeConnectorRequest {
  export type AsObject = {
    connector: string,
  }
}

export class RevokeConnectorResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RevokeConnectorResponse.AsObject;
  static toObject(includeInstance: boolean, msg: RevokeConnectorResponse): RevokeConnectorResponse.AsObject;
  static serializeBinaryToWriter(message: RevokeConnectorResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RevokeConnectorResponse;
  static deserializeBinaryFromReader(message: RevokeConnectorResponse, reader: jspb.BinaryReader): RevokeConnectorResponse;
}

export namespace RevokeConnectorResponse {
  export type AsObject = {
  }
}

export class ListMyAvailableConnectorsRequest extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListMyAvailableConnectorsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListMyAvailableConnectorsRequest): ListMyAvailableConnectorsRequest.AsObject;
  static serializeBinaryToWriter(message: ListMyAvailableConnectorsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListMyAvailableConnectorsRequest;
  static deserializeBinaryFromReader(message: ListMyAvailableConnectorsRequest, reader: jspb.BinaryReader): ListMyAvailableConnectorsRequest;
}

export namespace ListMyAvailableConnectorsRequest {
  export type AsObject = {
  }
}

export class ListMyAvailableConnectorsResponse extends jspb.Message {
  getConnectorSummariesList(): Array<ListMyAvailableConnectorsResponse.ConnectorSummary>;
  setConnectorSummariesList(value: Array<ListMyAvailableConnectorsResponse.ConnectorSummary>): ListMyAvailableConnectorsResponse;
  clearConnectorSummariesList(): ListMyAvailableConnectorsResponse;
  addConnectorSummaries(value?: ListMyAvailableConnectorsResponse.ConnectorSummary, index?: number): ListMyAvailableConnectorsResponse.ConnectorSummary;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListMyAvailableConnectorsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListMyAvailableConnectorsResponse): ListMyAvailableConnectorsResponse.AsObject;
  static serializeBinaryToWriter(message: ListMyAvailableConnectorsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListMyAvailableConnectorsResponse;
  static deserializeBinaryFromReader(message: ListMyAvailableConnectorsResponse, reader: jspb.BinaryReader): ListMyAvailableConnectorsResponse;
}

export namespace ListMyAvailableConnectorsResponse {
  export type AsObject = {
    connectorSummariesList: Array<ListMyAvailableConnectorsResponse.ConnectorSummary.AsObject>,
  }

  export class ConnectorSummary extends jspb.Message {
    getName(): string;
    setName(value: string): ConnectorSummary;

    getDescription(): string;
    setDescription(value: string): ConnectorSummary;

    getConnectorStatus(): ListMyAvailableConnectorsResponse.ConnectorSummary.ConnectorStatus;
    setConnectorStatus(value: ListMyAvailableConnectorsResponse.ConnectorSummary.ConnectorStatus): ConnectorSummary;

    getProvider(): string;
    setProvider(value: string): ConnectorSummary;

    getDisplayName(): string;
    setDisplayName(value: string): ConnectorSummary;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): ConnectorSummary.AsObject;
    static toObject(includeInstance: boolean, msg: ConnectorSummary): ConnectorSummary.AsObject;
    static serializeBinaryToWriter(message: ConnectorSummary, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): ConnectorSummary;
    static deserializeBinaryFromReader(message: ConnectorSummary, reader: jspb.BinaryReader): ConnectorSummary;
  }

  export namespace ConnectorSummary {
    export type AsObject = {
      name: string,
      description: string,
      connectorStatus: ListMyAvailableConnectorsResponse.ConnectorSummary.ConnectorStatus,
      provider: string,
      displayName: string,
    }

    export enum ConnectorStatus { 
      CONNECTOR_STATUS_UNSPECIFIED = 0,
      UNCONNECTED = 1,
      CONNECTED = 2,
      EXPIRED = 3,
    }
  }

}

export enum CredentialState { 
  CREDENTIAL_STATE_UNSPECIFIED = 0,
  CREDENTIAL_STATE_ACTIVE = 1,
  CREDENTIAL_STATE_REVOKED = 2,
}
export enum IdentityProvider { 
  IDENTITY_PROVIDER_UNSPECIFIED = 0,
  GOOGLE = 1,
  MICROSOFT = 2,
  EMAIL = 3,
  LINKEDIN = 4,
  APPLE = 5,
}
export enum UserView { 
  USER_VIEW_UNSPECIFIED = 0,
  USER_VIEW_BASIC = 1,
  USER_VIEW_FULL = 2,
}
export enum ConnectorView { 
  CONNECTOR_VIEW_UNSPECIFIED = 0,
  CONNECTOR_VIEW_BASIC = 1,
  CONNECTOR_VIEW_FULL = 2,
}