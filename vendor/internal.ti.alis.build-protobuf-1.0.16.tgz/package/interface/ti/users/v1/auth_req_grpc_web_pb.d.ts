import * as grpcWeb from 'grpc-web';

import * as interface_ti_users_v1_auth_req_pb from '../../../../interface/ti/users/v1/auth_req_pb'; // proto import: "interface/ti/users/v1/auth_req.proto"


export class AuthReqsServiceClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  createAuthReq(
    request: interface_ti_users_v1_auth_req_pb.CreateAuthReqRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_req_pb.AuthReq) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_req_pb.AuthReq>;

  getAuthReq(
    request: interface_ti_users_v1_auth_req_pb.GetAuthReqRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_req_pb.AuthReq) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_req_pb.AuthReq>;

  updateAuthReq(
    request: interface_ti_users_v1_auth_req_pb.UpdateAuthReqRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_req_pb.AuthReq) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_req_pb.AuthReq>;

  listAuthReqs(
    request: interface_ti_users_v1_auth_req_pb.ListAuthReqsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_req_pb.ListAuthReqsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_req_pb.ListAuthReqsResponse>;

  deleteAuthReq(
    request: interface_ti_users_v1_auth_req_pb.DeleteAuthReqRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_req_pb.AuthReq) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_req_pb.AuthReq>;

  batchGetAuthReqs(
    request: interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsResponse>;

  batchDeleteAuthReqs(
    request: interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsResponse>;

  streamAuthReqs(
    request: interface_ti_users_v1_auth_req_pb.StreamAuthReqsRequest,
    metadata?: grpcWeb.Metadata
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_req_pb.AuthReq>;

}

export class AuthReqsServicePromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  createAuthReq(
    request: interface_ti_users_v1_auth_req_pb.CreateAuthReqRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_req_pb.AuthReq>;

  getAuthReq(
    request: interface_ti_users_v1_auth_req_pb.GetAuthReqRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_req_pb.AuthReq>;

  updateAuthReq(
    request: interface_ti_users_v1_auth_req_pb.UpdateAuthReqRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_req_pb.AuthReq>;

  listAuthReqs(
    request: interface_ti_users_v1_auth_req_pb.ListAuthReqsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_req_pb.ListAuthReqsResponse>;

  deleteAuthReq(
    request: interface_ti_users_v1_auth_req_pb.DeleteAuthReqRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_req_pb.AuthReq>;

  batchGetAuthReqs(
    request: interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsResponse>;

  batchDeleteAuthReqs(
    request: interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsResponse>;

  streamAuthReqs(
    request: interface_ti_users_v1_auth_req_pb.StreamAuthReqsRequest,
    metadata?: grpcWeb.Metadata
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_req_pb.AuthReq>;

}
