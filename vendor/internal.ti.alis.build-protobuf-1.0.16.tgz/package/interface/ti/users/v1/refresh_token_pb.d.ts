import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb'; // proto import: "google/protobuf/timestamp.proto"
import * as google_protobuf_field_mask_pb from 'google-protobuf/google/protobuf/field_mask_pb'; // proto import: "google/protobuf/field_mask.proto"


export class RefreshToken extends jspb.Message {
  getName(): string;
  setName(value: string): RefreshToken;

  getUser(): string;
  setUser(value: string): RefreshToken;

  getExpiryTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setExpiryTime(value?: google_protobuf_timestamp_pb.Timestamp): RefreshToken;
  hasExpiryTime(): boolean;
  clearExpiryTime(): RefreshToken;

  getClientId(): string;
  setClientId(value: string): RefreshToken;

  getScopesList(): Array<string>;
  setScopesList(value: Array<string>): RefreshToken;
  clearScopesList(): RefreshToken;
  addScopes(value: string, index?: number): RefreshToken;

  getEtag(): string;
  setEtag(value: string): RefreshToken;

  getCreateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreateTime(value?: google_protobuf_timestamp_pb.Timestamp): RefreshToken;
  hasCreateTime(): boolean;
  clearCreateTime(): RefreshToken;

  getUpdateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setUpdateTime(value?: google_protobuf_timestamp_pb.Timestamp): RefreshToken;
  hasUpdateTime(): boolean;
  clearUpdateTime(): RefreshToken;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RefreshToken.AsObject;
  static toObject(includeInstance: boolean, msg: RefreshToken): RefreshToken.AsObject;
  static serializeBinaryToWriter(message: RefreshToken, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RefreshToken;
  static deserializeBinaryFromReader(message: RefreshToken, reader: jspb.BinaryReader): RefreshToken;
}

export namespace RefreshToken {
  export type AsObject = {
    name: string,
    user: string,
    expiryTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    clientId: string,
    scopesList: Array<string>,
    etag: string,
    createTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    updateTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }
}

export class CreateRefreshTokenRequest extends jspb.Message {
  getRefreshToken(): RefreshToken | undefined;
  setRefreshToken(value?: RefreshToken): CreateRefreshTokenRequest;
  hasRefreshToken(): boolean;
  clearRefreshToken(): CreateRefreshTokenRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateRefreshTokenRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateRefreshTokenRequest): CreateRefreshTokenRequest.AsObject;
  static serializeBinaryToWriter(message: CreateRefreshTokenRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateRefreshTokenRequest;
  static deserializeBinaryFromReader(message: CreateRefreshTokenRequest, reader: jspb.BinaryReader): CreateRefreshTokenRequest;
}

export namespace CreateRefreshTokenRequest {
  export type AsObject = {
    refreshToken?: RefreshToken.AsObject,
  }
}

export class GetRefreshTokenRequest extends jspb.Message {
  getName(): string;
  setName(value: string): GetRefreshTokenRequest;

  getView(): RefreshTokenView;
  setView(value: RefreshTokenView): GetRefreshTokenRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): GetRefreshTokenRequest;
  hasReadMask(): boolean;
  clearReadMask(): GetRefreshTokenRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetRefreshTokenRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetRefreshTokenRequest): GetRefreshTokenRequest.AsObject;
  static serializeBinaryToWriter(message: GetRefreshTokenRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetRefreshTokenRequest;
  static deserializeBinaryFromReader(message: GetRefreshTokenRequest, reader: jspb.BinaryReader): GetRefreshTokenRequest;
}

export namespace GetRefreshTokenRequest {
  export type AsObject = {
    name: string,
    view: RefreshTokenView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class UpdateRefreshTokenRequest extends jspb.Message {
  getRefreshToken(): RefreshToken | undefined;
  setRefreshToken(value?: RefreshToken): UpdateRefreshTokenRequest;
  hasRefreshToken(): boolean;
  clearRefreshToken(): UpdateRefreshTokenRequest;

  getUpdateMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setUpdateMask(value?: google_protobuf_field_mask_pb.FieldMask): UpdateRefreshTokenRequest;
  hasUpdateMask(): boolean;
  clearUpdateMask(): UpdateRefreshTokenRequest;

  getAllowMissing(): boolean;
  setAllowMissing(value: boolean): UpdateRefreshTokenRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateRefreshTokenRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateRefreshTokenRequest): UpdateRefreshTokenRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateRefreshTokenRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateRefreshTokenRequest;
  static deserializeBinaryFromReader(message: UpdateRefreshTokenRequest, reader: jspb.BinaryReader): UpdateRefreshTokenRequest;
}

export namespace UpdateRefreshTokenRequest {
  export type AsObject = {
    refreshToken?: RefreshToken.AsObject,
    updateMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    allowMissing: boolean,
  }
}

export class DeleteRefreshTokenRequest extends jspb.Message {
  getName(): string;
  setName(value: string): DeleteRefreshTokenRequest;

  getEtag(): string;
  setEtag(value: string): DeleteRefreshTokenRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteRefreshTokenRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteRefreshTokenRequest): DeleteRefreshTokenRequest.AsObject;
  static serializeBinaryToWriter(message: DeleteRefreshTokenRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteRefreshTokenRequest;
  static deserializeBinaryFromReader(message: DeleteRefreshTokenRequest, reader: jspb.BinaryReader): DeleteRefreshTokenRequest;
}

export namespace DeleteRefreshTokenRequest {
  export type AsObject = {
    name: string,
    etag: string,
  }
}

export class ListRefreshTokensRequest extends jspb.Message {
  getPageSize(): number;
  setPageSize(value: number): ListRefreshTokensRequest;

  getPageToken(): string;
  setPageToken(value: string): ListRefreshTokensRequest;

  getView(): RefreshTokenView;
  setView(value: RefreshTokenView): ListRefreshTokensRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): ListRefreshTokensRequest;
  hasReadMask(): boolean;
  clearReadMask(): ListRefreshTokensRequest;

  getFilter(): string;
  setFilter(value: string): ListRefreshTokensRequest;

  getOrderBy(): string;
  setOrderBy(value: string): ListRefreshTokensRequest;

  getShowDeleted(): boolean;
  setShowDeleted(value: boolean): ListRefreshTokensRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListRefreshTokensRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListRefreshTokensRequest): ListRefreshTokensRequest.AsObject;
  static serializeBinaryToWriter(message: ListRefreshTokensRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListRefreshTokensRequest;
  static deserializeBinaryFromReader(message: ListRefreshTokensRequest, reader: jspb.BinaryReader): ListRefreshTokensRequest;
}

export namespace ListRefreshTokensRequest {
  export type AsObject = {
    pageSize: number,
    pageToken: string,
    view: RefreshTokenView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
    orderBy: string,
    showDeleted: boolean,
  }
}

export class ListRefreshTokensResponse extends jspb.Message {
  getRefreshTokensList(): Array<RefreshToken>;
  setRefreshTokensList(value: Array<RefreshToken>): ListRefreshTokensResponse;
  clearRefreshTokensList(): ListRefreshTokensResponse;
  addRefreshTokens(value?: RefreshToken, index?: number): RefreshToken;

  getNextPageToken(): string;
  setNextPageToken(value: string): ListRefreshTokensResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListRefreshTokensResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListRefreshTokensResponse): ListRefreshTokensResponse.AsObject;
  static serializeBinaryToWriter(message: ListRefreshTokensResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListRefreshTokensResponse;
  static deserializeBinaryFromReader(message: ListRefreshTokensResponse, reader: jspb.BinaryReader): ListRefreshTokensResponse;
}

export namespace ListRefreshTokensResponse {
  export type AsObject = {
    refreshTokensList: Array<RefreshToken.AsObject>,
    nextPageToken: string,
  }
}

export class BatchGetRefreshTokensRequest extends jspb.Message {
  getNamesList(): Array<string>;
  setNamesList(value: Array<string>): BatchGetRefreshTokensRequest;
  clearNamesList(): BatchGetRefreshTokensRequest;
  addNames(value: string, index?: number): BatchGetRefreshTokensRequest;

  getView(): RefreshTokenView;
  setView(value: RefreshTokenView): BatchGetRefreshTokensRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): BatchGetRefreshTokensRequest;
  hasReadMask(): boolean;
  clearReadMask(): BatchGetRefreshTokensRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchGetRefreshTokensRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchGetRefreshTokensRequest): BatchGetRefreshTokensRequest.AsObject;
  static serializeBinaryToWriter(message: BatchGetRefreshTokensRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchGetRefreshTokensRequest;
  static deserializeBinaryFromReader(message: BatchGetRefreshTokensRequest, reader: jspb.BinaryReader): BatchGetRefreshTokensRequest;
}

export namespace BatchGetRefreshTokensRequest {
  export type AsObject = {
    namesList: Array<string>,
    view: RefreshTokenView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class BatchGetRefreshTokensResponse extends jspb.Message {
  getRefreshTokensList(): Array<RefreshToken>;
  setRefreshTokensList(value: Array<RefreshToken>): BatchGetRefreshTokensResponse;
  clearRefreshTokensList(): BatchGetRefreshTokensResponse;
  addRefreshTokens(value?: RefreshToken, index?: number): RefreshToken;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchGetRefreshTokensResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchGetRefreshTokensResponse): BatchGetRefreshTokensResponse.AsObject;
  static serializeBinaryToWriter(message: BatchGetRefreshTokensResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchGetRefreshTokensResponse;
  static deserializeBinaryFromReader(message: BatchGetRefreshTokensResponse, reader: jspb.BinaryReader): BatchGetRefreshTokensResponse;
}

export namespace BatchGetRefreshTokensResponse {
  export type AsObject = {
    refreshTokensList: Array<RefreshToken.AsObject>,
  }
}

export class BatchUpdateRefreshTokensRequest extends jspb.Message {
  getRequestsList(): Array<UpdateRefreshTokenRequest>;
  setRequestsList(value: Array<UpdateRefreshTokenRequest>): BatchUpdateRefreshTokensRequest;
  clearRequestsList(): BatchUpdateRefreshTokensRequest;
  addRequests(value?: UpdateRefreshTokenRequest, index?: number): UpdateRefreshTokenRequest;

  getUpdateMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setUpdateMask(value?: google_protobuf_field_mask_pb.FieldMask): BatchUpdateRefreshTokensRequest;
  hasUpdateMask(): boolean;
  clearUpdateMask(): BatchUpdateRefreshTokensRequest;

  getAllowMissing(): boolean;
  setAllowMissing(value: boolean): BatchUpdateRefreshTokensRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchUpdateRefreshTokensRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchUpdateRefreshTokensRequest): BatchUpdateRefreshTokensRequest.AsObject;
  static serializeBinaryToWriter(message: BatchUpdateRefreshTokensRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchUpdateRefreshTokensRequest;
  static deserializeBinaryFromReader(message: BatchUpdateRefreshTokensRequest, reader: jspb.BinaryReader): BatchUpdateRefreshTokensRequest;
}

export namespace BatchUpdateRefreshTokensRequest {
  export type AsObject = {
    requestsList: Array<UpdateRefreshTokenRequest.AsObject>,
    updateMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    allowMissing: boolean,
  }
}

export class BatchUpdateRefreshTokensResponse extends jspb.Message {
  getRefreshTokensList(): Array<RefreshToken>;
  setRefreshTokensList(value: Array<RefreshToken>): BatchUpdateRefreshTokensResponse;
  clearRefreshTokensList(): BatchUpdateRefreshTokensResponse;
  addRefreshTokens(value?: RefreshToken, index?: number): RefreshToken;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchUpdateRefreshTokensResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchUpdateRefreshTokensResponse): BatchUpdateRefreshTokensResponse.AsObject;
  static serializeBinaryToWriter(message: BatchUpdateRefreshTokensResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchUpdateRefreshTokensResponse;
  static deserializeBinaryFromReader(message: BatchUpdateRefreshTokensResponse, reader: jspb.BinaryReader): BatchUpdateRefreshTokensResponse;
}

export namespace BatchUpdateRefreshTokensResponse {
  export type AsObject = {
    refreshTokensList: Array<RefreshToken.AsObject>,
  }
}

export class BatchDeleteRefreshTokensRequest extends jspb.Message {
  getRequestsList(): Array<DeleteRefreshTokenRequest>;
  setRequestsList(value: Array<DeleteRefreshTokenRequest>): BatchDeleteRefreshTokensRequest;
  clearRequestsList(): BatchDeleteRefreshTokensRequest;
  addRequests(value?: DeleteRefreshTokenRequest, index?: number): DeleteRefreshTokenRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchDeleteRefreshTokensRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchDeleteRefreshTokensRequest): BatchDeleteRefreshTokensRequest.AsObject;
  static serializeBinaryToWriter(message: BatchDeleteRefreshTokensRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchDeleteRefreshTokensRequest;
  static deserializeBinaryFromReader(message: BatchDeleteRefreshTokensRequest, reader: jspb.BinaryReader): BatchDeleteRefreshTokensRequest;
}

export namespace BatchDeleteRefreshTokensRequest {
  export type AsObject = {
    requestsList: Array<DeleteRefreshTokenRequest.AsObject>,
  }
}

export class BatchDeleteRefreshTokensResponse extends jspb.Message {
  getRefreshTokensList(): Array<RefreshToken>;
  setRefreshTokensList(value: Array<RefreshToken>): BatchDeleteRefreshTokensResponse;
  clearRefreshTokensList(): BatchDeleteRefreshTokensResponse;
  addRefreshTokens(value?: RefreshToken, index?: number): RefreshToken;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchDeleteRefreshTokensResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchDeleteRefreshTokensResponse): BatchDeleteRefreshTokensResponse.AsObject;
  static serializeBinaryToWriter(message: BatchDeleteRefreshTokensResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchDeleteRefreshTokensResponse;
  static deserializeBinaryFromReader(message: BatchDeleteRefreshTokensResponse, reader: jspb.BinaryReader): BatchDeleteRefreshTokensResponse;
}

export namespace BatchDeleteRefreshTokensResponse {
  export type AsObject = {
    refreshTokensList: Array<RefreshToken.AsObject>,
  }
}

export class StreamRefreshTokensRequest extends jspb.Message {
  getView(): RefreshTokenView;
  setView(value: RefreshTokenView): StreamRefreshTokensRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): StreamRefreshTokensRequest;
  hasReadMask(): boolean;
  clearReadMask(): StreamRefreshTokensRequest;

  getFilter(): string;
  setFilter(value: string): StreamRefreshTokensRequest;

  getOrderBy(): string;
  setOrderBy(value: string): StreamRefreshTokensRequest;

  getShowDeleted(): boolean;
  setShowDeleted(value: boolean): StreamRefreshTokensRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StreamRefreshTokensRequest.AsObject;
  static toObject(includeInstance: boolean, msg: StreamRefreshTokensRequest): StreamRefreshTokensRequest.AsObject;
  static serializeBinaryToWriter(message: StreamRefreshTokensRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StreamRefreshTokensRequest;
  static deserializeBinaryFromReader(message: StreamRefreshTokensRequest, reader: jspb.BinaryReader): StreamRefreshTokensRequest;
}

export namespace StreamRefreshTokensRequest {
  export type AsObject = {
    view: RefreshTokenView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
    orderBy: string,
    showDeleted: boolean,
  }
}

export enum RefreshTokenView { 
  REFRESH_TOKEN_VIEW_UNSPECIFIED = 0,
  REFRESH_TOKEN_VIEW_BASIC = 1,
  REFRESH_TOKEN_VIEW_FULL = 2,
}