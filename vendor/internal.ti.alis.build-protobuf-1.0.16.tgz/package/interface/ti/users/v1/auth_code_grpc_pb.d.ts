// GENERATED CODE -- DO NOT EDIT!

// package: interface.ti.users.v1
// file: interface/ti/users/v1/auth_code.proto

import * as interface_ti_users_v1_auth_code_pb from "../../../../interface/ti/users/v1/auth_code_pb";
import * as grpc from "@grpc/grpc-js";

interface IAuthCodesServiceService extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
  createAuthCode: grpc.MethodDefinition<interface_ti_users_v1_auth_code_pb.CreateAuthCodeRequest, interface_ti_users_v1_auth_code_pb.AuthCode>;
  getAuthCode: grpc.MethodDefinition<interface_ti_users_v1_auth_code_pb.GetAuthCodeRequest, interface_ti_users_v1_auth_code_pb.AuthCode>;
  updateAuthCode: grpc.MethodDefinition<interface_ti_users_v1_auth_code_pb.UpdateAuthCodeRequest, interface_ti_users_v1_auth_code_pb.AuthCode>;
  listAuthCodes: grpc.MethodDefinition<interface_ti_users_v1_auth_code_pb.ListAuthCodesRequest, interface_ti_users_v1_auth_code_pb.ListAuthCodesResponse>;
  deleteAuthCode: grpc.MethodDefinition<interface_ti_users_v1_auth_code_pb.DeleteAuthCodeRequest, interface_ti_users_v1_auth_code_pb.AuthCode>;
  batchGetAuthCodes: grpc.MethodDefinition<interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesRequest, interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesResponse>;
  batchDeleteAuthCodes: grpc.MethodDefinition<interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesRequest, interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesResponse>;
  streamAuthCodes: grpc.MethodDefinition<interface_ti_users_v1_auth_code_pb.StreamAuthCodesRequest, interface_ti_users_v1_auth_code_pb.AuthCode>;
}

export const AuthCodesServiceService: IAuthCodesServiceService;

export interface IAuthCodesServiceServer extends grpc.UntypedServiceImplementation {
  createAuthCode: grpc.handleUnaryCall<interface_ti_users_v1_auth_code_pb.CreateAuthCodeRequest, interface_ti_users_v1_auth_code_pb.AuthCode>;
  getAuthCode: grpc.handleUnaryCall<interface_ti_users_v1_auth_code_pb.GetAuthCodeRequest, interface_ti_users_v1_auth_code_pb.AuthCode>;
  updateAuthCode: grpc.handleUnaryCall<interface_ti_users_v1_auth_code_pb.UpdateAuthCodeRequest, interface_ti_users_v1_auth_code_pb.AuthCode>;
  listAuthCodes: grpc.handleUnaryCall<interface_ti_users_v1_auth_code_pb.ListAuthCodesRequest, interface_ti_users_v1_auth_code_pb.ListAuthCodesResponse>;
  deleteAuthCode: grpc.handleUnaryCall<interface_ti_users_v1_auth_code_pb.DeleteAuthCodeRequest, interface_ti_users_v1_auth_code_pb.AuthCode>;
  batchGetAuthCodes: grpc.handleUnaryCall<interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesRequest, interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesResponse>;
  batchDeleteAuthCodes: grpc.handleUnaryCall<interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesRequest, interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesResponse>;
  streamAuthCodes: grpc.handleServerStreamingCall<interface_ti_users_v1_auth_code_pb.StreamAuthCodesRequest, interface_ti_users_v1_auth_code_pb.AuthCode>;
}

export class AuthCodesServiceClient extends grpc.Client {
  constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
  createAuthCode(argument: interface_ti_users_v1_auth_code_pb.CreateAuthCodeRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.AuthCode>): grpc.ClientUnaryCall;
  createAuthCode(argument: interface_ti_users_v1_auth_code_pb.CreateAuthCodeRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.AuthCode>): grpc.ClientUnaryCall;
  createAuthCode(argument: interface_ti_users_v1_auth_code_pb.CreateAuthCodeRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.AuthCode>): grpc.ClientUnaryCall;
  getAuthCode(argument: interface_ti_users_v1_auth_code_pb.GetAuthCodeRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.AuthCode>): grpc.ClientUnaryCall;
  getAuthCode(argument: interface_ti_users_v1_auth_code_pb.GetAuthCodeRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.AuthCode>): grpc.ClientUnaryCall;
  getAuthCode(argument: interface_ti_users_v1_auth_code_pb.GetAuthCodeRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.AuthCode>): grpc.ClientUnaryCall;
  updateAuthCode(argument: interface_ti_users_v1_auth_code_pb.UpdateAuthCodeRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.AuthCode>): grpc.ClientUnaryCall;
  updateAuthCode(argument: interface_ti_users_v1_auth_code_pb.UpdateAuthCodeRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.AuthCode>): grpc.ClientUnaryCall;
  updateAuthCode(argument: interface_ti_users_v1_auth_code_pb.UpdateAuthCodeRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.AuthCode>): grpc.ClientUnaryCall;
  listAuthCodes(argument: interface_ti_users_v1_auth_code_pb.ListAuthCodesRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.ListAuthCodesResponse>): grpc.ClientUnaryCall;
  listAuthCodes(argument: interface_ti_users_v1_auth_code_pb.ListAuthCodesRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.ListAuthCodesResponse>): grpc.ClientUnaryCall;
  listAuthCodes(argument: interface_ti_users_v1_auth_code_pb.ListAuthCodesRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.ListAuthCodesResponse>): grpc.ClientUnaryCall;
  deleteAuthCode(argument: interface_ti_users_v1_auth_code_pb.DeleteAuthCodeRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.AuthCode>): grpc.ClientUnaryCall;
  deleteAuthCode(argument: interface_ti_users_v1_auth_code_pb.DeleteAuthCodeRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.AuthCode>): grpc.ClientUnaryCall;
  deleteAuthCode(argument: interface_ti_users_v1_auth_code_pb.DeleteAuthCodeRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.AuthCode>): grpc.ClientUnaryCall;
  batchGetAuthCodes(argument: interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesResponse>): grpc.ClientUnaryCall;
  batchGetAuthCodes(argument: interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesResponse>): grpc.ClientUnaryCall;
  batchGetAuthCodes(argument: interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesResponse>): grpc.ClientUnaryCall;
  batchDeleteAuthCodes(argument: interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesResponse>): grpc.ClientUnaryCall;
  batchDeleteAuthCodes(argument: interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesResponse>): grpc.ClientUnaryCall;
  batchDeleteAuthCodes(argument: interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesResponse>): grpc.ClientUnaryCall;
  streamAuthCodes(argument: interface_ti_users_v1_auth_code_pb.StreamAuthCodesRequest, metadataOrOptions?: grpc.Metadata | grpc.CallOptions | null): grpc.ClientReadableStream<interface_ti_users_v1_auth_code_pb.AuthCode>;
  streamAuthCodes(argument: interface_ti_users_v1_auth_code_pb.StreamAuthCodesRequest, metadata?: grpc.Metadata | null, options?: grpc.CallOptions | null): grpc.ClientReadableStream<interface_ti_users_v1_auth_code_pb.AuthCode>;
}