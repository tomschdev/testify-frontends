// GENERATED CODE -- DO NOT EDIT!

// package: interface.ti.users.v1
// file: interface/ti/users/v1/apps.proto

import * as interface_ti_users_v1_apps_pb from "../../../../interface/ti/users/v1/apps_pb";
import * as google_iam_v1_policy_pb from "@alis-build/google-common-protos/google/iam/v1/policy_pb";
import * as google_iam_v1_iam_policy_pb from "@alis-build/google-common-protos/google/iam/v1/iam_policy_pb";
import * as alis_open_iam_v1_iam_pb from "@open.alis.services/protobuf/alis/open/iam/v1/iam_pb";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as grpc from "@grpc/grpc-js";

interface IAppsServiceService extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
  getIamPolicy: grpc.MethodDefinition<google_iam_v1_iam_policy_pb.GetIamPolicyRequest, google_iam_v1_policy_pb.Policy>;
  setIamPolicy: grpc.MethodDefinition<google_iam_v1_iam_policy_pb.SetIamPolicyRequest, google_iam_v1_policy_pb.Policy>;
  testIamPermissions: grpc.MethodDefinition<google_iam_v1_iam_policy_pb.TestIamPermissionsRequest, google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>;
  batchTestIamPermissions: grpc.MethodDefinition<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest, alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>;
  addIamBindings: grpc.MethodDefinition<alis_open_iam_v1_iam_pb.AddIamBindingsRequest, google_iam_v1_policy_pb.Policy>;
  removeIamBindings: grpc.MethodDefinition<alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest, google_iam_v1_policy_pb.Policy>;
  createApp: grpc.MethodDefinition<interface_ti_users_v1_apps_pb.CreateAppRequest, interface_ti_users_v1_apps_pb.App>;
  getApp: grpc.MethodDefinition<interface_ti_users_v1_apps_pb.GetAppRequest, interface_ti_users_v1_apps_pb.App>;
  updateApp: grpc.MethodDefinition<interface_ti_users_v1_apps_pb.UpdateAppRequest, interface_ti_users_v1_apps_pb.App>;
  listApps: grpc.MethodDefinition<interface_ti_users_v1_apps_pb.ListAppsRequest, interface_ti_users_v1_apps_pb.ListAppsResponse>;
  deleteApp: grpc.MethodDefinition<interface_ti_users_v1_apps_pb.DeleteAppRequest, google_protobuf_empty_pb.Empty>;
}

export const AppsServiceService: IAppsServiceService;

export interface IAppsServiceServer extends grpc.UntypedServiceImplementation {
  getIamPolicy: grpc.handleUnaryCall<google_iam_v1_iam_policy_pb.GetIamPolicyRequest, google_iam_v1_policy_pb.Policy>;
  setIamPolicy: grpc.handleUnaryCall<google_iam_v1_iam_policy_pb.SetIamPolicyRequest, google_iam_v1_policy_pb.Policy>;
  testIamPermissions: grpc.handleUnaryCall<google_iam_v1_iam_policy_pb.TestIamPermissionsRequest, google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>;
  batchTestIamPermissions: grpc.handleUnaryCall<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest, alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>;
  addIamBindings: grpc.handleUnaryCall<alis_open_iam_v1_iam_pb.AddIamBindingsRequest, google_iam_v1_policy_pb.Policy>;
  removeIamBindings: grpc.handleUnaryCall<alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest, google_iam_v1_policy_pb.Policy>;
  createApp: grpc.handleUnaryCall<interface_ti_users_v1_apps_pb.CreateAppRequest, interface_ti_users_v1_apps_pb.App>;
  getApp: grpc.handleUnaryCall<interface_ti_users_v1_apps_pb.GetAppRequest, interface_ti_users_v1_apps_pb.App>;
  updateApp: grpc.handleUnaryCall<interface_ti_users_v1_apps_pb.UpdateAppRequest, interface_ti_users_v1_apps_pb.App>;
  listApps: grpc.handleUnaryCall<interface_ti_users_v1_apps_pb.ListAppsRequest, interface_ti_users_v1_apps_pb.ListAppsResponse>;
  deleteApp: grpc.handleUnaryCall<interface_ti_users_v1_apps_pb.DeleteAppRequest, google_protobuf_empty_pb.Empty>;
}

export class AppsServiceClient extends grpc.Client {
  constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
  getIamPolicy(argument: google_iam_v1_iam_policy_pb.GetIamPolicyRequest, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  getIamPolicy(argument: google_iam_v1_iam_policy_pb.GetIamPolicyRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  getIamPolicy(argument: google_iam_v1_iam_policy_pb.GetIamPolicyRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  setIamPolicy(argument: google_iam_v1_iam_policy_pb.SetIamPolicyRequest, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  setIamPolicy(argument: google_iam_v1_iam_policy_pb.SetIamPolicyRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  setIamPolicy(argument: google_iam_v1_iam_policy_pb.SetIamPolicyRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  testIamPermissions(argument: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest, callback: grpc.requestCallback<google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>): grpc.ClientUnaryCall;
  testIamPermissions(argument: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>): grpc.ClientUnaryCall;
  testIamPermissions(argument: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>): grpc.ClientUnaryCall;
  batchTestIamPermissions(argument: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest, callback: grpc.requestCallback<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>): grpc.ClientUnaryCall;
  batchTestIamPermissions(argument: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>): grpc.ClientUnaryCall;
  batchTestIamPermissions(argument: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>): grpc.ClientUnaryCall;
  addIamBindings(argument: alis_open_iam_v1_iam_pb.AddIamBindingsRequest, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  addIamBindings(argument: alis_open_iam_v1_iam_pb.AddIamBindingsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  addIamBindings(argument: alis_open_iam_v1_iam_pb.AddIamBindingsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  removeIamBindings(argument: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  removeIamBindings(argument: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  removeIamBindings(argument: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  createApp(argument: interface_ti_users_v1_apps_pb.CreateAppRequest, callback: grpc.requestCallback<interface_ti_users_v1_apps_pb.App>): grpc.ClientUnaryCall;
  createApp(argument: interface_ti_users_v1_apps_pb.CreateAppRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_apps_pb.App>): grpc.ClientUnaryCall;
  createApp(argument: interface_ti_users_v1_apps_pb.CreateAppRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_apps_pb.App>): grpc.ClientUnaryCall;
  getApp(argument: interface_ti_users_v1_apps_pb.GetAppRequest, callback: grpc.requestCallback<interface_ti_users_v1_apps_pb.App>): grpc.ClientUnaryCall;
  getApp(argument: interface_ti_users_v1_apps_pb.GetAppRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_apps_pb.App>): grpc.ClientUnaryCall;
  getApp(argument: interface_ti_users_v1_apps_pb.GetAppRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_apps_pb.App>): grpc.ClientUnaryCall;
  updateApp(argument: interface_ti_users_v1_apps_pb.UpdateAppRequest, callback: grpc.requestCallback<interface_ti_users_v1_apps_pb.App>): grpc.ClientUnaryCall;
  updateApp(argument: interface_ti_users_v1_apps_pb.UpdateAppRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_apps_pb.App>): grpc.ClientUnaryCall;
  updateApp(argument: interface_ti_users_v1_apps_pb.UpdateAppRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_apps_pb.App>): grpc.ClientUnaryCall;
  listApps(argument: interface_ti_users_v1_apps_pb.ListAppsRequest, callback: grpc.requestCallback<interface_ti_users_v1_apps_pb.ListAppsResponse>): grpc.ClientUnaryCall;
  listApps(argument: interface_ti_users_v1_apps_pb.ListAppsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_apps_pb.ListAppsResponse>): grpc.ClientUnaryCall;
  listApps(argument: interface_ti_users_v1_apps_pb.ListAppsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_apps_pb.ListAppsResponse>): grpc.ClientUnaryCall;
  deleteApp(argument: interface_ti_users_v1_apps_pb.DeleteAppRequest, callback: grpc.requestCallback<google_protobuf_empty_pb.Empty>): grpc.ClientUnaryCall;
  deleteApp(argument: interface_ti_users_v1_apps_pb.DeleteAppRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<google_protobuf_empty_pb.Empty>): grpc.ClientUnaryCall;
  deleteApp(argument: interface_ti_users_v1_apps_pb.DeleteAppRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<google_protobuf_empty_pb.Empty>): grpc.ClientUnaryCall;
}