import * as jspb from 'google-protobuf'

import * as alis_open_iam_v1_iam_pb from '@open.alis.services/protobuf/alis/open/iam/v1/iam_pb'; // proto import: "alis/open/iam/v1/iam.proto"
import * as google_iam_v1_iam_policy_pb from '@alis-build/google-common-protos/google/iam/v1/iam_policy_pb'; // proto import: "google/iam/v1/iam_policy.proto"
import * as google_iam_v1_policy_pb from '@alis-build/google-common-protos/google/iam/v1/policy_pb'; // proto import: "google/iam/v1/policy.proto"
import * as google_protobuf_field_mask_pb from 'google-protobuf/google/protobuf/field_mask_pb'; // proto import: "google/protobuf/field_mask.proto"
import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb'; // proto import: "google/protobuf/timestamp.proto"


export class Organisation extends jspb.Message {
  getName(): string;
  setName(value: string): Organisation;

  getDisplayName(): string;
  setDisplayName(value: string): Organisation;

  getDescription(): string;
  setDescription(value: string): Organisation;

  getIssuerPublicKey(): string;
  setIssuerPublicKey(value: string): Organisation;

  getHederaAccountAddress(): string;
  setHederaAccountAddress(value: string): Organisation;

  getPrivateKey(): string;
  setPrivateKey(value: string): Organisation;

  getCreateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreateTime(value?: google_protobuf_timestamp_pb.Timestamp): Organisation;
  hasCreateTime(): boolean;
  clearCreateTime(): Organisation;

  getUpdateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setUpdateTime(value?: google_protobuf_timestamp_pb.Timestamp): Organisation;
  hasUpdateTime(): boolean;
  clearUpdateTime(): Organisation;

  getDeleteTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setDeleteTime(value?: google_protobuf_timestamp_pb.Timestamp): Organisation;
  hasDeleteTime(): boolean;
  clearDeleteTime(): Organisation;

  getEtag(): string;
  setEtag(value: string): Organisation;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Organisation.AsObject;
  static toObject(includeInstance: boolean, msg: Organisation): Organisation.AsObject;
  static serializeBinaryToWriter(message: Organisation, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Organisation;
  static deserializeBinaryFromReader(message: Organisation, reader: jspb.BinaryReader): Organisation;
}

export namespace Organisation {
  export type AsObject = {
    name: string,
    displayName: string,
    description: string,
    issuerPublicKey: string,
    hederaAccountAddress: string,
    privateKey: string,
    createTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    updateTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    deleteTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    etag: string,
  }
}

export class CreateOrganisationRequest extends jspb.Message {
  getOrganisation(): Organisation | undefined;
  setOrganisation(value?: Organisation): CreateOrganisationRequest;
  hasOrganisation(): boolean;
  clearOrganisation(): CreateOrganisationRequest;

  getOrganisationId(): string;
  setOrganisationId(value: string): CreateOrganisationRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateOrganisationRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateOrganisationRequest): CreateOrganisationRequest.AsObject;
  static serializeBinaryToWriter(message: CreateOrganisationRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateOrganisationRequest;
  static deserializeBinaryFromReader(message: CreateOrganisationRequest, reader: jspb.BinaryReader): CreateOrganisationRequest;
}

export namespace CreateOrganisationRequest {
  export type AsObject = {
    organisation?: Organisation.AsObject,
    organisationId: string,
  }
}

export class GetOrganisationRequest extends jspb.Message {
  getName(): string;
  setName(value: string): GetOrganisationRequest;

  getView(): OrganisationView;
  setView(value: OrganisationView): GetOrganisationRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): GetOrganisationRequest;
  hasReadMask(): boolean;
  clearReadMask(): GetOrganisationRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetOrganisationRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetOrganisationRequest): GetOrganisationRequest.AsObject;
  static serializeBinaryToWriter(message: GetOrganisationRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetOrganisationRequest;
  static deserializeBinaryFromReader(message: GetOrganisationRequest, reader: jspb.BinaryReader): GetOrganisationRequest;
}

export namespace GetOrganisationRequest {
  export type AsObject = {
    name: string,
    view: OrganisationView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class UpdateOrganisationRequest extends jspb.Message {
  getOrganisation(): Organisation | undefined;
  setOrganisation(value?: Organisation): UpdateOrganisationRequest;
  hasOrganisation(): boolean;
  clearOrganisation(): UpdateOrganisationRequest;

  getUpdateMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setUpdateMask(value?: google_protobuf_field_mask_pb.FieldMask): UpdateOrganisationRequest;
  hasUpdateMask(): boolean;
  clearUpdateMask(): UpdateOrganisationRequest;

  getAllowMissing(): boolean;
  setAllowMissing(value: boolean): UpdateOrganisationRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateOrganisationRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateOrganisationRequest): UpdateOrganisationRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateOrganisationRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateOrganisationRequest;
  static deserializeBinaryFromReader(message: UpdateOrganisationRequest, reader: jspb.BinaryReader): UpdateOrganisationRequest;
}

export namespace UpdateOrganisationRequest {
  export type AsObject = {
    organisation?: Organisation.AsObject,
    updateMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    allowMissing: boolean,
  }
}

export class ListOrganisationsRequest extends jspb.Message {
  getPageSize(): number;
  setPageSize(value: number): ListOrganisationsRequest;

  getPageToken(): string;
  setPageToken(value: string): ListOrganisationsRequest;

  getView(): OrganisationView;
  setView(value: OrganisationView): ListOrganisationsRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): ListOrganisationsRequest;
  hasReadMask(): boolean;
  clearReadMask(): ListOrganisationsRequest;

  getFilter(): string;
  setFilter(value: string): ListOrganisationsRequest;

  getOrderBy(): string;
  setOrderBy(value: string): ListOrganisationsRequest;

  getShowDeleted(): boolean;
  setShowDeleted(value: boolean): ListOrganisationsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListOrganisationsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListOrganisationsRequest): ListOrganisationsRequest.AsObject;
  static serializeBinaryToWriter(message: ListOrganisationsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListOrganisationsRequest;
  static deserializeBinaryFromReader(message: ListOrganisationsRequest, reader: jspb.BinaryReader): ListOrganisationsRequest;
}

export namespace ListOrganisationsRequest {
  export type AsObject = {
    pageSize: number,
    pageToken: string,
    view: OrganisationView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
    orderBy: string,
    showDeleted: boolean,
  }
}

export class ListOrganisationsResponse extends jspb.Message {
  getOrganisationsList(): Array<Organisation>;
  setOrganisationsList(value: Array<Organisation>): ListOrganisationsResponse;
  clearOrganisationsList(): ListOrganisationsResponse;
  addOrganisations(value?: Organisation, index?: number): Organisation;

  getNextPageToken(): string;
  setNextPageToken(value: string): ListOrganisationsResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListOrganisationsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListOrganisationsResponse): ListOrganisationsResponse.AsObject;
  static serializeBinaryToWriter(message: ListOrganisationsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListOrganisationsResponse;
  static deserializeBinaryFromReader(message: ListOrganisationsResponse, reader: jspb.BinaryReader): ListOrganisationsResponse;
}

export namespace ListOrganisationsResponse {
  export type AsObject = {
    organisationsList: Array<Organisation.AsObject>,
    nextPageToken: string,
  }
}

export class DeleteOrganisationRequest extends jspb.Message {
  getName(): string;
  setName(value: string): DeleteOrganisationRequest;

  getEtag(): string;
  setEtag(value: string): DeleteOrganisationRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteOrganisationRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteOrganisationRequest): DeleteOrganisationRequest.AsObject;
  static serializeBinaryToWriter(message: DeleteOrganisationRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteOrganisationRequest;
  static deserializeBinaryFromReader(message: DeleteOrganisationRequest, reader: jspb.BinaryReader): DeleteOrganisationRequest;
}

export namespace DeleteOrganisationRequest {
  export type AsObject = {
    name: string,
    etag: string,
  }
}

export class UndeleteOrganisationRequest extends jspb.Message {
  getName(): string;
  setName(value: string): UndeleteOrganisationRequest;

  getEtag(): string;
  setEtag(value: string): UndeleteOrganisationRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UndeleteOrganisationRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UndeleteOrganisationRequest): UndeleteOrganisationRequest.AsObject;
  static serializeBinaryToWriter(message: UndeleteOrganisationRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UndeleteOrganisationRequest;
  static deserializeBinaryFromReader(message: UndeleteOrganisationRequest, reader: jspb.BinaryReader): UndeleteOrganisationRequest;
}

export namespace UndeleteOrganisationRequest {
  export type AsObject = {
    name: string,
    etag: string,
  }
}

export class ListMyOrganisationsRequest extends jspb.Message {
  getPageSize(): number;
  setPageSize(value: number): ListMyOrganisationsRequest;

  getPageToken(): string;
  setPageToken(value: string): ListMyOrganisationsRequest;

  getView(): OrganisationView;
  setView(value: OrganisationView): ListMyOrganisationsRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): ListMyOrganisationsRequest;
  hasReadMask(): boolean;
  clearReadMask(): ListMyOrganisationsRequest;

  getOrderBy(): string;
  setOrderBy(value: string): ListMyOrganisationsRequest;

  getShowDeleted(): boolean;
  setShowDeleted(value: boolean): ListMyOrganisationsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListMyOrganisationsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListMyOrganisationsRequest): ListMyOrganisationsRequest.AsObject;
  static serializeBinaryToWriter(message: ListMyOrganisationsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListMyOrganisationsRequest;
  static deserializeBinaryFromReader(message: ListMyOrganisationsRequest, reader: jspb.BinaryReader): ListMyOrganisationsRequest;
}

export namespace ListMyOrganisationsRequest {
  export type AsObject = {
    pageSize: number,
    pageToken: string,
    view: OrganisationView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    orderBy: string,
    showDeleted: boolean,
  }
}

export class ListMyOrganisationsResponse extends jspb.Message {
  getOrganisationsList(): Array<Organisation>;
  setOrganisationsList(value: Array<Organisation>): ListMyOrganisationsResponse;
  clearOrganisationsList(): ListMyOrganisationsResponse;
  addOrganisations(value?: Organisation, index?: number): Organisation;

  getNextPageToken(): string;
  setNextPageToken(value: string): ListMyOrganisationsResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListMyOrganisationsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListMyOrganisationsResponse): ListMyOrganisationsResponse.AsObject;
  static serializeBinaryToWriter(message: ListMyOrganisationsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListMyOrganisationsResponse;
  static deserializeBinaryFromReader(message: ListMyOrganisationsResponse, reader: jspb.BinaryReader): ListMyOrganisationsResponse;
}

export namespace ListMyOrganisationsResponse {
  export type AsObject = {
    organisationsList: Array<Organisation.AsObject>,
    nextPageToken: string,
  }
}

export enum OrganisationView { 
  ORGANISATION_VIEW_UNSPECIFIED = 0,
  ORGANISATION_VIEW_BASIC = 1,
  ORGANISATION_VIEW_FULL = 2,
}