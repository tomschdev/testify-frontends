import * as grpcWeb from 'grpc-web';

import * as alis_open_iam_v1_iam_pb from '@open.alis.services/protobuf/alis/open/iam/v1/iam_pb'; // proto import: "alis/open/iam/v1/iam.proto"
import * as google_iam_v1_iam_policy_pb from '@alis-build/google-common-protos/google/iam/v1/iam_policy_pb'; // proto import: "google/iam/v1/iam_policy.proto"
import * as google_iam_v1_policy_pb from '@alis-build/google-common-protos/google/iam/v1/policy_pb'; // proto import: "google/iam/v1/policy.proto"
import * as google_protobuf_empty_pb from 'google-protobuf/google/protobuf/empty_pb'; // proto import: "google/protobuf/empty.proto"
import * as interface_ti_users_v1_apps_pb from '../../../../interface/ti/users/v1/apps_pb'; // proto import: "interface/ti/users/v1/apps.proto"


export class AppsServiceClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  getIamPolicy(
    request: google_iam_v1_iam_policy_pb.GetIamPolicyRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_policy_pb.Policy) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_policy_pb.Policy>;

  setIamPolicy(
    request: google_iam_v1_iam_policy_pb.SetIamPolicyRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_policy_pb.Policy) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_policy_pb.Policy>;

  testIamPermissions(
    request: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_iam_policy_pb.TestIamPermissionsResponse) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>;

  batchTestIamPermissions(
    request: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse) => void
  ): grpcWeb.ClientReadableStream<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>;

  addIamBindings(
    request: alis_open_iam_v1_iam_pb.AddIamBindingsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_policy_pb.Policy) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_policy_pb.Policy>;

  removeIamBindings(
    request: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_policy_pb.Policy) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_policy_pb.Policy>;

  createApp(
    request: interface_ti_users_v1_apps_pb.CreateAppRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_apps_pb.App) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_apps_pb.App>;

  getApp(
    request: interface_ti_users_v1_apps_pb.GetAppRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_apps_pb.App) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_apps_pb.App>;

  updateApp(
    request: interface_ti_users_v1_apps_pb.UpdateAppRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_apps_pb.App) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_apps_pb.App>;

  listApps(
    request: interface_ti_users_v1_apps_pb.ListAppsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_apps_pb.ListAppsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_apps_pb.ListAppsResponse>;

  deleteApp(
    request: interface_ti_users_v1_apps_pb.DeleteAppRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_protobuf_empty_pb.Empty) => void
  ): grpcWeb.ClientReadableStream<google_protobuf_empty_pb.Empty>;

}

export class AppsServicePromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  getIamPolicy(
    request: google_iam_v1_iam_policy_pb.GetIamPolicyRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_policy_pb.Policy>;

  setIamPolicy(
    request: google_iam_v1_iam_policy_pb.SetIamPolicyRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_policy_pb.Policy>;

  testIamPermissions(
    request: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>;

  batchTestIamPermissions(
    request: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>;

  addIamBindings(
    request: alis_open_iam_v1_iam_pb.AddIamBindingsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_policy_pb.Policy>;

  removeIamBindings(
    request: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_policy_pb.Policy>;

  createApp(
    request: interface_ti_users_v1_apps_pb.CreateAppRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_apps_pb.App>;

  getApp(
    request: interface_ti_users_v1_apps_pb.GetAppRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_apps_pb.App>;

  updateApp(
    request: interface_ti_users_v1_apps_pb.UpdateAppRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_apps_pb.App>;

  listApps(
    request: interface_ti_users_v1_apps_pb.ListAppsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_apps_pb.ListAppsResponse>;

  deleteApp(
    request: interface_ti_users_v1_apps_pb.DeleteAppRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_protobuf_empty_pb.Empty>;

}
