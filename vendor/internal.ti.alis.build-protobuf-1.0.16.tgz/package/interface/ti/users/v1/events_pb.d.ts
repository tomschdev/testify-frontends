import * as jspb from 'google-protobuf'

import * as google_protobuf_field_mask_pb from 'google-protobuf/google/protobuf/field_mask_pb'; // proto import: "google/protobuf/field_mask.proto"


export class UserCreatedEvent extends jspb.Message {
  getUser(): string;
  setUser(value: string): UserCreatedEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UserCreatedEvent.AsObject;
  static toObject(includeInstance: boolean, msg: UserCreatedEvent): UserCreatedEvent.AsObject;
  static serializeBinaryToWriter(message: UserCreatedEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UserCreatedEvent;
  static deserializeBinaryFromReader(message: UserCreatedEvent, reader: jspb.BinaryReader): UserCreatedEvent;
}

export namespace UserCreatedEvent {
  export type AsObject = {
    user: string,
  }
}

export class UserUpdatedEvent extends jspb.Message {
  getUser(): string;
  setUser(value: string): UserUpdatedEvent;

  getUpdateMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setUpdateMask(value?: google_protobuf_field_mask_pb.FieldMask): UserUpdatedEvent;
  hasUpdateMask(): boolean;
  clearUpdateMask(): UserUpdatedEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UserUpdatedEvent.AsObject;
  static toObject(includeInstance: boolean, msg: UserUpdatedEvent): UserUpdatedEvent.AsObject;
  static serializeBinaryToWriter(message: UserUpdatedEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UserUpdatedEvent;
  static deserializeBinaryFromReader(message: UserUpdatedEvent, reader: jspb.BinaryReader): UserUpdatedEvent;
}

export namespace UserUpdatedEvent {
  export type AsObject = {
    user: string,
    updateMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}
