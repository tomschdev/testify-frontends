// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('@grpc/grpc-js');
var interface_ti_users_v1_organisation_pb = require('../../../../interface/ti/users/v1/organisation_pb.js');
var alis_open_iam_v1_iam_pb = require('@open.alis.services/protobuf/alis/open/iam/v1/iam_pb.js');
var google_iam_v1_iam_policy_pb = require('@alis-build/google-common-protos/google/iam/v1/iam_policy_pb.js');
var google_iam_v1_policy_pb = require('@alis-build/google-common-protos/google/iam/v1/policy_pb.js');
var google_protobuf_field_mask_pb = require('google-protobuf/google/protobuf/field_mask_pb.js');
var google_protobuf_timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb.js');

function serialize_alis_open_iam_v1_AddIamBindingsRequest(arg) {
  if (!(arg instanceof alis_open_iam_v1_iam_pb.AddIamBindingsRequest)) {
    throw new Error('Expected argument of type alis.open.iam.v1.AddIamBindingsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_alis_open_iam_v1_AddIamBindingsRequest(buffer_arg) {
  return alis_open_iam_v1_iam_pb.AddIamBindingsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_alis_open_iam_v1_BatchTestIamPermissionsRequest(arg) {
  if (!(arg instanceof alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest)) {
    throw new Error('Expected argument of type alis.open.iam.v1.BatchTestIamPermissionsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_alis_open_iam_v1_BatchTestIamPermissionsRequest(buffer_arg) {
  return alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_alis_open_iam_v1_BatchTestIamPermissionsResponse(arg) {
  if (!(arg instanceof alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse)) {
    throw new Error('Expected argument of type alis.open.iam.v1.BatchTestIamPermissionsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_alis_open_iam_v1_BatchTestIamPermissionsResponse(buffer_arg) {
  return alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_alis_open_iam_v1_RemoveIamBindingsRequest(arg) {
  if (!(arg instanceof alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest)) {
    throw new Error('Expected argument of type alis.open.iam.v1.RemoveIamBindingsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_alis_open_iam_v1_RemoveIamBindingsRequest(buffer_arg) {
  return alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_GetIamPolicyRequest(arg) {
  if (!(arg instanceof google_iam_v1_iam_policy_pb.GetIamPolicyRequest)) {
    throw new Error('Expected argument of type google.iam.v1.GetIamPolicyRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_GetIamPolicyRequest(buffer_arg) {
  return google_iam_v1_iam_policy_pb.GetIamPolicyRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_Policy(arg) {
  if (!(arg instanceof google_iam_v1_policy_pb.Policy)) {
    throw new Error('Expected argument of type google.iam.v1.Policy');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_Policy(buffer_arg) {
  return google_iam_v1_policy_pb.Policy.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_SetIamPolicyRequest(arg) {
  if (!(arg instanceof google_iam_v1_iam_policy_pb.SetIamPolicyRequest)) {
    throw new Error('Expected argument of type google.iam.v1.SetIamPolicyRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_SetIamPolicyRequest(buffer_arg) {
  return google_iam_v1_iam_policy_pb.SetIamPolicyRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_TestIamPermissionsRequest(arg) {
  if (!(arg instanceof google_iam_v1_iam_policy_pb.TestIamPermissionsRequest)) {
    throw new Error('Expected argument of type google.iam.v1.TestIamPermissionsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_TestIamPermissionsRequest(buffer_arg) {
  return google_iam_v1_iam_policy_pb.TestIamPermissionsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_TestIamPermissionsResponse(arg) {
  if (!(arg instanceof google_iam_v1_iam_policy_pb.TestIamPermissionsResponse)) {
    throw new Error('Expected argument of type google.iam.v1.TestIamPermissionsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_TestIamPermissionsResponse(buffer_arg) {
  return google_iam_v1_iam_policy_pb.TestIamPermissionsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_CreateOrganisationRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_organisation_pb.CreateOrganisationRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.CreateOrganisationRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_CreateOrganisationRequest(buffer_arg) {
  return interface_ti_users_v1_organisation_pb.CreateOrganisationRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_DeleteOrganisationRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_organisation_pb.DeleteOrganisationRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.DeleteOrganisationRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_DeleteOrganisationRequest(buffer_arg) {
  return interface_ti_users_v1_organisation_pb.DeleteOrganisationRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_GetOrganisationRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_organisation_pb.GetOrganisationRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.GetOrganisationRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_GetOrganisationRequest(buffer_arg) {
  return interface_ti_users_v1_organisation_pb.GetOrganisationRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListMyOrganisationsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_organisation_pb.ListMyOrganisationsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListMyOrganisationsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListMyOrganisationsRequest(buffer_arg) {
  return interface_ti_users_v1_organisation_pb.ListMyOrganisationsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListMyOrganisationsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_organisation_pb.ListMyOrganisationsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListMyOrganisationsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListMyOrganisationsResponse(buffer_arg) {
  return interface_ti_users_v1_organisation_pb.ListMyOrganisationsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListOrganisationsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_organisation_pb.ListOrganisationsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListOrganisationsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListOrganisationsRequest(buffer_arg) {
  return interface_ti_users_v1_organisation_pb.ListOrganisationsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListOrganisationsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_organisation_pb.ListOrganisationsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListOrganisationsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListOrganisationsResponse(buffer_arg) {
  return interface_ti_users_v1_organisation_pb.ListOrganisationsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_Organisation(arg) {
  if (!(arg instanceof interface_ti_users_v1_organisation_pb.Organisation)) {
    throw new Error('Expected argument of type interface.ti.users.v1.Organisation');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_Organisation(buffer_arg) {
  return interface_ti_users_v1_organisation_pb.Organisation.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_UndeleteOrganisationRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_organisation_pb.UndeleteOrganisationRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.UndeleteOrganisationRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_UndeleteOrganisationRequest(buffer_arg) {
  return interface_ti_users_v1_organisation_pb.UndeleteOrganisationRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_UpdateOrganisationRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_organisation_pb.UpdateOrganisationRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.UpdateOrganisationRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_UpdateOrganisationRequest(buffer_arg) {
  return interface_ti_users_v1_organisation_pb.UpdateOrganisationRequest.deserializeBinary(new Uint8Array(buffer_arg));
}


// OrganisationsService manages Organisation resources.
//
// An Organisation is an issuing entity (the issuer / employer role) in the
// Testify model. The user that creates an Organisation owns it and grants
// other users access by writing the Organisation's IAM policy. Three roles are
// expected:
//   - owner:  full control, including delete and IAM policy changes.
//   - admin:  manage members and issue on behalf of the Organisation.
//   - member: issue and read on behalf of the Organisation.
// Roles are IAM role strings, not proto enums — they are granted via
// SetIamPolicy / AddIamBindings, mirroring UsersService.
var OrganisationsServiceService = exports.OrganisationsServiceService = {
  // Gets the IAM policy for a resource implemented in this service.
getIamPolicy: {
    path: '/interface.ti.users.v1.OrganisationsService/GetIamPolicy',
    requestStream: false,
    responseStream: false,
    requestType: google_iam_v1_iam_policy_pb.GetIamPolicyRequest,
    responseType: google_iam_v1_policy_pb.Policy,
    requestSerialize: serialize_google_iam_v1_GetIamPolicyRequest,
    requestDeserialize: deserialize_google_iam_v1_GetIamPolicyRequest,
    responseSerialize: serialize_google_iam_v1_Policy,
    responseDeserialize: deserialize_google_iam_v1_Policy,
  },
  // Sets the IAM policy for a resource implemented in this service.
setIamPolicy: {
    path: '/interface.ti.users.v1.OrganisationsService/SetIamPolicy',
    requestStream: false,
    responseStream: false,
    requestType: google_iam_v1_iam_policy_pb.SetIamPolicyRequest,
    responseType: google_iam_v1_policy_pb.Policy,
    requestSerialize: serialize_google_iam_v1_SetIamPolicyRequest,
    requestDeserialize: deserialize_google_iam_v1_SetIamPolicyRequest,
    responseSerialize: serialize_google_iam_v1_Policy,
    responseDeserialize: deserialize_google_iam_v1_Policy,
  },
  // Returns permissions that a caller has on the specified resource.
testIamPermissions: {
    path: '/interface.ti.users.v1.OrganisationsService/TestIamPermissions',
    requestStream: false,
    responseStream: false,
    requestType: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest,
    responseType: google_iam_v1_iam_policy_pb.TestIamPermissionsResponse,
    requestSerialize: serialize_google_iam_v1_TestIamPermissionsRequest,
    requestDeserialize: deserialize_google_iam_v1_TestIamPermissionsRequest,
    responseSerialize: serialize_google_iam_v1_TestIamPermissionsResponse,
    responseDeserialize: deserialize_google_iam_v1_TestIamPermissionsResponse,
  },
  // Returns permissions that a caller has on the specified resources.
batchTestIamPermissions: {
    path: '/interface.ti.users.v1.OrganisationsService/BatchTestIamPermissions',
    requestStream: false,
    responseStream: false,
    requestType: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest,
    responseType: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse,
    requestSerialize: serialize_alis_open_iam_v1_BatchTestIamPermissionsRequest,
    requestDeserialize: deserialize_alis_open_iam_v1_BatchTestIamPermissionsRequest,
    responseSerialize: serialize_alis_open_iam_v1_BatchTestIamPermissionsResponse,
    responseDeserialize: deserialize_alis_open_iam_v1_BatchTestIamPermissionsResponse,
  },
  // Adds principals or updates the roles existing principals have on an IAM Policy protected resource.
addIamBindings: {
    path: '/interface.ti.users.v1.OrganisationsService/AddIamBindings',
    requestStream: false,
    responseStream: false,
    requestType: alis_open_iam_v1_iam_pb.AddIamBindingsRequest,
    responseType: google_iam_v1_policy_pb.Policy,
    requestSerialize: serialize_alis_open_iam_v1_AddIamBindingsRequest,
    requestDeserialize: deserialize_alis_open_iam_v1_AddIamBindingsRequest,
    responseSerialize: serialize_google_iam_v1_Policy,
    responseDeserialize: deserialize_google_iam_v1_Policy,
  },
  // Removes principals or some of the roles they have on an IAM Policy protected resource.
removeIamBindings: {
    path: '/interface.ti.users.v1.OrganisationsService/RemoveIamBindings',
    requestStream: false,
    responseStream: false,
    requestType: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest,
    responseType: google_iam_v1_policy_pb.Policy,
    requestSerialize: serialize_alis_open_iam_v1_RemoveIamBindingsRequest,
    requestDeserialize: deserialize_alis_open_iam_v1_RemoveIamBindingsRequest,
    responseSerialize: serialize_google_iam_v1_Policy,
    responseDeserialize: deserialize_google_iam_v1_Policy,
  },
  // Creates a new organisation. The caller becomes the owner.
createOrganisation: {
    path: '/interface.ti.users.v1.OrganisationsService/CreateOrganisation',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_organisation_pb.CreateOrganisationRequest,
    responseType: interface_ti_users_v1_organisation_pb.Organisation,
    requestSerialize: serialize_interface_ti_users_v1_CreateOrganisationRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_CreateOrganisationRequest,
    responseSerialize: serialize_interface_ti_users_v1_Organisation,
    responseDeserialize: deserialize_interface_ti_users_v1_Organisation,
  },
  // Gets an organisation by its resource name.
getOrganisation: {
    path: '/interface.ti.users.v1.OrganisationsService/GetOrganisation',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_organisation_pb.GetOrganisationRequest,
    responseType: interface_ti_users_v1_organisation_pb.Organisation,
    requestSerialize: serialize_interface_ti_users_v1_GetOrganisationRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_GetOrganisationRequest,
    responseSerialize: serialize_interface_ti_users_v1_Organisation,
    responseDeserialize: deserialize_interface_ti_users_v1_Organisation,
  },
  // Updates an organisation.
updateOrganisation: {
    path: '/interface.ti.users.v1.OrganisationsService/UpdateOrganisation',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_organisation_pb.UpdateOrganisationRequest,
    responseType: interface_ti_users_v1_organisation_pb.Organisation,
    requestSerialize: serialize_interface_ti_users_v1_UpdateOrganisationRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_UpdateOrganisationRequest,
    responseSerialize: serialize_interface_ti_users_v1_Organisation,
    responseDeserialize: deserialize_interface_ti_users_v1_Organisation,
  },
  // Lists organisations the caller has access to.
listOrganisations: {
    path: '/interface.ti.users.v1.OrganisationsService/ListOrganisations',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_organisation_pb.ListOrganisationsRequest,
    responseType: interface_ti_users_v1_organisation_pb.ListOrganisationsResponse,
    requestSerialize: serialize_interface_ti_users_v1_ListOrganisationsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_ListOrganisationsRequest,
    responseSerialize: serialize_interface_ti_users_v1_ListOrganisationsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_ListOrganisationsResponse,
  },
  // Lists the organisations the calling user is a member of (owner, admin or member).
listMyOrganisations: {
    path: '/interface.ti.users.v1.OrganisationsService/ListMyOrganisations',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_organisation_pb.ListMyOrganisationsRequest,
    responseType: interface_ti_users_v1_organisation_pb.ListMyOrganisationsResponse,
    requestSerialize: serialize_interface_ti_users_v1_ListMyOrganisationsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_ListMyOrganisationsRequest,
    responseSerialize: serialize_interface_ti_users_v1_ListMyOrganisationsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_ListMyOrganisationsResponse,
  },
  // Soft-deletes an organisation. It can be restored with UndeleteOrganisation.
deleteOrganisation: {
    path: '/interface.ti.users.v1.OrganisationsService/DeleteOrganisation',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_organisation_pb.DeleteOrganisationRequest,
    responseType: interface_ti_users_v1_organisation_pb.Organisation,
    requestSerialize: serialize_interface_ti_users_v1_DeleteOrganisationRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_DeleteOrganisationRequest,
    responseSerialize: serialize_interface_ti_users_v1_Organisation,
    responseDeserialize: deserialize_interface_ti_users_v1_Organisation,
  },
  // Restores a soft-deleted organisation.
undeleteOrganisation: {
    path: '/interface.ti.users.v1.OrganisationsService/UndeleteOrganisation',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_organisation_pb.UndeleteOrganisationRequest,
    responseType: interface_ti_users_v1_organisation_pb.Organisation,
    requestSerialize: serialize_interface_ti_users_v1_UndeleteOrganisationRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_UndeleteOrganisationRequest,
    responseSerialize: serialize_interface_ti_users_v1_Organisation,
    responseDeserialize: deserialize_interface_ti_users_v1_Organisation,
  },
};

exports.OrganisationsServiceClient = grpc.makeGenericClientConstructor(OrganisationsServiceService, 'OrganisationsService');