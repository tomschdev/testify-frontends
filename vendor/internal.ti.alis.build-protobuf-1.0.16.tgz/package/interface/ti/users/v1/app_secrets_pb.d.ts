import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb'; // proto import: "google/protobuf/timestamp.proto"
import * as google_protobuf_field_mask_pb from 'google-protobuf/google/protobuf/field_mask_pb'; // proto import: "google/protobuf/field_mask.proto"
import * as google_protobuf_empty_pb from 'google-protobuf/google/protobuf/empty_pb'; // proto import: "google/protobuf/empty.proto"


export class AppSecret extends jspb.Message {
  getName(): string;
  setName(value: string): AppSecret;

  getSecretHash(): string;
  setSecretHash(value: string): AppSecret;

  getCreateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreateTime(value?: google_protobuf_timestamp_pb.Timestamp): AppSecret;
  hasCreateTime(): boolean;
  clearCreateTime(): AppSecret;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AppSecret.AsObject;
  static toObject(includeInstance: boolean, msg: AppSecret): AppSecret.AsObject;
  static serializeBinaryToWriter(message: AppSecret, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AppSecret;
  static deserializeBinaryFromReader(message: AppSecret, reader: jspb.BinaryReader): AppSecret;
}

export namespace AppSecret {
  export type AsObject = {
    name: string,
    secretHash: string,
    createTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }
}

export class GenerateAppSecretRequest extends jspb.Message {
  getApp(): string;
  setApp(value: string): GenerateAppSecretRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GenerateAppSecretRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GenerateAppSecretRequest): GenerateAppSecretRequest.AsObject;
  static serializeBinaryToWriter(message: GenerateAppSecretRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GenerateAppSecretRequest;
  static deserializeBinaryFromReader(message: GenerateAppSecretRequest, reader: jspb.BinaryReader): GenerateAppSecretRequest;
}

export namespace GenerateAppSecretRequest {
  export type AsObject = {
    app: string,
  }
}

export class GenerateAppSecretResponse extends jspb.Message {
  getSecretName(): string;
  setSecretName(value: string): GenerateAppSecretResponse;

  getSecretValue(): string;
  setSecretValue(value: string): GenerateAppSecretResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GenerateAppSecretResponse.AsObject;
  static toObject(includeInstance: boolean, msg: GenerateAppSecretResponse): GenerateAppSecretResponse.AsObject;
  static serializeBinaryToWriter(message: GenerateAppSecretResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GenerateAppSecretResponse;
  static deserializeBinaryFromReader(message: GenerateAppSecretResponse, reader: jspb.BinaryReader): GenerateAppSecretResponse;
}

export namespace GenerateAppSecretResponse {
  export type AsObject = {
    secretName: string,
    secretValue: string,
  }
}

export class GetAppSecretRequest extends jspb.Message {
  getName(): string;
  setName(value: string): GetAppSecretRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): GetAppSecretRequest;
  hasReadMask(): boolean;
  clearReadMask(): GetAppSecretRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetAppSecretRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetAppSecretRequest): GetAppSecretRequest.AsObject;
  static serializeBinaryToWriter(message: GetAppSecretRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetAppSecretRequest;
  static deserializeBinaryFromReader(message: GetAppSecretRequest, reader: jspb.BinaryReader): GetAppSecretRequest;
}

export namespace GetAppSecretRequest {
  export type AsObject = {
    name: string,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class DeleteAppSecretRequest extends jspb.Message {
  getName(): string;
  setName(value: string): DeleteAppSecretRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteAppSecretRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteAppSecretRequest): DeleteAppSecretRequest.AsObject;
  static serializeBinaryToWriter(message: DeleteAppSecretRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteAppSecretRequest;
  static deserializeBinaryFromReader(message: DeleteAppSecretRequest, reader: jspb.BinaryReader): DeleteAppSecretRequest;
}

export namespace DeleteAppSecretRequest {
  export type AsObject = {
    name: string,
  }
}

export class ListAppSecretsRequest extends jspb.Message {
  getParent(): string;
  setParent(value: string): ListAppSecretsRequest;

  getPageSize(): number;
  setPageSize(value: number): ListAppSecretsRequest;

  getPageToken(): string;
  setPageToken(value: string): ListAppSecretsRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): ListAppSecretsRequest;
  hasReadMask(): boolean;
  clearReadMask(): ListAppSecretsRequest;

  getFilter(): string;
  setFilter(value: string): ListAppSecretsRequest;

  getOrderBy(): string;
  setOrderBy(value: string): ListAppSecretsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListAppSecretsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListAppSecretsRequest): ListAppSecretsRequest.AsObject;
  static serializeBinaryToWriter(message: ListAppSecretsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListAppSecretsRequest;
  static deserializeBinaryFromReader(message: ListAppSecretsRequest, reader: jspb.BinaryReader): ListAppSecretsRequest;
}

export namespace ListAppSecretsRequest {
  export type AsObject = {
    parent: string,
    pageSize: number,
    pageToken: string,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
    orderBy: string,
  }
}

export class ListAppSecretsResponse extends jspb.Message {
  getAppSecretsList(): Array<AppSecret>;
  setAppSecretsList(value: Array<AppSecret>): ListAppSecretsResponse;
  clearAppSecretsList(): ListAppSecretsResponse;
  addAppSecrets(value?: AppSecret, index?: number): AppSecret;

  getNextPageToken(): string;
  setNextPageToken(value: string): ListAppSecretsResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListAppSecretsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListAppSecretsResponse): ListAppSecretsResponse.AsObject;
  static serializeBinaryToWriter(message: ListAppSecretsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListAppSecretsResponse;
  static deserializeBinaryFromReader(message: ListAppSecretsResponse, reader: jspb.BinaryReader): ListAppSecretsResponse;
}

export namespace ListAppSecretsResponse {
  export type AsObject = {
    appSecretsList: Array<AppSecret.AsObject>,
    nextPageToken: string,
  }
}
