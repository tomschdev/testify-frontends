import * as grpcWeb from 'grpc-web';

import * as alis_open_iam_v1_iam_pb from '@open.alis.services/protobuf/alis/open/iam/v1/iam_pb'; // proto import: "alis/open/iam/v1/iam.proto"
import * as google_iam_v1_iam_policy_pb from '@alis-build/google-common-protos/google/iam/v1/iam_policy_pb'; // proto import: "google/iam/v1/iam_policy.proto"
import * as google_iam_v1_policy_pb from '@alis-build/google-common-protos/google/iam/v1/policy_pb'; // proto import: "google/iam/v1/policy.proto"
import * as interface_ti_users_v1_organisation_pb from '../../../../interface/ti/users/v1/organisation_pb'; // proto import: "interface/ti/users/v1/organisation.proto"


export class OrganisationsServiceClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  getIamPolicy(
    request: google_iam_v1_iam_policy_pb.GetIamPolicyRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_policy_pb.Policy) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_policy_pb.Policy>;

  setIamPolicy(
    request: google_iam_v1_iam_policy_pb.SetIamPolicyRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_policy_pb.Policy) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_policy_pb.Policy>;

  testIamPermissions(
    request: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_iam_policy_pb.TestIamPermissionsResponse) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>;

  batchTestIamPermissions(
    request: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse) => void
  ): grpcWeb.ClientReadableStream<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>;

  addIamBindings(
    request: alis_open_iam_v1_iam_pb.AddIamBindingsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_policy_pb.Policy) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_policy_pb.Policy>;

  removeIamBindings(
    request: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_policy_pb.Policy) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_policy_pb.Policy>;

  createOrganisation(
    request: interface_ti_users_v1_organisation_pb.CreateOrganisationRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_organisation_pb.Organisation) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_organisation_pb.Organisation>;

  getOrganisation(
    request: interface_ti_users_v1_organisation_pb.GetOrganisationRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_organisation_pb.Organisation) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_organisation_pb.Organisation>;

  updateOrganisation(
    request: interface_ti_users_v1_organisation_pb.UpdateOrganisationRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_organisation_pb.Organisation) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_organisation_pb.Organisation>;

  listOrganisations(
    request: interface_ti_users_v1_organisation_pb.ListOrganisationsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_organisation_pb.ListOrganisationsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_organisation_pb.ListOrganisationsResponse>;

  listMyOrganisations(
    request: interface_ti_users_v1_organisation_pb.ListMyOrganisationsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_organisation_pb.ListMyOrganisationsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_organisation_pb.ListMyOrganisationsResponse>;

  deleteOrganisation(
    request: interface_ti_users_v1_organisation_pb.DeleteOrganisationRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_organisation_pb.Organisation) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_organisation_pb.Organisation>;

  undeleteOrganisation(
    request: interface_ti_users_v1_organisation_pb.UndeleteOrganisationRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_organisation_pb.Organisation) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_organisation_pb.Organisation>;

}

export class OrganisationsServicePromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  getIamPolicy(
    request: google_iam_v1_iam_policy_pb.GetIamPolicyRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_policy_pb.Policy>;

  setIamPolicy(
    request: google_iam_v1_iam_policy_pb.SetIamPolicyRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_policy_pb.Policy>;

  testIamPermissions(
    request: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>;

  batchTestIamPermissions(
    request: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>;

  addIamBindings(
    request: alis_open_iam_v1_iam_pb.AddIamBindingsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_policy_pb.Policy>;

  removeIamBindings(
    request: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_policy_pb.Policy>;

  createOrganisation(
    request: interface_ti_users_v1_organisation_pb.CreateOrganisationRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_organisation_pb.Organisation>;

  getOrganisation(
    request: interface_ti_users_v1_organisation_pb.GetOrganisationRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_organisation_pb.Organisation>;

  updateOrganisation(
    request: interface_ti_users_v1_organisation_pb.UpdateOrganisationRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_organisation_pb.Organisation>;

  listOrganisations(
    request: interface_ti_users_v1_organisation_pb.ListOrganisationsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_organisation_pb.ListOrganisationsResponse>;

  listMyOrganisations(
    request: interface_ti_users_v1_organisation_pb.ListMyOrganisationsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_organisation_pb.ListMyOrganisationsResponse>;

  deleteOrganisation(
    request: interface_ti_users_v1_organisation_pb.DeleteOrganisationRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_organisation_pb.Organisation>;

  undeleteOrganisation(
    request: interface_ti_users_v1_organisation_pb.UndeleteOrganisationRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_organisation_pb.Organisation>;

}
