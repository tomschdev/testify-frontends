// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('@grpc/grpc-js');
var interface_ti_users_v1_group_pb = require('../../../../interface/ti/users/v1/group_pb.js');
var google_protobuf_timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb.js');
var google_protobuf_field_mask_pb = require('google-protobuf/google/protobuf/field_mask_pb.js');

function serialize_interface_ti_users_v1_BatchDeleteGroupsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.BatchDeleteGroupsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchDeleteGroupsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchDeleteGroupsRequest(buffer_arg) {
  return interface_ti_users_v1_group_pb.BatchDeleteGroupsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchDeleteGroupsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.BatchDeleteGroupsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchDeleteGroupsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchDeleteGroupsResponse(buffer_arg) {
  return interface_ti_users_v1_group_pb.BatchDeleteGroupsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchGetGroupsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.BatchGetGroupsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchGetGroupsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchGetGroupsRequest(buffer_arg) {
  return interface_ti_users_v1_group_pb.BatchGetGroupsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchGetGroupsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.BatchGetGroupsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchGetGroupsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchGetGroupsResponse(buffer_arg) {
  return interface_ti_users_v1_group_pb.BatchGetGroupsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_CreateGroupRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.CreateGroupRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.CreateGroupRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_CreateGroupRequest(buffer_arg) {
  return interface_ti_users_v1_group_pb.CreateGroupRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_DeleteGroupRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.DeleteGroupRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.DeleteGroupRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_DeleteGroupRequest(buffer_arg) {
  return interface_ti_users_v1_group_pb.DeleteGroupRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_GetGroupRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.GetGroupRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.GetGroupRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_GetGroupRequest(buffer_arg) {
  return interface_ti_users_v1_group_pb.GetGroupRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_Group(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.Group)) {
    throw new Error('Expected argument of type interface.ti.users.v1.Group');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_Group(buffer_arg) {
  return interface_ti_users_v1_group_pb.Group.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListGroupsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.ListGroupsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListGroupsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListGroupsRequest(buffer_arg) {
  return interface_ti_users_v1_group_pb.ListGroupsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListGroupsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.ListGroupsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListGroupsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListGroupsResponse(buffer_arg) {
  return interface_ti_users_v1_group_pb.ListGroupsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_StreamGroupsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.StreamGroupsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.StreamGroupsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_StreamGroupsRequest(buffer_arg) {
  return interface_ti_users_v1_group_pb.StreamGroupsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_SyncGroupRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.SyncGroupRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.SyncGroupRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_SyncGroupRequest(buffer_arg) {
  return interface_ti_users_v1_group_pb.SyncGroupRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_SyncGroupResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.SyncGroupResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.SyncGroupResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_SyncGroupResponse(buffer_arg) {
  return interface_ti_users_v1_group_pb.SyncGroupResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_UpdateGroupRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_group_pb.UpdateGroupRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.UpdateGroupRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_UpdateGroupRequest(buffer_arg) {
  return interface_ti_users_v1_group_pb.UpdateGroupRequest.deserializeBinary(new Uint8Array(buffer_arg));
}


// GroupsService
var GroupsServiceService = exports.GroupsServiceService = {
  // Creates a new group.
createGroup: {
    path: '/interface.ti.users.v1.GroupsService/CreateGroup',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_group_pb.CreateGroupRequest,
    responseType: interface_ti_users_v1_group_pb.Group,
    requestSerialize: serialize_interface_ti_users_v1_CreateGroupRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_CreateGroupRequest,
    responseSerialize: serialize_interface_ti_users_v1_Group,
    responseDeserialize: deserialize_interface_ti_users_v1_Group,
  },
  // Gets an group by its resource name.
getGroup: {
    path: '/interface.ti.users.v1.GroupsService/GetGroup',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_group_pb.GetGroupRequest,
    responseType: interface_ti_users_v1_group_pb.Group,
    requestSerialize: serialize_interface_ti_users_v1_GetGroupRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_GetGroupRequest,
    responseSerialize: serialize_interface_ti_users_v1_Group,
    responseDeserialize: deserialize_interface_ti_users_v1_Group,
  },
  // Updates an group.
updateGroup: {
    path: '/interface.ti.users.v1.GroupsService/UpdateGroup',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_group_pb.UpdateGroupRequest,
    responseType: interface_ti_users_v1_group_pb.Group,
    requestSerialize: serialize_interface_ti_users_v1_UpdateGroupRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_UpdateGroupRequest,
    responseSerialize: serialize_interface_ti_users_v1_Group,
    responseDeserialize: deserialize_interface_ti_users_v1_Group,
  },
  // Lists all groups.
listGroups: {
    path: '/interface.ti.users.v1.GroupsService/ListGroups',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_group_pb.ListGroupsRequest,
    responseType: interface_ti_users_v1_group_pb.ListGroupsResponse,
    requestSerialize: serialize_interface_ti_users_v1_ListGroupsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_ListGroupsRequest,
    responseSerialize: serialize_interface_ti_users_v1_ListGroupsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_ListGroupsResponse,
  },
  // Deletes an group.
deleteGroup: {
    path: '/interface.ti.users.v1.GroupsService/DeleteGroup',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_group_pb.DeleteGroupRequest,
    responseType: interface_ti_users_v1_group_pb.Group,
    requestSerialize: serialize_interface_ti_users_v1_DeleteGroupRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_DeleteGroupRequest,
    responseSerialize: serialize_interface_ti_users_v1_Group,
    responseDeserialize: deserialize_interface_ti_users_v1_Group,
  },
  // Get a batch of groups by their resource names.
batchGetGroups: {
    path: '/interface.ti.users.v1.GroupsService/BatchGetGroups',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_group_pb.BatchGetGroupsRequest,
    responseType: interface_ti_users_v1_group_pb.BatchGetGroupsResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchGetGroupsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchGetGroupsRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchGetGroupsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchGetGroupsResponse,
  },
  // Batch deletes groups.
batchDeleteGroups: {
    path: '/interface.ti.users.v1.GroupsService/BatchDeleteGroups',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_group_pb.BatchDeleteGroupsRequest,
    responseType: interface_ti_users_v1_group_pb.BatchDeleteGroupsResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchDeleteGroupsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchDeleteGroupsRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchDeleteGroupsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchDeleteGroupsResponse,
  },
  // Stream groups.
streamGroups: {
    path: '/interface.ti.users.v1.GroupsService/StreamGroups',
    requestStream: false,
    responseStream: true,
    requestType: interface_ti_users_v1_group_pb.StreamGroupsRequest,
    responseType: interface_ti_users_v1_group_pb.Group,
    requestSerialize: serialize_interface_ti_users_v1_StreamGroupsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_StreamGroupsRequest,
    responseSerialize: serialize_interface_ti_users_v1_Group,
    responseDeserialize: deserialize_interface_ti_users_v1_Group,
  },
  // Syncs the specified group to its list of users
syncGroup: {
    path: '/interface.ti.users.v1.GroupsService/SyncGroup',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_group_pb.SyncGroupRequest,
    responseType: interface_ti_users_v1_group_pb.SyncGroupResponse,
    requestSerialize: serialize_interface_ti_users_v1_SyncGroupRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_SyncGroupRequest,
    responseSerialize: serialize_interface_ti_users_v1_SyncGroupResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_SyncGroupResponse,
  },
};

exports.GroupsServiceClient = grpc.makeGenericClientConstructor(GroupsServiceService, 'GroupsService');