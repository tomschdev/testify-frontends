import * as grpcWeb from 'grpc-web';

import * as interface_ti_users_v1_group_pb from '../../../../interface/ti/users/v1/group_pb'; // proto import: "interface/ti/users/v1/group.proto"


export class GroupsServiceClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  createGroup(
    request: interface_ti_users_v1_group_pb.CreateGroupRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_group_pb.Group) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_group_pb.Group>;

  getGroup(
    request: interface_ti_users_v1_group_pb.GetGroupRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_group_pb.Group) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_group_pb.Group>;

  updateGroup(
    request: interface_ti_users_v1_group_pb.UpdateGroupRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_group_pb.Group) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_group_pb.Group>;

  listGroups(
    request: interface_ti_users_v1_group_pb.ListGroupsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_group_pb.ListGroupsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_group_pb.ListGroupsResponse>;

  deleteGroup(
    request: interface_ti_users_v1_group_pb.DeleteGroupRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_group_pb.Group) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_group_pb.Group>;

  batchGetGroups(
    request: interface_ti_users_v1_group_pb.BatchGetGroupsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_group_pb.BatchGetGroupsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_group_pb.BatchGetGroupsResponse>;

  batchDeleteGroups(
    request: interface_ti_users_v1_group_pb.BatchDeleteGroupsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_group_pb.BatchDeleteGroupsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_group_pb.BatchDeleteGroupsResponse>;

  streamGroups(
    request: interface_ti_users_v1_group_pb.StreamGroupsRequest,
    metadata?: grpcWeb.Metadata
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_group_pb.Group>;

  syncGroup(
    request: interface_ti_users_v1_group_pb.SyncGroupRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_group_pb.SyncGroupResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_group_pb.SyncGroupResponse>;

}

export class GroupsServicePromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  createGroup(
    request: interface_ti_users_v1_group_pb.CreateGroupRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_group_pb.Group>;

  getGroup(
    request: interface_ti_users_v1_group_pb.GetGroupRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_group_pb.Group>;

  updateGroup(
    request: interface_ti_users_v1_group_pb.UpdateGroupRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_group_pb.Group>;

  listGroups(
    request: interface_ti_users_v1_group_pb.ListGroupsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_group_pb.ListGroupsResponse>;

  deleteGroup(
    request: interface_ti_users_v1_group_pb.DeleteGroupRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_group_pb.Group>;

  batchGetGroups(
    request: interface_ti_users_v1_group_pb.BatchGetGroupsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_group_pb.BatchGetGroupsResponse>;

  batchDeleteGroups(
    request: interface_ti_users_v1_group_pb.BatchDeleteGroupsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_group_pb.BatchDeleteGroupsResponse>;

  streamGroups(
    request: interface_ti_users_v1_group_pb.StreamGroupsRequest,
    metadata?: grpcWeb.Metadata
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_group_pb.Group>;

  syncGroup(
    request: interface_ti_users_v1_group_pb.SyncGroupRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_group_pb.SyncGroupResponse>;

}
