// GENERATED CODE -- DO NOT EDIT!

// package: interface.ti.users.v1
// file: interface/ti/users/v1/auth_req.proto

import * as interface_ti_users_v1_auth_req_pb from "../../../../interface/ti/users/v1/auth_req_pb";
import * as grpc from "@grpc/grpc-js";

interface IAuthReqsServiceService extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
  createAuthReq: grpc.MethodDefinition<interface_ti_users_v1_auth_req_pb.CreateAuthReqRequest, interface_ti_users_v1_auth_req_pb.AuthReq>;
  getAuthReq: grpc.MethodDefinition<interface_ti_users_v1_auth_req_pb.GetAuthReqRequest, interface_ti_users_v1_auth_req_pb.AuthReq>;
  updateAuthReq: grpc.MethodDefinition<interface_ti_users_v1_auth_req_pb.UpdateAuthReqRequest, interface_ti_users_v1_auth_req_pb.AuthReq>;
  listAuthReqs: grpc.MethodDefinition<interface_ti_users_v1_auth_req_pb.ListAuthReqsRequest, interface_ti_users_v1_auth_req_pb.ListAuthReqsResponse>;
  deleteAuthReq: grpc.MethodDefinition<interface_ti_users_v1_auth_req_pb.DeleteAuthReqRequest, interface_ti_users_v1_auth_req_pb.AuthReq>;
  batchGetAuthReqs: grpc.MethodDefinition<interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsRequest, interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsResponse>;
  batchDeleteAuthReqs: grpc.MethodDefinition<interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsRequest, interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsResponse>;
  streamAuthReqs: grpc.MethodDefinition<interface_ti_users_v1_auth_req_pb.StreamAuthReqsRequest, interface_ti_users_v1_auth_req_pb.AuthReq>;
}

export const AuthReqsServiceService: IAuthReqsServiceService;

export interface IAuthReqsServiceServer extends grpc.UntypedServiceImplementation {
  createAuthReq: grpc.handleUnaryCall<interface_ti_users_v1_auth_req_pb.CreateAuthReqRequest, interface_ti_users_v1_auth_req_pb.AuthReq>;
  getAuthReq: grpc.handleUnaryCall<interface_ti_users_v1_auth_req_pb.GetAuthReqRequest, interface_ti_users_v1_auth_req_pb.AuthReq>;
  updateAuthReq: grpc.handleUnaryCall<interface_ti_users_v1_auth_req_pb.UpdateAuthReqRequest, interface_ti_users_v1_auth_req_pb.AuthReq>;
  listAuthReqs: grpc.handleUnaryCall<interface_ti_users_v1_auth_req_pb.ListAuthReqsRequest, interface_ti_users_v1_auth_req_pb.ListAuthReqsResponse>;
  deleteAuthReq: grpc.handleUnaryCall<interface_ti_users_v1_auth_req_pb.DeleteAuthReqRequest, interface_ti_users_v1_auth_req_pb.AuthReq>;
  batchGetAuthReqs: grpc.handleUnaryCall<interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsRequest, interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsResponse>;
  batchDeleteAuthReqs: grpc.handleUnaryCall<interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsRequest, interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsResponse>;
  streamAuthReqs: grpc.handleServerStreamingCall<interface_ti_users_v1_auth_req_pb.StreamAuthReqsRequest, interface_ti_users_v1_auth_req_pb.AuthReq>;
}

export class AuthReqsServiceClient extends grpc.Client {
  constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
  createAuthReq(argument: interface_ti_users_v1_auth_req_pb.CreateAuthReqRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.AuthReq>): grpc.ClientUnaryCall;
  createAuthReq(argument: interface_ti_users_v1_auth_req_pb.CreateAuthReqRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.AuthReq>): grpc.ClientUnaryCall;
  createAuthReq(argument: interface_ti_users_v1_auth_req_pb.CreateAuthReqRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.AuthReq>): grpc.ClientUnaryCall;
  getAuthReq(argument: interface_ti_users_v1_auth_req_pb.GetAuthReqRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.AuthReq>): grpc.ClientUnaryCall;
  getAuthReq(argument: interface_ti_users_v1_auth_req_pb.GetAuthReqRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.AuthReq>): grpc.ClientUnaryCall;
  getAuthReq(argument: interface_ti_users_v1_auth_req_pb.GetAuthReqRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.AuthReq>): grpc.ClientUnaryCall;
  updateAuthReq(argument: interface_ti_users_v1_auth_req_pb.UpdateAuthReqRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.AuthReq>): grpc.ClientUnaryCall;
  updateAuthReq(argument: interface_ti_users_v1_auth_req_pb.UpdateAuthReqRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.AuthReq>): grpc.ClientUnaryCall;
  updateAuthReq(argument: interface_ti_users_v1_auth_req_pb.UpdateAuthReqRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.AuthReq>): grpc.ClientUnaryCall;
  listAuthReqs(argument: interface_ti_users_v1_auth_req_pb.ListAuthReqsRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.ListAuthReqsResponse>): grpc.ClientUnaryCall;
  listAuthReqs(argument: interface_ti_users_v1_auth_req_pb.ListAuthReqsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.ListAuthReqsResponse>): grpc.ClientUnaryCall;
  listAuthReqs(argument: interface_ti_users_v1_auth_req_pb.ListAuthReqsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.ListAuthReqsResponse>): grpc.ClientUnaryCall;
  deleteAuthReq(argument: interface_ti_users_v1_auth_req_pb.DeleteAuthReqRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.AuthReq>): grpc.ClientUnaryCall;
  deleteAuthReq(argument: interface_ti_users_v1_auth_req_pb.DeleteAuthReqRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.AuthReq>): grpc.ClientUnaryCall;
  deleteAuthReq(argument: interface_ti_users_v1_auth_req_pb.DeleteAuthReqRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.AuthReq>): grpc.ClientUnaryCall;
  batchGetAuthReqs(argument: interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsResponse>): grpc.ClientUnaryCall;
  batchGetAuthReqs(argument: interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsResponse>): grpc.ClientUnaryCall;
  batchGetAuthReqs(argument: interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsResponse>): grpc.ClientUnaryCall;
  batchDeleteAuthReqs(argument: interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsRequest, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsResponse>): grpc.ClientUnaryCall;
  batchDeleteAuthReqs(argument: interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsResponse>): grpc.ClientUnaryCall;
  batchDeleteAuthReqs(argument: interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsResponse>): grpc.ClientUnaryCall;
  streamAuthReqs(argument: interface_ti_users_v1_auth_req_pb.StreamAuthReqsRequest, metadataOrOptions?: grpc.Metadata | grpc.CallOptions | null): grpc.ClientReadableStream<interface_ti_users_v1_auth_req_pb.AuthReq>;
  streamAuthReqs(argument: interface_ti_users_v1_auth_req_pb.StreamAuthReqsRequest, metadata?: grpc.Metadata | null, options?: grpc.CallOptions | null): grpc.ClientReadableStream<interface_ti_users_v1_auth_req_pb.AuthReq>;
}