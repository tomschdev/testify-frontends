// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('@grpc/grpc-js');
var interface_ti_users_v1_auth_req_pb = require('../../../../interface/ti/users/v1/auth_req_pb.js');
var google_protobuf_timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb.js');
var google_protobuf_field_mask_pb = require('google-protobuf/google/protobuf/field_mask_pb.js');

function serialize_interface_ti_users_v1_AuthReq(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_req_pb.AuthReq)) {
    throw new Error('Expected argument of type interface.ti.users.v1.AuthReq');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_AuthReq(buffer_arg) {
  return interface_ti_users_v1_auth_req_pb.AuthReq.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchDeleteAuthReqsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchDeleteAuthReqsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchDeleteAuthReqsRequest(buffer_arg) {
  return interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchDeleteAuthReqsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchDeleteAuthReqsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchDeleteAuthReqsResponse(buffer_arg) {
  return interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchGetAuthReqsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchGetAuthReqsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchGetAuthReqsRequest(buffer_arg) {
  return interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchGetAuthReqsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchGetAuthReqsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchGetAuthReqsResponse(buffer_arg) {
  return interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_CreateAuthReqRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_req_pb.CreateAuthReqRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.CreateAuthReqRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_CreateAuthReqRequest(buffer_arg) {
  return interface_ti_users_v1_auth_req_pb.CreateAuthReqRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_DeleteAuthReqRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_req_pb.DeleteAuthReqRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.DeleteAuthReqRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_DeleteAuthReqRequest(buffer_arg) {
  return interface_ti_users_v1_auth_req_pb.DeleteAuthReqRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_GetAuthReqRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_req_pb.GetAuthReqRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.GetAuthReqRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_GetAuthReqRequest(buffer_arg) {
  return interface_ti_users_v1_auth_req_pb.GetAuthReqRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListAuthReqsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_req_pb.ListAuthReqsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListAuthReqsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListAuthReqsRequest(buffer_arg) {
  return interface_ti_users_v1_auth_req_pb.ListAuthReqsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListAuthReqsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_req_pb.ListAuthReqsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListAuthReqsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListAuthReqsResponse(buffer_arg) {
  return interface_ti_users_v1_auth_req_pb.ListAuthReqsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_StreamAuthReqsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_req_pb.StreamAuthReqsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.StreamAuthReqsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_StreamAuthReqsRequest(buffer_arg) {
  return interface_ti_users_v1_auth_req_pb.StreamAuthReqsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_UpdateAuthReqRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_req_pb.UpdateAuthReqRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.UpdateAuthReqRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_UpdateAuthReqRequest(buffer_arg) {
  return interface_ti_users_v1_auth_req_pb.UpdateAuthReqRequest.deserializeBinary(new Uint8Array(buffer_arg));
}


// AuthReqsService provides operations for managing Client-Initiated Backchannel Authentication (CIBA) requests.
var AuthReqsServiceService = exports.AuthReqsServiceService = {
  // Creates a new auth_req.
createAuthReq: {
    path: '/interface.ti.users.v1.AuthReqsService/CreateAuthReq',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_req_pb.CreateAuthReqRequest,
    responseType: interface_ti_users_v1_auth_req_pb.AuthReq,
    requestSerialize: serialize_interface_ti_users_v1_CreateAuthReqRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_CreateAuthReqRequest,
    responseSerialize: serialize_interface_ti_users_v1_AuthReq,
    responseDeserialize: deserialize_interface_ti_users_v1_AuthReq,
  },
  // Gets an auth_req by its resource name.
getAuthReq: {
    path: '/interface.ti.users.v1.AuthReqsService/GetAuthReq',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_req_pb.GetAuthReqRequest,
    responseType: interface_ti_users_v1_auth_req_pb.AuthReq,
    requestSerialize: serialize_interface_ti_users_v1_GetAuthReqRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_GetAuthReqRequest,
    responseSerialize: serialize_interface_ti_users_v1_AuthReq,
    responseDeserialize: deserialize_interface_ti_users_v1_AuthReq,
  },
  // Updates an auth_req.
updateAuthReq: {
    path: '/interface.ti.users.v1.AuthReqsService/UpdateAuthReq',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_req_pb.UpdateAuthReqRequest,
    responseType: interface_ti_users_v1_auth_req_pb.AuthReq,
    requestSerialize: serialize_interface_ti_users_v1_UpdateAuthReqRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_UpdateAuthReqRequest,
    responseSerialize: serialize_interface_ti_users_v1_AuthReq,
    responseDeserialize: deserialize_interface_ti_users_v1_AuthReq,
  },
  // Lists all authReqs.
listAuthReqs: {
    path: '/interface.ti.users.v1.AuthReqsService/ListAuthReqs',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_req_pb.ListAuthReqsRequest,
    responseType: interface_ti_users_v1_auth_req_pb.ListAuthReqsResponse,
    requestSerialize: serialize_interface_ti_users_v1_ListAuthReqsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_ListAuthReqsRequest,
    responseSerialize: serialize_interface_ti_users_v1_ListAuthReqsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_ListAuthReqsResponse,
  },
  // Deletes an auth_req.
deleteAuthReq: {
    path: '/interface.ti.users.v1.AuthReqsService/DeleteAuthReq',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_req_pb.DeleteAuthReqRequest,
    responseType: interface_ti_users_v1_auth_req_pb.AuthReq,
    requestSerialize: serialize_interface_ti_users_v1_DeleteAuthReqRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_DeleteAuthReqRequest,
    responseSerialize: serialize_interface_ti_users_v1_AuthReq,
    responseDeserialize: deserialize_interface_ti_users_v1_AuthReq,
  },
  // Get a batch of authReqs by their resource names.
batchGetAuthReqs: {
    path: '/interface.ti.users.v1.AuthReqsService/BatchGetAuthReqs',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsRequest,
    responseType: interface_ti_users_v1_auth_req_pb.BatchGetAuthReqsResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchGetAuthReqsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchGetAuthReqsRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchGetAuthReqsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchGetAuthReqsResponse,
  },
  // Batch deletes authReqs.
batchDeleteAuthReqs: {
    path: '/interface.ti.users.v1.AuthReqsService/BatchDeleteAuthReqs',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsRequest,
    responseType: interface_ti_users_v1_auth_req_pb.BatchDeleteAuthReqsResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchDeleteAuthReqsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchDeleteAuthReqsRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchDeleteAuthReqsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchDeleteAuthReqsResponse,
  },
  // Stream authReqs.
streamAuthReqs: {
    path: '/interface.ti.users.v1.AuthReqsService/StreamAuthReqs',
    requestStream: false,
    responseStream: true,
    requestType: interface_ti_users_v1_auth_req_pb.StreamAuthReqsRequest,
    responseType: interface_ti_users_v1_auth_req_pb.AuthReq,
    requestSerialize: serialize_interface_ti_users_v1_StreamAuthReqsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_StreamAuthReqsRequest,
    responseSerialize: serialize_interface_ti_users_v1_AuthReq,
    responseDeserialize: deserialize_interface_ti_users_v1_AuthReq,
  },
};

exports.AuthReqsServiceClient = grpc.makeGenericClientConstructor(AuthReqsServiceService, 'AuthReqsService');