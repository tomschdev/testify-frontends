// GENERATED CODE -- DO NOT EDIT!

// package: interface.ti.users.v1
// file: interface/ti/users/v1/app_secrets.proto

import * as interface_ti_users_v1_app_secrets_pb from "../../../../interface/ti/users/v1/app_secrets_pb";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as grpc from "@grpc/grpc-js";

interface IAppSecretsServiceService extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
  generateAppSecret: grpc.MethodDefinition<interface_ti_users_v1_app_secrets_pb.GenerateAppSecretRequest, interface_ti_users_v1_app_secrets_pb.GenerateAppSecretResponse>;
  getAppSecret: grpc.MethodDefinition<interface_ti_users_v1_app_secrets_pb.GetAppSecretRequest, interface_ti_users_v1_app_secrets_pb.AppSecret>;
  listAppSecrets: grpc.MethodDefinition<interface_ti_users_v1_app_secrets_pb.ListAppSecretsRequest, interface_ti_users_v1_app_secrets_pb.ListAppSecretsResponse>;
  deleteAppSecret: grpc.MethodDefinition<interface_ti_users_v1_app_secrets_pb.DeleteAppSecretRequest, google_protobuf_empty_pb.Empty>;
}

export const AppSecretsServiceService: IAppSecretsServiceService;

export interface IAppSecretsServiceServer extends grpc.UntypedServiceImplementation {
  generateAppSecret: grpc.handleUnaryCall<interface_ti_users_v1_app_secrets_pb.GenerateAppSecretRequest, interface_ti_users_v1_app_secrets_pb.GenerateAppSecretResponse>;
  getAppSecret: grpc.handleUnaryCall<interface_ti_users_v1_app_secrets_pb.GetAppSecretRequest, interface_ti_users_v1_app_secrets_pb.AppSecret>;
  listAppSecrets: grpc.handleUnaryCall<interface_ti_users_v1_app_secrets_pb.ListAppSecretsRequest, interface_ti_users_v1_app_secrets_pb.ListAppSecretsResponse>;
  deleteAppSecret: grpc.handleUnaryCall<interface_ti_users_v1_app_secrets_pb.DeleteAppSecretRequest, google_protobuf_empty_pb.Empty>;
}

export class AppSecretsServiceClient extends grpc.Client {
  constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
  generateAppSecret(argument: interface_ti_users_v1_app_secrets_pb.GenerateAppSecretRequest, callback: grpc.requestCallback<interface_ti_users_v1_app_secrets_pb.GenerateAppSecretResponse>): grpc.ClientUnaryCall;
  generateAppSecret(argument: interface_ti_users_v1_app_secrets_pb.GenerateAppSecretRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_app_secrets_pb.GenerateAppSecretResponse>): grpc.ClientUnaryCall;
  generateAppSecret(argument: interface_ti_users_v1_app_secrets_pb.GenerateAppSecretRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_app_secrets_pb.GenerateAppSecretResponse>): grpc.ClientUnaryCall;
  getAppSecret(argument: interface_ti_users_v1_app_secrets_pb.GetAppSecretRequest, callback: grpc.requestCallback<interface_ti_users_v1_app_secrets_pb.AppSecret>): grpc.ClientUnaryCall;
  getAppSecret(argument: interface_ti_users_v1_app_secrets_pb.GetAppSecretRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_app_secrets_pb.AppSecret>): grpc.ClientUnaryCall;
  getAppSecret(argument: interface_ti_users_v1_app_secrets_pb.GetAppSecretRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_app_secrets_pb.AppSecret>): grpc.ClientUnaryCall;
  listAppSecrets(argument: interface_ti_users_v1_app_secrets_pb.ListAppSecretsRequest, callback: grpc.requestCallback<interface_ti_users_v1_app_secrets_pb.ListAppSecretsResponse>): grpc.ClientUnaryCall;
  listAppSecrets(argument: interface_ti_users_v1_app_secrets_pb.ListAppSecretsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_app_secrets_pb.ListAppSecretsResponse>): grpc.ClientUnaryCall;
  listAppSecrets(argument: interface_ti_users_v1_app_secrets_pb.ListAppSecretsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_app_secrets_pb.ListAppSecretsResponse>): grpc.ClientUnaryCall;
  deleteAppSecret(argument: interface_ti_users_v1_app_secrets_pb.DeleteAppSecretRequest, callback: grpc.requestCallback<google_protobuf_empty_pb.Empty>): grpc.ClientUnaryCall;
  deleteAppSecret(argument: interface_ti_users_v1_app_secrets_pb.DeleteAppSecretRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<google_protobuf_empty_pb.Empty>): grpc.ClientUnaryCall;
  deleteAppSecret(argument: interface_ti_users_v1_app_secrets_pb.DeleteAppSecretRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<google_protobuf_empty_pb.Empty>): grpc.ClientUnaryCall;
}