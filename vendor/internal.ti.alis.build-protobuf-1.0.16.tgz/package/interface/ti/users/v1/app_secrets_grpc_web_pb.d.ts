import * as grpcWeb from 'grpc-web';

import * as google_protobuf_empty_pb from 'google-protobuf/google/protobuf/empty_pb'; // proto import: "google/protobuf/empty.proto"
import * as interface_ti_users_v1_app_secrets_pb from '../../../../interface/ti/users/v1/app_secrets_pb'; // proto import: "interface/ti/users/v1/app_secrets.proto"


export class AppSecretsServiceClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  generateAppSecret(
    request: interface_ti_users_v1_app_secrets_pb.GenerateAppSecretRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_app_secrets_pb.GenerateAppSecretResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_app_secrets_pb.GenerateAppSecretResponse>;

  getAppSecret(
    request: interface_ti_users_v1_app_secrets_pb.GetAppSecretRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_app_secrets_pb.AppSecret) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_app_secrets_pb.AppSecret>;

  listAppSecrets(
    request: interface_ti_users_v1_app_secrets_pb.ListAppSecretsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_app_secrets_pb.ListAppSecretsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_app_secrets_pb.ListAppSecretsResponse>;

  deleteAppSecret(
    request: interface_ti_users_v1_app_secrets_pb.DeleteAppSecretRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_protobuf_empty_pb.Empty) => void
  ): grpcWeb.ClientReadableStream<google_protobuf_empty_pb.Empty>;

}

export class AppSecretsServicePromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  generateAppSecret(
    request: interface_ti_users_v1_app_secrets_pb.GenerateAppSecretRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_app_secrets_pb.GenerateAppSecretResponse>;

  getAppSecret(
    request: interface_ti_users_v1_app_secrets_pb.GetAppSecretRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_app_secrets_pb.AppSecret>;

  listAppSecrets(
    request: interface_ti_users_v1_app_secrets_pb.ListAppSecretsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_app_secrets_pb.ListAppSecretsResponse>;

  deleteAppSecret(
    request: interface_ti_users_v1_app_secrets_pb.DeleteAppSecretRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_protobuf_empty_pb.Empty>;

}
