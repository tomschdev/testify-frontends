// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('@grpc/grpc-js');
var interface_ti_users_v1_app_secrets_pb = require('../../../../interface/ti/users/v1/app_secrets_pb.js');
var google_protobuf_timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb.js');
var google_protobuf_field_mask_pb = require('google-protobuf/google/protobuf/field_mask_pb.js');
var google_protobuf_empty_pb = require('google-protobuf/google/protobuf/empty_pb.js');

function serialize_google_protobuf_Empty(arg) {
  if (!(arg instanceof google_protobuf_empty_pb.Empty)) {
    throw new Error('Expected argument of type google.protobuf.Empty');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_protobuf_Empty(buffer_arg) {
  return google_protobuf_empty_pb.Empty.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_AppSecret(arg) {
  if (!(arg instanceof interface_ti_users_v1_app_secrets_pb.AppSecret)) {
    throw new Error('Expected argument of type interface.ti.users.v1.AppSecret');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_AppSecret(buffer_arg) {
  return interface_ti_users_v1_app_secrets_pb.AppSecret.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_DeleteAppSecretRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_app_secrets_pb.DeleteAppSecretRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.DeleteAppSecretRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_DeleteAppSecretRequest(buffer_arg) {
  return interface_ti_users_v1_app_secrets_pb.DeleteAppSecretRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_GenerateAppSecretRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_app_secrets_pb.GenerateAppSecretRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.GenerateAppSecretRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_GenerateAppSecretRequest(buffer_arg) {
  return interface_ti_users_v1_app_secrets_pb.GenerateAppSecretRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_GenerateAppSecretResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_app_secrets_pb.GenerateAppSecretResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.GenerateAppSecretResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_GenerateAppSecretResponse(buffer_arg) {
  return interface_ti_users_v1_app_secrets_pb.GenerateAppSecretResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_GetAppSecretRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_app_secrets_pb.GetAppSecretRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.GetAppSecretRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_GetAppSecretRequest(buffer_arg) {
  return interface_ti_users_v1_app_secrets_pb.GetAppSecretRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListAppSecretsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_app_secrets_pb.ListAppSecretsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListAppSecretsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListAppSecretsRequest(buffer_arg) {
  return interface_ti_users_v1_app_secrets_pb.ListAppSecretsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListAppSecretsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_app_secrets_pb.ListAppSecretsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListAppSecretsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListAppSecretsResponse(buffer_arg) {
  return interface_ti_users_v1_app_secrets_pb.ListAppSecretsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}


// AppsService manages secrets of OAuth2 apps (clients) for an environment.
var AppSecretsServiceService = exports.AppSecretsServiceService = {
  // Generates a new secret to an app.
generateAppSecret: {
    path: '/interface.ti.users.v1.AppSecretsService/GenerateAppSecret',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_app_secrets_pb.GenerateAppSecretRequest,
    responseType: interface_ti_users_v1_app_secrets_pb.GenerateAppSecretResponse,
    requestSerialize: serialize_interface_ti_users_v1_GenerateAppSecretRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_GenerateAppSecretRequest,
    responseSerialize: serialize_interface_ti_users_v1_GenerateAppSecretResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_GenerateAppSecretResponse,
  },
  // Gets an app secret by its resource name.
getAppSecret: {
    path: '/interface.ti.users.v1.AppSecretsService/GetAppSecret',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_app_secrets_pb.GetAppSecretRequest,
    responseType: interface_ti_users_v1_app_secrets_pb.AppSecret,
    requestSerialize: serialize_interface_ti_users_v1_GetAppSecretRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_GetAppSecretRequest,
    responseSerialize: serialize_interface_ti_users_v1_AppSecret,
    responseDeserialize: deserialize_interface_ti_users_v1_AppSecret,
  },
  // Lists all app secrets.
listAppSecrets: {
    path: '/interface.ti.users.v1.AppSecretsService/ListAppSecrets',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_app_secrets_pb.ListAppSecretsRequest,
    responseType: interface_ti_users_v1_app_secrets_pb.ListAppSecretsResponse,
    requestSerialize: serialize_interface_ti_users_v1_ListAppSecretsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_ListAppSecretsRequest,
    responseSerialize: serialize_interface_ti_users_v1_ListAppSecretsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_ListAppSecretsResponse,
  },
  // Deletes an app secret.
deleteAppSecret: {
    path: '/interface.ti.users.v1.AppSecretsService/DeleteAppSecret',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_app_secrets_pb.DeleteAppSecretRequest,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_interface_ti_users_v1_DeleteAppSecretRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_DeleteAppSecretRequest,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
};

exports.AppSecretsServiceClient = grpc.makeGenericClientConstructor(AppSecretsServiceService, 'AppSecretsService');