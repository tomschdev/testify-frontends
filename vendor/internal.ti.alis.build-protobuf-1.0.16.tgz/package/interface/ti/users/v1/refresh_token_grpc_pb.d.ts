// GENERATED CODE -- DO NOT EDIT!

// package: interface.ti.users.v1
// file: interface/ti/users/v1/refresh_token.proto

import * as interface_ti_users_v1_refresh_token_pb from "../../../../interface/ti/users/v1/refresh_token_pb";
import * as grpc from "@grpc/grpc-js";

interface IRefreshTokensServiceService extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
  createRefreshToken: grpc.MethodDefinition<interface_ti_users_v1_refresh_token_pb.CreateRefreshTokenRequest, interface_ti_users_v1_refresh_token_pb.RefreshToken>;
  getRefreshToken: grpc.MethodDefinition<interface_ti_users_v1_refresh_token_pb.GetRefreshTokenRequest, interface_ti_users_v1_refresh_token_pb.RefreshToken>;
  updateRefreshToken: grpc.MethodDefinition<interface_ti_users_v1_refresh_token_pb.UpdateRefreshTokenRequest, interface_ti_users_v1_refresh_token_pb.RefreshToken>;
  listRefreshTokens: grpc.MethodDefinition<interface_ti_users_v1_refresh_token_pb.ListRefreshTokensRequest, interface_ti_users_v1_refresh_token_pb.ListRefreshTokensResponse>;
  deleteRefreshToken: grpc.MethodDefinition<interface_ti_users_v1_refresh_token_pb.DeleteRefreshTokenRequest, interface_ti_users_v1_refresh_token_pb.RefreshToken>;
  batchGetRefreshTokens: grpc.MethodDefinition<interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensRequest, interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensResponse>;
  batchDeleteRefreshTokens: grpc.MethodDefinition<interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensRequest, interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensResponse>;
  streamRefreshTokens: grpc.MethodDefinition<interface_ti_users_v1_refresh_token_pb.StreamRefreshTokensRequest, interface_ti_users_v1_refresh_token_pb.RefreshToken>;
}

export const RefreshTokensServiceService: IRefreshTokensServiceService;

export interface IRefreshTokensServiceServer extends grpc.UntypedServiceImplementation {
  createRefreshToken: grpc.handleUnaryCall<interface_ti_users_v1_refresh_token_pb.CreateRefreshTokenRequest, interface_ti_users_v1_refresh_token_pb.RefreshToken>;
  getRefreshToken: grpc.handleUnaryCall<interface_ti_users_v1_refresh_token_pb.GetRefreshTokenRequest, interface_ti_users_v1_refresh_token_pb.RefreshToken>;
  updateRefreshToken: grpc.handleUnaryCall<interface_ti_users_v1_refresh_token_pb.UpdateRefreshTokenRequest, interface_ti_users_v1_refresh_token_pb.RefreshToken>;
  listRefreshTokens: grpc.handleUnaryCall<interface_ti_users_v1_refresh_token_pb.ListRefreshTokensRequest, interface_ti_users_v1_refresh_token_pb.ListRefreshTokensResponse>;
  deleteRefreshToken: grpc.handleUnaryCall<interface_ti_users_v1_refresh_token_pb.DeleteRefreshTokenRequest, interface_ti_users_v1_refresh_token_pb.RefreshToken>;
  batchGetRefreshTokens: grpc.handleUnaryCall<interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensRequest, interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensResponse>;
  batchDeleteRefreshTokens: grpc.handleUnaryCall<interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensRequest, interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensResponse>;
  streamRefreshTokens: grpc.handleServerStreamingCall<interface_ti_users_v1_refresh_token_pb.StreamRefreshTokensRequest, interface_ti_users_v1_refresh_token_pb.RefreshToken>;
}

export class RefreshTokensServiceClient extends grpc.Client {
  constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
  createRefreshToken(argument: interface_ti_users_v1_refresh_token_pb.CreateRefreshTokenRequest, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.RefreshToken>): grpc.ClientUnaryCall;
  createRefreshToken(argument: interface_ti_users_v1_refresh_token_pb.CreateRefreshTokenRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.RefreshToken>): grpc.ClientUnaryCall;
  createRefreshToken(argument: interface_ti_users_v1_refresh_token_pb.CreateRefreshTokenRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.RefreshToken>): grpc.ClientUnaryCall;
  getRefreshToken(argument: interface_ti_users_v1_refresh_token_pb.GetRefreshTokenRequest, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.RefreshToken>): grpc.ClientUnaryCall;
  getRefreshToken(argument: interface_ti_users_v1_refresh_token_pb.GetRefreshTokenRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.RefreshToken>): grpc.ClientUnaryCall;
  getRefreshToken(argument: interface_ti_users_v1_refresh_token_pb.GetRefreshTokenRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.RefreshToken>): grpc.ClientUnaryCall;
  updateRefreshToken(argument: interface_ti_users_v1_refresh_token_pb.UpdateRefreshTokenRequest, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.RefreshToken>): grpc.ClientUnaryCall;
  updateRefreshToken(argument: interface_ti_users_v1_refresh_token_pb.UpdateRefreshTokenRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.RefreshToken>): grpc.ClientUnaryCall;
  updateRefreshToken(argument: interface_ti_users_v1_refresh_token_pb.UpdateRefreshTokenRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.RefreshToken>): grpc.ClientUnaryCall;
  listRefreshTokens(argument: interface_ti_users_v1_refresh_token_pb.ListRefreshTokensRequest, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.ListRefreshTokensResponse>): grpc.ClientUnaryCall;
  listRefreshTokens(argument: interface_ti_users_v1_refresh_token_pb.ListRefreshTokensRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.ListRefreshTokensResponse>): grpc.ClientUnaryCall;
  listRefreshTokens(argument: interface_ti_users_v1_refresh_token_pb.ListRefreshTokensRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.ListRefreshTokensResponse>): grpc.ClientUnaryCall;
  deleteRefreshToken(argument: interface_ti_users_v1_refresh_token_pb.DeleteRefreshTokenRequest, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.RefreshToken>): grpc.ClientUnaryCall;
  deleteRefreshToken(argument: interface_ti_users_v1_refresh_token_pb.DeleteRefreshTokenRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.RefreshToken>): grpc.ClientUnaryCall;
  deleteRefreshToken(argument: interface_ti_users_v1_refresh_token_pb.DeleteRefreshTokenRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.RefreshToken>): grpc.ClientUnaryCall;
  batchGetRefreshTokens(argument: interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensRequest, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensResponse>): grpc.ClientUnaryCall;
  batchGetRefreshTokens(argument: interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensResponse>): grpc.ClientUnaryCall;
  batchGetRefreshTokens(argument: interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensResponse>): grpc.ClientUnaryCall;
  batchDeleteRefreshTokens(argument: interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensRequest, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensResponse>): grpc.ClientUnaryCall;
  batchDeleteRefreshTokens(argument: interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensResponse>): grpc.ClientUnaryCall;
  batchDeleteRefreshTokens(argument: interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensResponse>): grpc.ClientUnaryCall;
  streamRefreshTokens(argument: interface_ti_users_v1_refresh_token_pb.StreamRefreshTokensRequest, metadataOrOptions?: grpc.Metadata | grpc.CallOptions | null): grpc.ClientReadableStream<interface_ti_users_v1_refresh_token_pb.RefreshToken>;
  streamRefreshTokens(argument: interface_ti_users_v1_refresh_token_pb.StreamRefreshTokensRequest, metadata?: grpc.Metadata | null, options?: grpc.CallOptions | null): grpc.ClientReadableStream<interface_ti_users_v1_refresh_token_pb.RefreshToken>;
}