// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('@grpc/grpc-js');
var interface_ti_users_v1_apps_pb = require('../../../../interface/ti/users/v1/apps_pb.js');
var google_protobuf_timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb.js');
var google_protobuf_field_mask_pb = require('google-protobuf/google/protobuf/field_mask_pb.js');
var google_iam_v1_policy_pb = require('@alis-build/google-common-protos/google/iam/v1/policy_pb.js');
var google_iam_v1_iam_policy_pb = require('@alis-build/google-common-protos/google/iam/v1/iam_policy_pb.js');
var alis_open_iam_v1_iam_pb = require('@open.alis.services/protobuf/alis/open/iam/v1/iam_pb.js');
var google_protobuf_empty_pb = require('google-protobuf/google/protobuf/empty_pb.js');

function serialize_alis_open_iam_v1_AddIamBindingsRequest(arg) {
  if (!(arg instanceof alis_open_iam_v1_iam_pb.AddIamBindingsRequest)) {
    throw new Error('Expected argument of type alis.open.iam.v1.AddIamBindingsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_alis_open_iam_v1_AddIamBindingsRequest(buffer_arg) {
  return alis_open_iam_v1_iam_pb.AddIamBindingsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_alis_open_iam_v1_BatchTestIamPermissionsRequest(arg) {
  if (!(arg instanceof alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest)) {
    throw new Error('Expected argument of type alis.open.iam.v1.BatchTestIamPermissionsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_alis_open_iam_v1_BatchTestIamPermissionsRequest(buffer_arg) {
  return alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_alis_open_iam_v1_BatchTestIamPermissionsResponse(arg) {
  if (!(arg instanceof alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse)) {
    throw new Error('Expected argument of type alis.open.iam.v1.BatchTestIamPermissionsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_alis_open_iam_v1_BatchTestIamPermissionsResponse(buffer_arg) {
  return alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_alis_open_iam_v1_RemoveIamBindingsRequest(arg) {
  if (!(arg instanceof alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest)) {
    throw new Error('Expected argument of type alis.open.iam.v1.RemoveIamBindingsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_alis_open_iam_v1_RemoveIamBindingsRequest(buffer_arg) {
  return alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_GetIamPolicyRequest(arg) {
  if (!(arg instanceof google_iam_v1_iam_policy_pb.GetIamPolicyRequest)) {
    throw new Error('Expected argument of type google.iam.v1.GetIamPolicyRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_GetIamPolicyRequest(buffer_arg) {
  return google_iam_v1_iam_policy_pb.GetIamPolicyRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_Policy(arg) {
  if (!(arg instanceof google_iam_v1_policy_pb.Policy)) {
    throw new Error('Expected argument of type google.iam.v1.Policy');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_Policy(buffer_arg) {
  return google_iam_v1_policy_pb.Policy.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_SetIamPolicyRequest(arg) {
  if (!(arg instanceof google_iam_v1_iam_policy_pb.SetIamPolicyRequest)) {
    throw new Error('Expected argument of type google.iam.v1.SetIamPolicyRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_SetIamPolicyRequest(buffer_arg) {
  return google_iam_v1_iam_policy_pb.SetIamPolicyRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_TestIamPermissionsRequest(arg) {
  if (!(arg instanceof google_iam_v1_iam_policy_pb.TestIamPermissionsRequest)) {
    throw new Error('Expected argument of type google.iam.v1.TestIamPermissionsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_TestIamPermissionsRequest(buffer_arg) {
  return google_iam_v1_iam_policy_pb.TestIamPermissionsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_TestIamPermissionsResponse(arg) {
  if (!(arg instanceof google_iam_v1_iam_policy_pb.TestIamPermissionsResponse)) {
    throw new Error('Expected argument of type google.iam.v1.TestIamPermissionsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_TestIamPermissionsResponse(buffer_arg) {
  return google_iam_v1_iam_policy_pb.TestIamPermissionsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_protobuf_Empty(arg) {
  if (!(arg instanceof google_protobuf_empty_pb.Empty)) {
    throw new Error('Expected argument of type google.protobuf.Empty');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_protobuf_Empty(buffer_arg) {
  return google_protobuf_empty_pb.Empty.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_App(arg) {
  if (!(arg instanceof interface_ti_users_v1_apps_pb.App)) {
    throw new Error('Expected argument of type interface.ti.users.v1.App');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_App(buffer_arg) {
  return interface_ti_users_v1_apps_pb.App.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_CreateAppRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_apps_pb.CreateAppRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.CreateAppRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_CreateAppRequest(buffer_arg) {
  return interface_ti_users_v1_apps_pb.CreateAppRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_DeleteAppRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_apps_pb.DeleteAppRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.DeleteAppRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_DeleteAppRequest(buffer_arg) {
  return interface_ti_users_v1_apps_pb.DeleteAppRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_GetAppRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_apps_pb.GetAppRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.GetAppRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_GetAppRequest(buffer_arg) {
  return interface_ti_users_v1_apps_pb.GetAppRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListAppsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_apps_pb.ListAppsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListAppsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListAppsRequest(buffer_arg) {
  return interface_ti_users_v1_apps_pb.ListAppsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListAppsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_apps_pb.ListAppsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListAppsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListAppsResponse(buffer_arg) {
  return interface_ti_users_v1_apps_pb.ListAppsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_UpdateAppRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_apps_pb.UpdateAppRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.UpdateAppRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_UpdateAppRequest(buffer_arg) {
  return interface_ti_users_v1_apps_pb.UpdateAppRequest.deserializeBinary(new Uint8Array(buffer_arg));
}


// AppsService manages OAuth2 apps (clients) for an environment.
var AppsServiceService = exports.AppsServiceService = {
  // Gets the IAM policy for a resource implemented in this service.
getIamPolicy: {
    path: '/interface.ti.users.v1.AppsService/GetIamPolicy',
    requestStream: false,
    responseStream: false,
    requestType: google_iam_v1_iam_policy_pb.GetIamPolicyRequest,
    responseType: google_iam_v1_policy_pb.Policy,
    requestSerialize: serialize_google_iam_v1_GetIamPolicyRequest,
    requestDeserialize: deserialize_google_iam_v1_GetIamPolicyRequest,
    responseSerialize: serialize_google_iam_v1_Policy,
    responseDeserialize: deserialize_google_iam_v1_Policy,
  },
  // Sets the IAM policy for a resource implemented in this service.
setIamPolicy: {
    path: '/interface.ti.users.v1.AppsService/SetIamPolicy',
    requestStream: false,
    responseStream: false,
    requestType: google_iam_v1_iam_policy_pb.SetIamPolicyRequest,
    responseType: google_iam_v1_policy_pb.Policy,
    requestSerialize: serialize_google_iam_v1_SetIamPolicyRequest,
    requestDeserialize: deserialize_google_iam_v1_SetIamPolicyRequest,
    responseSerialize: serialize_google_iam_v1_Policy,
    responseDeserialize: deserialize_google_iam_v1_Policy,
  },
  // Returns permissions that a caller has on the specified resource.
testIamPermissions: {
    path: '/interface.ti.users.v1.AppsService/TestIamPermissions',
    requestStream: false,
    responseStream: false,
    requestType: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest,
    responseType: google_iam_v1_iam_policy_pb.TestIamPermissionsResponse,
    requestSerialize: serialize_google_iam_v1_TestIamPermissionsRequest,
    requestDeserialize: deserialize_google_iam_v1_TestIamPermissionsRequest,
    responseSerialize: serialize_google_iam_v1_TestIamPermissionsResponse,
    responseDeserialize: deserialize_google_iam_v1_TestIamPermissionsResponse,
  },
  // Returns permissions that a caller has on the specified resources.
batchTestIamPermissions: {
    path: '/interface.ti.users.v1.AppsService/BatchTestIamPermissions',
    requestStream: false,
    responseStream: false,
    requestType: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest,
    responseType: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse,
    requestSerialize: serialize_alis_open_iam_v1_BatchTestIamPermissionsRequest,
    requestDeserialize: deserialize_alis_open_iam_v1_BatchTestIamPermissionsRequest,
    responseSerialize: serialize_alis_open_iam_v1_BatchTestIamPermissionsResponse,
    responseDeserialize: deserialize_alis_open_iam_v1_BatchTestIamPermissionsResponse,
  },
  // Adds principals or updates the roles existing principals have on an IAM Policy protected resource.
addIamBindings: {
    path: '/interface.ti.users.v1.AppsService/AddIamBindings',
    requestStream: false,
    responseStream: false,
    requestType: alis_open_iam_v1_iam_pb.AddIamBindingsRequest,
    responseType: google_iam_v1_policy_pb.Policy,
    requestSerialize: serialize_alis_open_iam_v1_AddIamBindingsRequest,
    requestDeserialize: deserialize_alis_open_iam_v1_AddIamBindingsRequest,
    responseSerialize: serialize_google_iam_v1_Policy,
    responseDeserialize: deserialize_google_iam_v1_Policy,
  },
  // Removes principals or some of the roles they have on an IAM Policy protected resource.
removeIamBindings: {
    path: '/interface.ti.users.v1.AppsService/RemoveIamBindings',
    requestStream: false,
    responseStream: false,
    requestType: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest,
    responseType: google_iam_v1_policy_pb.Policy,
    requestSerialize: serialize_alis_open_iam_v1_RemoveIamBindingsRequest,
    requestDeserialize: deserialize_alis_open_iam_v1_RemoveIamBindingsRequest,
    responseSerialize: serialize_google_iam_v1_Policy,
    responseDeserialize: deserialize_google_iam_v1_Policy,
  },
  // Creates a new app.
createApp: {
    path: '/interface.ti.users.v1.AppsService/CreateApp',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_apps_pb.CreateAppRequest,
    responseType: interface_ti_users_v1_apps_pb.App,
    requestSerialize: serialize_interface_ti_users_v1_CreateAppRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_CreateAppRequest,
    responseSerialize: serialize_interface_ti_users_v1_App,
    responseDeserialize: deserialize_interface_ti_users_v1_App,
  },
  // Gets an app by its resource name.
getApp: {
    path: '/interface.ti.users.v1.AppsService/GetApp',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_apps_pb.GetAppRequest,
    responseType: interface_ti_users_v1_apps_pb.App,
    requestSerialize: serialize_interface_ti_users_v1_GetAppRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_GetAppRequest,
    responseSerialize: serialize_interface_ti_users_v1_App,
    responseDeserialize: deserialize_interface_ti_users_v1_App,
  },
  // Updates an app.
updateApp: {
    path: '/interface.ti.users.v1.AppsService/UpdateApp',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_apps_pb.UpdateAppRequest,
    responseType: interface_ti_users_v1_apps_pb.App,
    requestSerialize: serialize_interface_ti_users_v1_UpdateAppRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_UpdateAppRequest,
    responseSerialize: serialize_interface_ti_users_v1_App,
    responseDeserialize: deserialize_interface_ti_users_v1_App,
  },
  // Lists all apps.
listApps: {
    path: '/interface.ti.users.v1.AppsService/ListApps',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_apps_pb.ListAppsRequest,
    responseType: interface_ti_users_v1_apps_pb.ListAppsResponse,
    requestSerialize: serialize_interface_ti_users_v1_ListAppsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_ListAppsRequest,
    responseSerialize: serialize_interface_ti_users_v1_ListAppsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_ListAppsResponse,
  },
  // Deletes an app.
deleteApp: {
    path: '/interface.ti.users.v1.AppsService/DeleteApp',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_apps_pb.DeleteAppRequest,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_interface_ti_users_v1_DeleteAppRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_DeleteAppRequest,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
};

exports.AppsServiceClient = grpc.makeGenericClientConstructor(AppsServiceService, 'AppsService');