import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb'; // proto import: "google/protobuf/timestamp.proto"
import * as google_protobuf_field_mask_pb from 'google-protobuf/google/protobuf/field_mask_pb'; // proto import: "google/protobuf/field_mask.proto"


export class AuthReq extends jspb.Message {
  getName(): string;
  setName(value: string): AuthReq;

  getUser(): string;
  setUser(value: string): AuthReq;

  getClientId(): string;
  setClientId(value: string): AuthReq;

  getScopesList(): Array<string>;
  setScopesList(value: Array<string>): AuthReq;
  clearScopesList(): AuthReq;
  addScopes(value: string, index?: number): AuthReq;

  getBindingMessage(): string;
  setBindingMessage(value: string): AuthReq;

  getStatus(): AuthReqStatus;
  setStatus(value: AuthReqStatus): AuthReq;

  getClientNotificationToken(): string;
  setClientNotificationToken(value: string): AuthReq;

  getExpiryTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setExpiryTime(value?: google_protobuf_timestamp_pb.Timestamp): AuthReq;
  hasExpiryTime(): boolean;
  clearExpiryTime(): AuthReq;

  getApprovedScopesList(): Array<string>;
  setApprovedScopesList(value: Array<string>): AuthReq;
  clearApprovedScopesList(): AuthReq;
  addApprovedScopes(value: string, index?: number): AuthReq;

  getEtag(): string;
  setEtag(value: string): AuthReq;

  getCreateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreateTime(value?: google_protobuf_timestamp_pb.Timestamp): AuthReq;
  hasCreateTime(): boolean;
  clearCreateTime(): AuthReq;

  getUpdateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setUpdateTime(value?: google_protobuf_timestamp_pb.Timestamp): AuthReq;
  hasUpdateTime(): boolean;
  clearUpdateTime(): AuthReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AuthReq.AsObject;
  static toObject(includeInstance: boolean, msg: AuthReq): AuthReq.AsObject;
  static serializeBinaryToWriter(message: AuthReq, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AuthReq;
  static deserializeBinaryFromReader(message: AuthReq, reader: jspb.BinaryReader): AuthReq;
}

export namespace AuthReq {
  export type AsObject = {
    name: string,
    user: string,
    clientId: string,
    scopesList: Array<string>,
    bindingMessage: string,
    status: AuthReqStatus,
    clientNotificationToken: string,
    expiryTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    approvedScopesList: Array<string>,
    etag: string,
    createTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    updateTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }
}

export class CreateAuthReqRequest extends jspb.Message {
  getAuthReq(): AuthReq | undefined;
  setAuthReq(value?: AuthReq): CreateAuthReqRequest;
  hasAuthReq(): boolean;
  clearAuthReq(): CreateAuthReqRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateAuthReqRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateAuthReqRequest): CreateAuthReqRequest.AsObject;
  static serializeBinaryToWriter(message: CreateAuthReqRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateAuthReqRequest;
  static deserializeBinaryFromReader(message: CreateAuthReqRequest, reader: jspb.BinaryReader): CreateAuthReqRequest;
}

export namespace CreateAuthReqRequest {
  export type AsObject = {
    authReq?: AuthReq.AsObject,
  }
}

export class GetAuthReqRequest extends jspb.Message {
  getName(): string;
  setName(value: string): GetAuthReqRequest;

  getView(): AuthReqView;
  setView(value: AuthReqView): GetAuthReqRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): GetAuthReqRequest;
  hasReadMask(): boolean;
  clearReadMask(): GetAuthReqRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetAuthReqRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetAuthReqRequest): GetAuthReqRequest.AsObject;
  static serializeBinaryToWriter(message: GetAuthReqRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetAuthReqRequest;
  static deserializeBinaryFromReader(message: GetAuthReqRequest, reader: jspb.BinaryReader): GetAuthReqRequest;
}

export namespace GetAuthReqRequest {
  export type AsObject = {
    name: string,
    view: AuthReqView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class UpdateAuthReqRequest extends jspb.Message {
  getAuthReq(): AuthReq | undefined;
  setAuthReq(value?: AuthReq): UpdateAuthReqRequest;
  hasAuthReq(): boolean;
  clearAuthReq(): UpdateAuthReqRequest;

  getUpdateMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setUpdateMask(value?: google_protobuf_field_mask_pb.FieldMask): UpdateAuthReqRequest;
  hasUpdateMask(): boolean;
  clearUpdateMask(): UpdateAuthReqRequest;

  getAllowMissing(): boolean;
  setAllowMissing(value: boolean): UpdateAuthReqRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateAuthReqRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateAuthReqRequest): UpdateAuthReqRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateAuthReqRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateAuthReqRequest;
  static deserializeBinaryFromReader(message: UpdateAuthReqRequest, reader: jspb.BinaryReader): UpdateAuthReqRequest;
}

export namespace UpdateAuthReqRequest {
  export type AsObject = {
    authReq?: AuthReq.AsObject,
    updateMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    allowMissing: boolean,
  }
}

export class ListAuthReqsRequest extends jspb.Message {
  getPageSize(): number;
  setPageSize(value: number): ListAuthReqsRequest;

  getPageToken(): string;
  setPageToken(value: string): ListAuthReqsRequest;

  getFilter(): string;
  setFilter(value: string): ListAuthReqsRequest;

  getOrderBy(): string;
  setOrderBy(value: string): ListAuthReqsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListAuthReqsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListAuthReqsRequest): ListAuthReqsRequest.AsObject;
  static serializeBinaryToWriter(message: ListAuthReqsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListAuthReqsRequest;
  static deserializeBinaryFromReader(message: ListAuthReqsRequest, reader: jspb.BinaryReader): ListAuthReqsRequest;
}

export namespace ListAuthReqsRequest {
  export type AsObject = {
    pageSize: number,
    pageToken: string,
    filter: string,
    orderBy: string,
  }
}

export class ListAuthReqsResponse extends jspb.Message {
  getAuthReqsList(): Array<AuthReq>;
  setAuthReqsList(value: Array<AuthReq>): ListAuthReqsResponse;
  clearAuthReqsList(): ListAuthReqsResponse;
  addAuthReqs(value?: AuthReq, index?: number): AuthReq;

  getNextPageToken(): string;
  setNextPageToken(value: string): ListAuthReqsResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListAuthReqsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListAuthReqsResponse): ListAuthReqsResponse.AsObject;
  static serializeBinaryToWriter(message: ListAuthReqsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListAuthReqsResponse;
  static deserializeBinaryFromReader(message: ListAuthReqsResponse, reader: jspb.BinaryReader): ListAuthReqsResponse;
}

export namespace ListAuthReqsResponse {
  export type AsObject = {
    authReqsList: Array<AuthReq.AsObject>,
    nextPageToken: string,
  }
}

export class DeleteAuthReqRequest extends jspb.Message {
  getName(): string;
  setName(value: string): DeleteAuthReqRequest;

  getEtag(): string;
  setEtag(value: string): DeleteAuthReqRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteAuthReqRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteAuthReqRequest): DeleteAuthReqRequest.AsObject;
  static serializeBinaryToWriter(message: DeleteAuthReqRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteAuthReqRequest;
  static deserializeBinaryFromReader(message: DeleteAuthReqRequest, reader: jspb.BinaryReader): DeleteAuthReqRequest;
}

export namespace DeleteAuthReqRequest {
  export type AsObject = {
    name: string,
    etag: string,
  }
}

export class BatchGetAuthReqsRequest extends jspb.Message {
  getNamesList(): Array<string>;
  setNamesList(value: Array<string>): BatchGetAuthReqsRequest;
  clearNamesList(): BatchGetAuthReqsRequest;
  addNames(value: string, index?: number): BatchGetAuthReqsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchGetAuthReqsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchGetAuthReqsRequest): BatchGetAuthReqsRequest.AsObject;
  static serializeBinaryToWriter(message: BatchGetAuthReqsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchGetAuthReqsRequest;
  static deserializeBinaryFromReader(message: BatchGetAuthReqsRequest, reader: jspb.BinaryReader): BatchGetAuthReqsRequest;
}

export namespace BatchGetAuthReqsRequest {
  export type AsObject = {
    namesList: Array<string>,
  }
}

export class BatchGetAuthReqsResponse extends jspb.Message {
  getAuthReqsList(): Array<AuthReq>;
  setAuthReqsList(value: Array<AuthReq>): BatchGetAuthReqsResponse;
  clearAuthReqsList(): BatchGetAuthReqsResponse;
  addAuthReqs(value?: AuthReq, index?: number): AuthReq;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchGetAuthReqsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchGetAuthReqsResponse): BatchGetAuthReqsResponse.AsObject;
  static serializeBinaryToWriter(message: BatchGetAuthReqsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchGetAuthReqsResponse;
  static deserializeBinaryFromReader(message: BatchGetAuthReqsResponse, reader: jspb.BinaryReader): BatchGetAuthReqsResponse;
}

export namespace BatchGetAuthReqsResponse {
  export type AsObject = {
    authReqsList: Array<AuthReq.AsObject>,
  }
}

export class BatchDeleteAuthReqsRequest extends jspb.Message {
  getNamesList(): Array<string>;
  setNamesList(value: Array<string>): BatchDeleteAuthReqsRequest;
  clearNamesList(): BatchDeleteAuthReqsRequest;
  addNames(value: string, index?: number): BatchDeleteAuthReqsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchDeleteAuthReqsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchDeleteAuthReqsRequest): BatchDeleteAuthReqsRequest.AsObject;
  static serializeBinaryToWriter(message: BatchDeleteAuthReqsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchDeleteAuthReqsRequest;
  static deserializeBinaryFromReader(message: BatchDeleteAuthReqsRequest, reader: jspb.BinaryReader): BatchDeleteAuthReqsRequest;
}

export namespace BatchDeleteAuthReqsRequest {
  export type AsObject = {
    namesList: Array<string>,
  }
}

export class BatchDeleteAuthReqsResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchDeleteAuthReqsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchDeleteAuthReqsResponse): BatchDeleteAuthReqsResponse.AsObject;
  static serializeBinaryToWriter(message: BatchDeleteAuthReqsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchDeleteAuthReqsResponse;
  static deserializeBinaryFromReader(message: BatchDeleteAuthReqsResponse, reader: jspb.BinaryReader): BatchDeleteAuthReqsResponse;
}

export namespace BatchDeleteAuthReqsResponse {
  export type AsObject = {
  }
}

export class StreamAuthReqsRequest extends jspb.Message {
  getFilter(): string;
  setFilter(value: string): StreamAuthReqsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StreamAuthReqsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: StreamAuthReqsRequest): StreamAuthReqsRequest.AsObject;
  static serializeBinaryToWriter(message: StreamAuthReqsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StreamAuthReqsRequest;
  static deserializeBinaryFromReader(message: StreamAuthReqsRequest, reader: jspb.BinaryReader): StreamAuthReqsRequest;
}

export namespace StreamAuthReqsRequest {
  export type AsObject = {
    filter: string,
  }
}

export enum AuthReqStatus { 
  AUTH_REQ_STATUS_UNSPECIFIED = 0,
  AUTH_REQ_STATUS_PENDING = 1,
  AUTH_REQ_STATUS_APPROVED = 2,
  AUTH_REQ_STATUS_DENIED = 3,
}
export enum AuthReqView { 
  AUTH_REQ_VIEW_UNSPECIFIED = 0,
  AUTH_REQ_VIEW_BASIC = 1,
  AUTH_REQ_VIEW_FULL = 2,
}