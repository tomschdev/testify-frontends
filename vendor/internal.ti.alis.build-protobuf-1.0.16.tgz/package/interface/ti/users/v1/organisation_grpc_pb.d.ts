// GENERATED CODE -- DO NOT EDIT!

// package: interface.ti.users.v1
// file: interface/ti/users/v1/organisation.proto

import * as interface_ti_users_v1_organisation_pb from "../../../../interface/ti/users/v1/organisation_pb";
import * as alis_open_iam_v1_iam_pb from "@open.alis.services/protobuf/alis/open/iam/v1/iam_pb";
import * as google_iam_v1_iam_policy_pb from "@alis-build/google-common-protos/google/iam/v1/iam_policy_pb";
import * as google_iam_v1_policy_pb from "@alis-build/google-common-protos/google/iam/v1/policy_pb";
import * as grpc from "@grpc/grpc-js";

interface IOrganisationsServiceService extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
  getIamPolicy: grpc.MethodDefinition<google_iam_v1_iam_policy_pb.GetIamPolicyRequest, google_iam_v1_policy_pb.Policy>;
  setIamPolicy: grpc.MethodDefinition<google_iam_v1_iam_policy_pb.SetIamPolicyRequest, google_iam_v1_policy_pb.Policy>;
  testIamPermissions: grpc.MethodDefinition<google_iam_v1_iam_policy_pb.TestIamPermissionsRequest, google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>;
  batchTestIamPermissions: grpc.MethodDefinition<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest, alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>;
  addIamBindings: grpc.MethodDefinition<alis_open_iam_v1_iam_pb.AddIamBindingsRequest, google_iam_v1_policy_pb.Policy>;
  removeIamBindings: grpc.MethodDefinition<alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest, google_iam_v1_policy_pb.Policy>;
  createOrganisation: grpc.MethodDefinition<interface_ti_users_v1_organisation_pb.CreateOrganisationRequest, interface_ti_users_v1_organisation_pb.Organisation>;
  getOrganisation: grpc.MethodDefinition<interface_ti_users_v1_organisation_pb.GetOrganisationRequest, interface_ti_users_v1_organisation_pb.Organisation>;
  updateOrganisation: grpc.MethodDefinition<interface_ti_users_v1_organisation_pb.UpdateOrganisationRequest, interface_ti_users_v1_organisation_pb.Organisation>;
  listOrganisations: grpc.MethodDefinition<interface_ti_users_v1_organisation_pb.ListOrganisationsRequest, interface_ti_users_v1_organisation_pb.ListOrganisationsResponse>;
  listMyOrganisations: grpc.MethodDefinition<interface_ti_users_v1_organisation_pb.ListMyOrganisationsRequest, interface_ti_users_v1_organisation_pb.ListMyOrganisationsResponse>;
  deleteOrganisation: grpc.MethodDefinition<interface_ti_users_v1_organisation_pb.DeleteOrganisationRequest, interface_ti_users_v1_organisation_pb.Organisation>;
  undeleteOrganisation: grpc.MethodDefinition<interface_ti_users_v1_organisation_pb.UndeleteOrganisationRequest, interface_ti_users_v1_organisation_pb.Organisation>;
}

export const OrganisationsServiceService: IOrganisationsServiceService;

export interface IOrganisationsServiceServer extends grpc.UntypedServiceImplementation {
  getIamPolicy: grpc.handleUnaryCall<google_iam_v1_iam_policy_pb.GetIamPolicyRequest, google_iam_v1_policy_pb.Policy>;
  setIamPolicy: grpc.handleUnaryCall<google_iam_v1_iam_policy_pb.SetIamPolicyRequest, google_iam_v1_policy_pb.Policy>;
  testIamPermissions: grpc.handleUnaryCall<google_iam_v1_iam_policy_pb.TestIamPermissionsRequest, google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>;
  batchTestIamPermissions: grpc.handleUnaryCall<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest, alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>;
  addIamBindings: grpc.handleUnaryCall<alis_open_iam_v1_iam_pb.AddIamBindingsRequest, google_iam_v1_policy_pb.Policy>;
  removeIamBindings: grpc.handleUnaryCall<alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest, google_iam_v1_policy_pb.Policy>;
  createOrganisation: grpc.handleUnaryCall<interface_ti_users_v1_organisation_pb.CreateOrganisationRequest, interface_ti_users_v1_organisation_pb.Organisation>;
  getOrganisation: grpc.handleUnaryCall<interface_ti_users_v1_organisation_pb.GetOrganisationRequest, interface_ti_users_v1_organisation_pb.Organisation>;
  updateOrganisation: grpc.handleUnaryCall<interface_ti_users_v1_organisation_pb.UpdateOrganisationRequest, interface_ti_users_v1_organisation_pb.Organisation>;
  listOrganisations: grpc.handleUnaryCall<interface_ti_users_v1_organisation_pb.ListOrganisationsRequest, interface_ti_users_v1_organisation_pb.ListOrganisationsResponse>;
  listMyOrganisations: grpc.handleUnaryCall<interface_ti_users_v1_organisation_pb.ListMyOrganisationsRequest, interface_ti_users_v1_organisation_pb.ListMyOrganisationsResponse>;
  deleteOrganisation: grpc.handleUnaryCall<interface_ti_users_v1_organisation_pb.DeleteOrganisationRequest, interface_ti_users_v1_organisation_pb.Organisation>;
  undeleteOrganisation: grpc.handleUnaryCall<interface_ti_users_v1_organisation_pb.UndeleteOrganisationRequest, interface_ti_users_v1_organisation_pb.Organisation>;
}

export class OrganisationsServiceClient extends grpc.Client {
  constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
  getIamPolicy(argument: google_iam_v1_iam_policy_pb.GetIamPolicyRequest, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  getIamPolicy(argument: google_iam_v1_iam_policy_pb.GetIamPolicyRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  getIamPolicy(argument: google_iam_v1_iam_policy_pb.GetIamPolicyRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  setIamPolicy(argument: google_iam_v1_iam_policy_pb.SetIamPolicyRequest, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  setIamPolicy(argument: google_iam_v1_iam_policy_pb.SetIamPolicyRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  setIamPolicy(argument: google_iam_v1_iam_policy_pb.SetIamPolicyRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  testIamPermissions(argument: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest, callback: grpc.requestCallback<google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>): grpc.ClientUnaryCall;
  testIamPermissions(argument: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>): grpc.ClientUnaryCall;
  testIamPermissions(argument: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>): grpc.ClientUnaryCall;
  batchTestIamPermissions(argument: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest, callback: grpc.requestCallback<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>): grpc.ClientUnaryCall;
  batchTestIamPermissions(argument: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>): grpc.ClientUnaryCall;
  batchTestIamPermissions(argument: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>): grpc.ClientUnaryCall;
  addIamBindings(argument: alis_open_iam_v1_iam_pb.AddIamBindingsRequest, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  addIamBindings(argument: alis_open_iam_v1_iam_pb.AddIamBindingsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  addIamBindings(argument: alis_open_iam_v1_iam_pb.AddIamBindingsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  removeIamBindings(argument: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  removeIamBindings(argument: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  removeIamBindings(argument: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<google_iam_v1_policy_pb.Policy>): grpc.ClientUnaryCall;
  createOrganisation(argument: interface_ti_users_v1_organisation_pb.CreateOrganisationRequest, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  createOrganisation(argument: interface_ti_users_v1_organisation_pb.CreateOrganisationRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  createOrganisation(argument: interface_ti_users_v1_organisation_pb.CreateOrganisationRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  getOrganisation(argument: interface_ti_users_v1_organisation_pb.GetOrganisationRequest, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  getOrganisation(argument: interface_ti_users_v1_organisation_pb.GetOrganisationRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  getOrganisation(argument: interface_ti_users_v1_organisation_pb.GetOrganisationRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  updateOrganisation(argument: interface_ti_users_v1_organisation_pb.UpdateOrganisationRequest, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  updateOrganisation(argument: interface_ti_users_v1_organisation_pb.UpdateOrganisationRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  updateOrganisation(argument: interface_ti_users_v1_organisation_pb.UpdateOrganisationRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  listOrganisations(argument: interface_ti_users_v1_organisation_pb.ListOrganisationsRequest, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.ListOrganisationsResponse>): grpc.ClientUnaryCall;
  listOrganisations(argument: interface_ti_users_v1_organisation_pb.ListOrganisationsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.ListOrganisationsResponse>): grpc.ClientUnaryCall;
  listOrganisations(argument: interface_ti_users_v1_organisation_pb.ListOrganisationsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.ListOrganisationsResponse>): grpc.ClientUnaryCall;
  listMyOrganisations(argument: interface_ti_users_v1_organisation_pb.ListMyOrganisationsRequest, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.ListMyOrganisationsResponse>): grpc.ClientUnaryCall;
  listMyOrganisations(argument: interface_ti_users_v1_organisation_pb.ListMyOrganisationsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.ListMyOrganisationsResponse>): grpc.ClientUnaryCall;
  listMyOrganisations(argument: interface_ti_users_v1_organisation_pb.ListMyOrganisationsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.ListMyOrganisationsResponse>): grpc.ClientUnaryCall;
  deleteOrganisation(argument: interface_ti_users_v1_organisation_pb.DeleteOrganisationRequest, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  deleteOrganisation(argument: interface_ti_users_v1_organisation_pb.DeleteOrganisationRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  deleteOrganisation(argument: interface_ti_users_v1_organisation_pb.DeleteOrganisationRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  undeleteOrganisation(argument: interface_ti_users_v1_organisation_pb.UndeleteOrganisationRequest, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  undeleteOrganisation(argument: interface_ti_users_v1_organisation_pb.UndeleteOrganisationRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
  undeleteOrganisation(argument: interface_ti_users_v1_organisation_pb.UndeleteOrganisationRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_organisation_pb.Organisation>): grpc.ClientUnaryCall;
}