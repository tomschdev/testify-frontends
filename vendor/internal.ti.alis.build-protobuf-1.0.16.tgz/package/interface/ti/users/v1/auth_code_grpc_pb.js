// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('@grpc/grpc-js');
var interface_ti_users_v1_auth_code_pb = require('../../../../interface/ti/users/v1/auth_code_pb.js');
var google_protobuf_timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb.js');
var google_protobuf_field_mask_pb = require('google-protobuf/google/protobuf/field_mask_pb.js');

function serialize_interface_ti_users_v1_AuthCode(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_code_pb.AuthCode)) {
    throw new Error('Expected argument of type interface.ti.users.v1.AuthCode');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_AuthCode(buffer_arg) {
  return interface_ti_users_v1_auth_code_pb.AuthCode.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchDeleteAuthCodesRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchDeleteAuthCodesRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchDeleteAuthCodesRequest(buffer_arg) {
  return interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchDeleteAuthCodesResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchDeleteAuthCodesResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchDeleteAuthCodesResponse(buffer_arg) {
  return interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchGetAuthCodesRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchGetAuthCodesRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchGetAuthCodesRequest(buffer_arg) {
  return interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchGetAuthCodesResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchGetAuthCodesResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchGetAuthCodesResponse(buffer_arg) {
  return interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_CreateAuthCodeRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_code_pb.CreateAuthCodeRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.CreateAuthCodeRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_CreateAuthCodeRequest(buffer_arg) {
  return interface_ti_users_v1_auth_code_pb.CreateAuthCodeRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_DeleteAuthCodeRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_code_pb.DeleteAuthCodeRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.DeleteAuthCodeRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_DeleteAuthCodeRequest(buffer_arg) {
  return interface_ti_users_v1_auth_code_pb.DeleteAuthCodeRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_GetAuthCodeRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_code_pb.GetAuthCodeRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.GetAuthCodeRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_GetAuthCodeRequest(buffer_arg) {
  return interface_ti_users_v1_auth_code_pb.GetAuthCodeRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListAuthCodesRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_code_pb.ListAuthCodesRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListAuthCodesRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListAuthCodesRequest(buffer_arg) {
  return interface_ti_users_v1_auth_code_pb.ListAuthCodesRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListAuthCodesResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_code_pb.ListAuthCodesResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListAuthCodesResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListAuthCodesResponse(buffer_arg) {
  return interface_ti_users_v1_auth_code_pb.ListAuthCodesResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_StreamAuthCodesRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_code_pb.StreamAuthCodesRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.StreamAuthCodesRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_StreamAuthCodesRequest(buffer_arg) {
  return interface_ti_users_v1_auth_code_pb.StreamAuthCodesRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_UpdateAuthCodeRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_auth_code_pb.UpdateAuthCodeRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.UpdateAuthCodeRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_UpdateAuthCodeRequest(buffer_arg) {
  return interface_ti_users_v1_auth_code_pb.UpdateAuthCodeRequest.deserializeBinary(new Uint8Array(buffer_arg));
}


// AuthCodesService
var AuthCodesServiceService = exports.AuthCodesServiceService = {
  // Creates a new auth_code.
createAuthCode: {
    path: '/interface.ti.users.v1.AuthCodesService/CreateAuthCode',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_code_pb.CreateAuthCodeRequest,
    responseType: interface_ti_users_v1_auth_code_pb.AuthCode,
    requestSerialize: serialize_interface_ti_users_v1_CreateAuthCodeRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_CreateAuthCodeRequest,
    responseSerialize: serialize_interface_ti_users_v1_AuthCode,
    responseDeserialize: deserialize_interface_ti_users_v1_AuthCode,
  },
  // Gets an auth_code by its resource name.
getAuthCode: {
    path: '/interface.ti.users.v1.AuthCodesService/GetAuthCode',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_code_pb.GetAuthCodeRequest,
    responseType: interface_ti_users_v1_auth_code_pb.AuthCode,
    requestSerialize: serialize_interface_ti_users_v1_GetAuthCodeRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_GetAuthCodeRequest,
    responseSerialize: serialize_interface_ti_users_v1_AuthCode,
    responseDeserialize: deserialize_interface_ti_users_v1_AuthCode,
  },
  // Updates an auth_code.
updateAuthCode: {
    path: '/interface.ti.users.v1.AuthCodesService/UpdateAuthCode',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_code_pb.UpdateAuthCodeRequest,
    responseType: interface_ti_users_v1_auth_code_pb.AuthCode,
    requestSerialize: serialize_interface_ti_users_v1_UpdateAuthCodeRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_UpdateAuthCodeRequest,
    responseSerialize: serialize_interface_ti_users_v1_AuthCode,
    responseDeserialize: deserialize_interface_ti_users_v1_AuthCode,
  },
  // Lists all authCodes.
listAuthCodes: {
    path: '/interface.ti.users.v1.AuthCodesService/ListAuthCodes',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_code_pb.ListAuthCodesRequest,
    responseType: interface_ti_users_v1_auth_code_pb.ListAuthCodesResponse,
    requestSerialize: serialize_interface_ti_users_v1_ListAuthCodesRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_ListAuthCodesRequest,
    responseSerialize: serialize_interface_ti_users_v1_ListAuthCodesResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_ListAuthCodesResponse,
  },
  // Deletes an auth_code.
deleteAuthCode: {
    path: '/interface.ti.users.v1.AuthCodesService/DeleteAuthCode',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_code_pb.DeleteAuthCodeRequest,
    responseType: interface_ti_users_v1_auth_code_pb.AuthCode,
    requestSerialize: serialize_interface_ti_users_v1_DeleteAuthCodeRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_DeleteAuthCodeRequest,
    responseSerialize: serialize_interface_ti_users_v1_AuthCode,
    responseDeserialize: deserialize_interface_ti_users_v1_AuthCode,
  },
  // Get a batch of authCodes by their resource names.
batchGetAuthCodes: {
    path: '/interface.ti.users.v1.AuthCodesService/BatchGetAuthCodes',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesRequest,
    responseType: interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchGetAuthCodesRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchGetAuthCodesRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchGetAuthCodesResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchGetAuthCodesResponse,
  },
  // Batch deletes authCodes.
batchDeleteAuthCodes: {
    path: '/interface.ti.users.v1.AuthCodesService/BatchDeleteAuthCodes',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesRequest,
    responseType: interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchDeleteAuthCodesRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchDeleteAuthCodesRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchDeleteAuthCodesResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchDeleteAuthCodesResponse,
  },
  // Stream authCodes.
streamAuthCodes: {
    path: '/interface.ti.users.v1.AuthCodesService/StreamAuthCodes',
    requestStream: false,
    responseStream: true,
    requestType: interface_ti_users_v1_auth_code_pb.StreamAuthCodesRequest,
    responseType: interface_ti_users_v1_auth_code_pb.AuthCode,
    requestSerialize: serialize_interface_ti_users_v1_StreamAuthCodesRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_StreamAuthCodesRequest,
    responseSerialize: serialize_interface_ti_users_v1_AuthCode,
    responseDeserialize: deserialize_interface_ti_users_v1_AuthCode,
  },
};

exports.AuthCodesServiceClient = grpc.makeGenericClientConstructor(AuthCodesServiceService, 'AuthCodesService');