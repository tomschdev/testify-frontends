// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('@grpc/grpc-js');
var interface_ti_users_v1_user_pb = require('../../../../interface/ti/users/v1/user_pb.js');
var alis_open_iam_v1_iam_pb = require('@open.alis.services/protobuf/alis/open/iam/v1/iam_pb.js');
var google_iam_v1_iam_policy_pb = require('@alis-build/google-common-protos/google/iam/v1/iam_policy_pb.js');
var google_iam_v1_policy_pb = require('@alis-build/google-common-protos/google/iam/v1/policy_pb.js');
var google_longrunning_operations_pb = require('@alis-build/google-common-protos/google/longrunning/operations_pb.js');
var google_protobuf_any_pb = require('google-protobuf/google/protobuf/any_pb.js');
var google_protobuf_empty_pb = require('google-protobuf/google/protobuf/empty_pb.js');
var google_protobuf_field_mask_pb = require('google-protobuf/google/protobuf/field_mask_pb.js');
var google_protobuf_timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb.js');

function serialize_alis_open_iam_v1_AddIamBindingsRequest(arg) {
  if (!(arg instanceof alis_open_iam_v1_iam_pb.AddIamBindingsRequest)) {
    throw new Error('Expected argument of type alis.open.iam.v1.AddIamBindingsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_alis_open_iam_v1_AddIamBindingsRequest(buffer_arg) {
  return alis_open_iam_v1_iam_pb.AddIamBindingsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_alis_open_iam_v1_BatchTestIamPermissionsRequest(arg) {
  if (!(arg instanceof alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest)) {
    throw new Error('Expected argument of type alis.open.iam.v1.BatchTestIamPermissionsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_alis_open_iam_v1_BatchTestIamPermissionsRequest(buffer_arg) {
  return alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_alis_open_iam_v1_BatchTestIamPermissionsResponse(arg) {
  if (!(arg instanceof alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse)) {
    throw new Error('Expected argument of type alis.open.iam.v1.BatchTestIamPermissionsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_alis_open_iam_v1_BatchTestIamPermissionsResponse(buffer_arg) {
  return alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_alis_open_iam_v1_RemoveIamBindingsRequest(arg) {
  if (!(arg instanceof alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest)) {
    throw new Error('Expected argument of type alis.open.iam.v1.RemoveIamBindingsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_alis_open_iam_v1_RemoveIamBindingsRequest(buffer_arg) {
  return alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_GetIamPolicyRequest(arg) {
  if (!(arg instanceof google_iam_v1_iam_policy_pb.GetIamPolicyRequest)) {
    throw new Error('Expected argument of type google.iam.v1.GetIamPolicyRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_GetIamPolicyRequest(buffer_arg) {
  return google_iam_v1_iam_policy_pb.GetIamPolicyRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_Policy(arg) {
  if (!(arg instanceof google_iam_v1_policy_pb.Policy)) {
    throw new Error('Expected argument of type google.iam.v1.Policy');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_Policy(buffer_arg) {
  return google_iam_v1_policy_pb.Policy.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_SetIamPolicyRequest(arg) {
  if (!(arg instanceof google_iam_v1_iam_policy_pb.SetIamPolicyRequest)) {
    throw new Error('Expected argument of type google.iam.v1.SetIamPolicyRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_SetIamPolicyRequest(buffer_arg) {
  return google_iam_v1_iam_policy_pb.SetIamPolicyRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_TestIamPermissionsRequest(arg) {
  if (!(arg instanceof google_iam_v1_iam_policy_pb.TestIamPermissionsRequest)) {
    throw new Error('Expected argument of type google.iam.v1.TestIamPermissionsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_TestIamPermissionsRequest(buffer_arg) {
  return google_iam_v1_iam_policy_pb.TestIamPermissionsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_iam_v1_TestIamPermissionsResponse(arg) {
  if (!(arg instanceof google_iam_v1_iam_policy_pb.TestIamPermissionsResponse)) {
    throw new Error('Expected argument of type google.iam.v1.TestIamPermissionsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_iam_v1_TestIamPermissionsResponse(buffer_arg) {
  return google_iam_v1_iam_policy_pb.TestIamPermissionsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_longrunning_Operation(arg) {
  if (!(arg instanceof google_longrunning_operations_pb.Operation)) {
    throw new Error('Expected argument of type google.longrunning.Operation');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_longrunning_Operation(buffer_arg) {
  return google_longrunning_operations_pb.Operation.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_protobuf_Empty(arg) {
  if (!(arg instanceof google_protobuf_empty_pb.Empty)) {
    throw new Error('Expected argument of type google.protobuf.Empty');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_protobuf_Empty(buffer_arg) {
  return google_protobuf_empty_pb.Empty.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_AuthorizeConnectorRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.AuthorizeConnectorRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.AuthorizeConnectorRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_AuthorizeConnectorRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.AuthorizeConnectorRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchCreateConnectorsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchCreateConnectorsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchCreateConnectorsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchCreateConnectorsRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchCreateConnectorsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchCreateConnectorsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchCreateConnectorsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchCreateConnectorsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchCreateConnectorsResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchCreateConnectorsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchDeleteConnectorsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchDeleteConnectorsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchDeleteConnectorsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchDeleteConnectorsRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchDeleteConnectorsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchDeleteConnectorsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchDeleteConnectorsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchDeleteConnectorsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchDeleteConnectorsResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchDeleteConnectorsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchDeleteUsersRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchDeleteUsersRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchDeleteUsersRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchDeleteUsersRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchDeleteUsersRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchDeleteUsersResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchDeleteUsersResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchDeleteUsersResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchDeleteUsersResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchDeleteUsersResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchGetConnectorsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchGetConnectorsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchGetConnectorsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchGetConnectorsRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchGetConnectorsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchGetConnectorsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchGetConnectorsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchGetConnectorsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchGetConnectorsResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchGetConnectorsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchGetUsersRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchGetUsersRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchGetUsersRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchGetUsersRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchGetUsersRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchGetUsersResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchGetUsersResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchGetUsersResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchGetUsersResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchGetUsersResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchRetrieveMaskedUsersRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchRetrieveMaskedUsersRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchRetrieveMaskedUsersRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchRetrieveMaskedUsersRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchRetrieveMaskedUsersRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchRetrieveMaskedUsersResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchRetrieveMaskedUsersResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchRetrieveMaskedUsersResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchRetrieveMaskedUsersResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchRetrieveMaskedUsersResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchUndeleteConnectorsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchUndeleteConnectorsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchUndeleteConnectorsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchUndeleteConnectorsRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchUndeleteConnectorsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchUndeleteConnectorsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchUndeleteConnectorsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchUndeleteConnectorsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchUndeleteConnectorsResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchUndeleteConnectorsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchUpdateConnectorsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchUpdateConnectorsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchUpdateConnectorsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchUpdateConnectorsRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchUpdateConnectorsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchUpdateConnectorsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.BatchUpdateConnectorsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchUpdateConnectorsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchUpdateConnectorsResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.BatchUpdateConnectorsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_Connector(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.Connector)) {
    throw new Error('Expected argument of type interface.ti.users.v1.Connector');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_Connector(buffer_arg) {
  return interface_ti_users_v1_user_pb.Connector.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_CreateConnectorRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.CreateConnectorRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.CreateConnectorRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_CreateConnectorRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.CreateConnectorRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_CreateUserRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.CreateUserRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.CreateUserRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_CreateUserRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.CreateUserRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_DeleteConnectorRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.DeleteConnectorRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.DeleteConnectorRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_DeleteConnectorRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.DeleteConnectorRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_DeleteUserRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.DeleteUserRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.DeleteUserRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_DeleteUserRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.DeleteUserRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_EditMyInfoRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.EditMyInfoRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.EditMyInfoRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_EditMyInfoRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.EditMyInfoRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_EditMyMetadataRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.EditMyMetadataRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.EditMyMetadataRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_EditMyMetadataRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.EditMyMetadataRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_EditUserInfoRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.EditUserInfoRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.EditUserInfoRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_EditUserInfoRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.EditUserInfoRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_EditUserMetadataRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.EditUserMetadataRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.EditUserMetadataRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_EditUserMetadataRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.EditUserMetadataRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_FetchAccessTokenRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.FetchAccessTokenRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.FetchAccessTokenRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_FetchAccessTokenRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.FetchAccessTokenRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_FetchAccessTokenResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.FetchAccessTokenResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.FetchAccessTokenResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_FetchAccessTokenResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.FetchAccessTokenResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_GetConnectorRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.GetConnectorRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.GetConnectorRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_GetConnectorRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.GetConnectorRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_GetUserRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.GetUserRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.GetUserRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_GetUserRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.GetUserRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListConnectorsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.ListConnectorsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListConnectorsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListConnectorsRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.ListConnectorsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListConnectorsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.ListConnectorsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListConnectorsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListConnectorsResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.ListConnectorsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListMyAvailableConnectorsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.ListMyAvailableConnectorsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListMyAvailableConnectorsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListMyAvailableConnectorsRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.ListMyAvailableConnectorsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListMyAvailableConnectorsResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.ListMyAvailableConnectorsResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListMyAvailableConnectorsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListMyAvailableConnectorsResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.ListMyAvailableConnectorsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListUsersRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.ListUsersRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListUsersRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListUsersRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.ListUsersRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListUsersResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.ListUsersResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListUsersResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListUsersResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.ListUsersResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_LookupUserRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.LookupUserRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.LookupUserRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_LookupUserRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.LookupUserRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_LookupUserResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.LookupUserResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.LookupUserResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_LookupUserResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.LookupUserResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_MaskedUser(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.MaskedUser)) {
    throw new Error('Expected argument of type interface.ti.users.v1.MaskedUser');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_MaskedUser(buffer_arg) {
  return interface_ti_users_v1_user_pb.MaskedUser.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_RemoveMyUserRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.RemoveMyUserRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.RemoveMyUserRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_RemoveMyUserRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.RemoveMyUserRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_RetrieveMaskedUserRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.RetrieveMaskedUserRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.RetrieveMaskedUserRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_RetrieveMaskedUserRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.RetrieveMaskedUserRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_RetrieveMaskedUsersRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.RetrieveMaskedUsersRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.RetrieveMaskedUsersRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_RetrieveMaskedUsersRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.RetrieveMaskedUsersRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_RetrieveMaskedUsersResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.RetrieveMaskedUsersResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.RetrieveMaskedUsersResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_RetrieveMaskedUsersResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.RetrieveMaskedUsersResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_RetrieveMyUserRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.RetrieveMyUserRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.RetrieveMyUserRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_RetrieveMyUserRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.RetrieveMyUserRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_RetrieveUserByEmailRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.RetrieveUserByEmailRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.RetrieveUserByEmailRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_RetrieveUserByEmailRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.RetrieveUserByEmailRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_RevokeConnectorRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.RevokeConnectorRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.RevokeConnectorRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_RevokeConnectorRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.RevokeConnectorRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_RevokeConnectorResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.RevokeConnectorResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.RevokeConnectorResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_RevokeConnectorResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.RevokeConnectorResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_SetUserPictureRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.SetUserPictureRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.SetUserPictureRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_SetUserPictureRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.SetUserPictureRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_SetUserPictureResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.SetUserPictureResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.SetUserPictureResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_SetUserPictureResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.SetUserPictureResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_StreamConnectorsRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.StreamConnectorsRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.StreamConnectorsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_StreamConnectorsRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.StreamConnectorsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_StreamUsersRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.StreamUsersRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.StreamUsersRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_StreamUsersRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.StreamUsersRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_SyncToGoogleGroupRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.SyncToGoogleGroupRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.SyncToGoogleGroupRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_SyncToGoogleGroupRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.SyncToGoogleGroupRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_SyncToGoogleGroupResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.SyncToGoogleGroupResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.SyncToGoogleGroupResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_SyncToGoogleGroupResponse(buffer_arg) {
  return interface_ti_users_v1_user_pb.SyncToGoogleGroupResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_UndeleteConnectorRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.UndeleteConnectorRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.UndeleteConnectorRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_UndeleteConnectorRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.UndeleteConnectorRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_UpdateConnectorRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.UpdateConnectorRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.UpdateConnectorRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_UpdateConnectorRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.UpdateConnectorRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_UpdateUserRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.UpdateUserRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.UpdateUserRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_UpdateUserRequest(buffer_arg) {
  return interface_ti_users_v1_user_pb.UpdateUserRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_User(arg) {
  if (!(arg instanceof interface_ti_users_v1_user_pb.User)) {
    throw new Error('Expected argument of type interface.ti.users.v1.User');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_User(buffer_arg) {
  return interface_ti_users_v1_user_pb.User.deserializeBinary(new Uint8Array(buffer_arg));
}


// UsersService
var UsersServiceService = exports.UsersServiceService = {
  // Gets the IAM policy for a resource implemented in this service.
getIamPolicy: {
    path: '/interface.ti.users.v1.UsersService/GetIamPolicy',
    requestStream: false,
    responseStream: false,
    requestType: google_iam_v1_iam_policy_pb.GetIamPolicyRequest,
    responseType: google_iam_v1_policy_pb.Policy,
    requestSerialize: serialize_google_iam_v1_GetIamPolicyRequest,
    requestDeserialize: deserialize_google_iam_v1_GetIamPolicyRequest,
    responseSerialize: serialize_google_iam_v1_Policy,
    responseDeserialize: deserialize_google_iam_v1_Policy,
  },
  // Sets the IAM policy for a resource implemented in this service.
setIamPolicy: {
    path: '/interface.ti.users.v1.UsersService/SetIamPolicy',
    requestStream: false,
    responseStream: false,
    requestType: google_iam_v1_iam_policy_pb.SetIamPolicyRequest,
    responseType: google_iam_v1_policy_pb.Policy,
    requestSerialize: serialize_google_iam_v1_SetIamPolicyRequest,
    requestDeserialize: deserialize_google_iam_v1_SetIamPolicyRequest,
    responseSerialize: serialize_google_iam_v1_Policy,
    responseDeserialize: deserialize_google_iam_v1_Policy,
  },
  // Returns permissions that a caller has on the specified resource.
testIamPermissions: {
    path: '/interface.ti.users.v1.UsersService/TestIamPermissions',
    requestStream: false,
    responseStream: false,
    requestType: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest,
    responseType: google_iam_v1_iam_policy_pb.TestIamPermissionsResponse,
    requestSerialize: serialize_google_iam_v1_TestIamPermissionsRequest,
    requestDeserialize: deserialize_google_iam_v1_TestIamPermissionsRequest,
    responseSerialize: serialize_google_iam_v1_TestIamPermissionsResponse,
    responseDeserialize: deserialize_google_iam_v1_TestIamPermissionsResponse,
  },
  // Returns permissions that a caller has on the specified resources.
batchTestIamPermissions: {
    path: '/interface.ti.users.v1.UsersService/BatchTestIamPermissions',
    requestStream: false,
    responseStream: false,
    requestType: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest,
    responseType: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse,
    requestSerialize: serialize_alis_open_iam_v1_BatchTestIamPermissionsRequest,
    requestDeserialize: deserialize_alis_open_iam_v1_BatchTestIamPermissionsRequest,
    responseSerialize: serialize_alis_open_iam_v1_BatchTestIamPermissionsResponse,
    responseDeserialize: deserialize_alis_open_iam_v1_BatchTestIamPermissionsResponse,
  },
  // Adds principals or updates the roles existing principals have on an IAM Policy protected resource.
addIamBindings: {
    path: '/interface.ti.users.v1.UsersService/AddIamBindings',
    requestStream: false,
    responseStream: false,
    requestType: alis_open_iam_v1_iam_pb.AddIamBindingsRequest,
    responseType: google_iam_v1_policy_pb.Policy,
    requestSerialize: serialize_alis_open_iam_v1_AddIamBindingsRequest,
    requestDeserialize: deserialize_alis_open_iam_v1_AddIamBindingsRequest,
    responseSerialize: serialize_google_iam_v1_Policy,
    responseDeserialize: deserialize_google_iam_v1_Policy,
  },
  // Removes principals or some of the roles they have on an IAM Policy protected resource.
removeIamBindings: {
    path: '/interface.ti.users.v1.UsersService/RemoveIamBindings',
    requestStream: false,
    responseStream: false,
    requestType: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest,
    responseType: google_iam_v1_policy_pb.Policy,
    requestSerialize: serialize_alis_open_iam_v1_RemoveIamBindingsRequest,
    requestDeserialize: deserialize_alis_open_iam_v1_RemoveIamBindingsRequest,
    responseSerialize: serialize_google_iam_v1_Policy,
    responseDeserialize: deserialize_google_iam_v1_Policy,
  },
  // Creates a new user.
createUser: {
    path: '/interface.ti.users.v1.UsersService/CreateUser',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.CreateUserRequest,
    responseType: interface_ti_users_v1_user_pb.User,
    requestSerialize: serialize_interface_ti_users_v1_CreateUserRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_CreateUserRequest,
    responseSerialize: serialize_interface_ti_users_v1_User,
    responseDeserialize: deserialize_interface_ti_users_v1_User,
  },
  // Gets an user by its resource name.
getUser: {
    path: '/interface.ti.users.v1.UsersService/GetUser',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.GetUserRequest,
    responseType: interface_ti_users_v1_user_pb.User,
    requestSerialize: serialize_interface_ti_users_v1_GetUserRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_GetUserRequest,
    responseSerialize: serialize_interface_ti_users_v1_User,
    responseDeserialize: deserialize_interface_ti_users_v1_User,
  },
  // Updates an user.
updateUser: {
    path: '/interface.ti.users.v1.UsersService/UpdateUser',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.UpdateUserRequest,
    responseType: interface_ti_users_v1_user_pb.User,
    requestSerialize: serialize_interface_ti_users_v1_UpdateUserRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_UpdateUserRequest,
    responseSerialize: serialize_interface_ti_users_v1_User,
    responseDeserialize: deserialize_interface_ti_users_v1_User,
  },
  // Lists all users.
listUsers: {
    path: '/interface.ti.users.v1.UsersService/ListUsers',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.ListUsersRequest,
    responseType: interface_ti_users_v1_user_pb.ListUsersResponse,
    requestSerialize: serialize_interface_ti_users_v1_ListUsersRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_ListUsersRequest,
    responseSerialize: serialize_interface_ti_users_v1_ListUsersResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_ListUsersResponse,
  },
  // Deletes an user.
deleteUser: {
    path: '/interface.ti.users.v1.UsersService/DeleteUser',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.DeleteUserRequest,
    responseType: interface_ti_users_v1_user_pb.User,
    requestSerialize: serialize_interface_ti_users_v1_DeleteUserRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_DeleteUserRequest,
    responseSerialize: serialize_interface_ti_users_v1_User,
    responseDeserialize: deserialize_interface_ti_users_v1_User,
  },
  // Get a batch of users by their resource names.
batchGetUsers: {
    path: '/interface.ti.users.v1.UsersService/BatchGetUsers',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.BatchGetUsersRequest,
    responseType: interface_ti_users_v1_user_pb.BatchGetUsersResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchGetUsersRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchGetUsersRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchGetUsersResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchGetUsersResponse,
  },
  // Batch deletes users.
batchDeleteUsers: {
    path: '/interface.ti.users.v1.UsersService/BatchDeleteUsers',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.BatchDeleteUsersRequest,
    responseType: interface_ti_users_v1_user_pb.BatchDeleteUsersResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchDeleteUsersRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchDeleteUsersRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchDeleteUsersResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchDeleteUsersResponse,
  },
  // Stream users.
streamUsers: {
    path: '/interface.ti.users.v1.UsersService/StreamUsers',
    requestStream: false,
    responseStream: true,
    requestType: interface_ti_users_v1_user_pb.StreamUsersRequest,
    responseType: interface_ti_users_v1_user_pb.User,
    requestSerialize: serialize_interface_ti_users_v1_StreamUsersRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_StreamUsersRequest,
    responseSerialize: serialize_interface_ti_users_v1_User,
    responseDeserialize: deserialize_interface_ti_users_v1_User,
  },
  // Look up a User based on a search text.
//
// This method retrieves a set of results, which are Users, based on the  request.
// The lookup for these Users are done across the given_name, family_name,    email and contact number.
lookupUser: {
    path: '/interface.ti.users.v1.UsersService/LookupUser',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.LookupUserRequest,
    responseType: interface_ti_users_v1_user_pb.LookupUserResponse,
    requestSerialize: serialize_interface_ti_users_v1_LookupUserRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_LookupUserRequest,
    responseSerialize: serialize_interface_ti_users_v1_LookupUserResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_LookupUserResponse,
  },
  // Retrieves the set of Users requested, with only a
// subset of the User information returned.
//
// This is equivalent to a BatchGet method, but only a subset of the User     information,
// which does not contain any sensitive information such as email or group    configurations.
//
// Differs from the RetrieveMaskedUsers method in that it returns only
// the Users that were specified in the request.
batchRetrieveMaskedUsers: {
    path: '/interface.ti.users.v1.UsersService/BatchRetrieveMaskedUsers',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.BatchRetrieveMaskedUsersRequest,
    responseType: interface_ti_users_v1_user_pb.BatchRetrieveMaskedUsersResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchRetrieveMaskedUsersRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchRetrieveMaskedUsersRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchRetrieveMaskedUsersResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchRetrieveMaskedUsersResponse,
  },
  // Retrieves all Users that match the filter criteria, if specified,
// with only a subset of the User information.
//
// This is equivalent to a List method, but only a subset of the User     information,
// which does not contain any sensitive information such as email or group    configurations.
//
// Differs from the BatchRetrieveMaskedUsers method in that it returns all
// the Users that match the filter, if the filter is specified.
//
// This is useful for displaying a list of Users without revealing sensitive  information like email.
retrieveMaskedUsers: {
    path: '/interface.ti.users.v1.UsersService/RetrieveMaskedUsers',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.RetrieveMaskedUsersRequest,
    responseType: interface_ti_users_v1_user_pb.RetrieveMaskedUsersResponse,
    requestSerialize: serialize_interface_ti_users_v1_RetrieveMaskedUsersRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_RetrieveMaskedUsersRequest,
    responseSerialize: serialize_interface_ti_users_v1_RetrieveMaskedUsersResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_RetrieveMaskedUsersResponse,
  },
  // Retrieves a User with some of their details hidden.
// This is useful for displaying a User without revealing sensitive information   like email.
// Both name and email can be used to retrieve the User.
retrieveMaskedUser: {
    path: '/interface.ti.users.v1.UsersService/RetrieveMaskedUser',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.RetrieveMaskedUserRequest,
    responseType: interface_ti_users_v1_user_pb.MaskedUser,
    requestSerialize: serialize_interface_ti_users_v1_RetrieveMaskedUserRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_RetrieveMaskedUserRequest,
    responseSerialize: serialize_interface_ti_users_v1_MaskedUser,
    responseDeserialize: deserialize_interface_ti_users_v1_MaskedUser,
  },
  // Edits a User's non-auth related information like family name and picture.
editUserInfo: {
    path: '/interface.ti.users.v1.UsersService/EditUserInfo',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.EditUserInfoRequest,
    responseType: interface_ti_users_v1_user_pb.User,
    requestSerialize: serialize_interface_ti_users_v1_EditUserInfoRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_EditUserInfoRequest,
    responseSerialize: serialize_interface_ti_users_v1_User,
    responseDeserialize: deserialize_interface_ti_users_v1_User,
  },
  // Edits a User's metadata
editUserMetadata: {
    path: '/interface.ti.users.v1.UsersService/EditUserMetadata',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.EditUserMetadataRequest,
    responseType: interface_ti_users_v1_user_pb.User,
    requestSerialize: serialize_interface_ti_users_v1_EditUserMetadataRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_EditUserMetadataRequest,
    responseSerialize: serialize_interface_ti_users_v1_User,
    responseDeserialize: deserialize_interface_ti_users_v1_User,
  },
  // Retrieves the currently signed in user.
// This is useful for client-side applications to get the signed in user's    information.
retrieveMyUser: {
    path: '/interface.ti.users.v1.UsersService/RetrieveMyUser',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.RetrieveMyUserRequest,
    responseType: interface_ti_users_v1_user_pb.User,
    requestSerialize: serialize_interface_ti_users_v1_RetrieveMyUserRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_RetrieveMyUserRequest,
    responseSerialize: serialize_interface_ti_users_v1_User,
    responseDeserialize: deserialize_interface_ti_users_v1_User,
  },
  // Edits the info of the currently signed in user.
// This is useful for client-side applications to edit the signed in user's   information.
// Allows the user to edit their given_name, family_name, picture,    contact_number, position, education, linkedin_uri and metadata.
editMyInfo: {
    path: '/interface.ti.users.v1.UsersService/EditMyInfo',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.EditMyInfoRequest,
    responseType: interface_ti_users_v1_user_pb.User,
    requestSerialize: serialize_interface_ti_users_v1_EditMyInfoRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_EditMyInfoRequest,
    responseSerialize: serialize_interface_ti_users_v1_User,
    responseDeserialize: deserialize_interface_ti_users_v1_User,
  },
  // Edits the metadata of the currently signed in user.
// This is useful for client-side applications to edit the signed in user's   metadata.
editMyMetadata: {
    path: '/interface.ti.users.v1.UsersService/EditMyMetadata',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.EditMyMetadataRequest,
    responseType: interface_ti_users_v1_user_pb.User,
    requestSerialize: serialize_interface_ti_users_v1_EditMyMetadataRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_EditMyMetadataRequest,
    responseSerialize: serialize_interface_ti_users_v1_User,
    responseDeserialize: deserialize_interface_ti_users_v1_User,
  },
  // Removes the currently signed in user.
// This is useful if a user wants to delete their account.
removeMyUser: {
    path: '/interface.ti.users.v1.UsersService/RemoveMyUser',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.RemoveMyUserRequest,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_interface_ti_users_v1_RemoveMyUserRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_RemoveMyUserRequest,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  // Syncs all google User's to the google group configured in the IamConfig.
// Will not delete service accounts.
syncToGoogleGroup: {
    path: '/interface.ti.users.v1.UsersService/SyncToGoogleGroup',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.SyncToGoogleGroupRequest,
    responseType: interface_ti_users_v1_user_pb.SyncToGoogleGroupResponse,
    requestSerialize: serialize_interface_ti_users_v1_SyncToGoogleGroupRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_SyncToGoogleGroupRequest,
    responseSerialize: serialize_interface_ti_users_v1_SyncToGoogleGroupResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_SyncToGoogleGroupResponse,
  },
  // Sets the user's profile picture
setUserPicture: {
    path: '/interface.ti.users.v1.UsersService/SetUserPicture',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.SetUserPictureRequest,
    responseType: interface_ti_users_v1_user_pb.SetUserPictureResponse,
    requestSerialize: serialize_interface_ti_users_v1_SetUserPictureRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_SetUserPictureRequest,
    responseSerialize: serialize_interface_ti_users_v1_SetUserPictureResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_SetUserPictureResponse,
  },
  // Retrieves a user from a specified email
retrieveUserByEmail: {
    path: '/interface.ti.users.v1.UsersService/RetrieveUserByEmail',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.RetrieveUserByEmailRequest,
    responseType: interface_ti_users_v1_user_pb.User,
    requestSerialize: serialize_interface_ti_users_v1_RetrieveUserByEmailRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_RetrieveUserByEmailRequest,
    responseSerialize: serialize_interface_ti_users_v1_User,
    responseDeserialize: deserialize_interface_ti_users_v1_User,
  },
  // Creates a new connector.
createConnector: {
    path: '/interface.ti.users.v1.UsersService/CreateConnector',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.CreateConnectorRequest,
    responseType: interface_ti_users_v1_user_pb.Connector,
    requestSerialize: serialize_interface_ti_users_v1_CreateConnectorRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_CreateConnectorRequest,
    responseSerialize: serialize_interface_ti_users_v1_Connector,
    responseDeserialize: deserialize_interface_ti_users_v1_Connector,
  },
  // Gets an connector by its resource name.
getConnector: {
    path: '/interface.ti.users.v1.UsersService/GetConnector',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.GetConnectorRequest,
    responseType: interface_ti_users_v1_user_pb.Connector,
    requestSerialize: serialize_interface_ti_users_v1_GetConnectorRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_GetConnectorRequest,
    responseSerialize: serialize_interface_ti_users_v1_Connector,
    responseDeserialize: deserialize_interface_ti_users_v1_Connector,
  },
  // Updates an connector.
updateConnector: {
    path: '/interface.ti.users.v1.UsersService/UpdateConnector',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.UpdateConnectorRequest,
    responseType: interface_ti_users_v1_user_pb.Connector,
    requestSerialize: serialize_interface_ti_users_v1_UpdateConnectorRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_UpdateConnectorRequest,
    responseSerialize: serialize_interface_ti_users_v1_Connector,
    responseDeserialize: deserialize_interface_ti_users_v1_Connector,
  },
  // Lists all connectors.
listConnectors: {
    path: '/interface.ti.users.v1.UsersService/ListConnectors',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.ListConnectorsRequest,
    responseType: interface_ti_users_v1_user_pb.ListConnectorsResponse,
    requestSerialize: serialize_interface_ti_users_v1_ListConnectorsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_ListConnectorsRequest,
    responseSerialize: serialize_interface_ti_users_v1_ListConnectorsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_ListConnectorsResponse,
  },
  // Deletes an connector.
deleteConnector: {
    path: '/interface.ti.users.v1.UsersService/DeleteConnector',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.DeleteConnectorRequest,
    responseType: interface_ti_users_v1_user_pb.Connector,
    requestSerialize: serialize_interface_ti_users_v1_DeleteConnectorRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_DeleteConnectorRequest,
    responseSerialize: serialize_interface_ti_users_v1_Connector,
    responseDeserialize: deserialize_interface_ti_users_v1_Connector,
  },
  // Un-deletes an connector.
undeleteConnector: {
    path: '/interface.ti.users.v1.UsersService/UndeleteConnector',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.UndeleteConnectorRequest,
    responseType: interface_ti_users_v1_user_pb.Connector,
    requestSerialize: serialize_interface_ti_users_v1_UndeleteConnectorRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_UndeleteConnectorRequest,
    responseSerialize: serialize_interface_ti_users_v1_Connector,
    responseDeserialize: deserialize_interface_ti_users_v1_Connector,
  },
  // Batch creates connectors.
batchCreateConnectors: {
    path: '/interface.ti.users.v1.UsersService/BatchCreateConnectors',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.BatchCreateConnectorsRequest,
    responseType: interface_ti_users_v1_user_pb.BatchCreateConnectorsResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchCreateConnectorsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchCreateConnectorsRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchCreateConnectorsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchCreateConnectorsResponse,
  },
  // Get a batch of connectors by their resource names.
batchGetConnectors: {
    path: '/interface.ti.users.v1.UsersService/BatchGetConnectors',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.BatchGetConnectorsRequest,
    responseType: interface_ti_users_v1_user_pb.BatchGetConnectorsResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchGetConnectorsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchGetConnectorsRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchGetConnectorsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchGetConnectorsResponse,
  },
  // Batch updates connectors.
batchUpdateConnectors: {
    path: '/interface.ti.users.v1.UsersService/BatchUpdateConnectors',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.BatchUpdateConnectorsRequest,
    responseType: interface_ti_users_v1_user_pb.BatchUpdateConnectorsResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchUpdateConnectorsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchUpdateConnectorsRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchUpdateConnectorsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchUpdateConnectorsResponse,
  },
  // Batch deletes connectors.
batchDeleteConnectors: {
    path: '/interface.ti.users.v1.UsersService/BatchDeleteConnectors',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.BatchDeleteConnectorsRequest,
    responseType: interface_ti_users_v1_user_pb.BatchDeleteConnectorsResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchDeleteConnectorsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchDeleteConnectorsRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchDeleteConnectorsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchDeleteConnectorsResponse,
  },
  // Batch undeletes connectors.
batchUndeleteConnectors: {
    path: '/interface.ti.users.v1.UsersService/BatchUndeleteConnectors',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.BatchUndeleteConnectorsRequest,
    responseType: interface_ti_users_v1_user_pb.BatchUndeleteConnectorsResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchUndeleteConnectorsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchUndeleteConnectorsRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchUndeleteConnectorsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchUndeleteConnectorsResponse,
  },
  // Stream connectors.
streamConnectors: {
    path: '/interface.ti.users.v1.UsersService/StreamConnectors',
    requestStream: false,
    responseStream: true,
    requestType: interface_ti_users_v1_user_pb.StreamConnectorsRequest,
    responseType: interface_ti_users_v1_user_pb.Connector,
    requestSerialize: serialize_interface_ti_users_v1_StreamConnectorsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_StreamConnectorsRequest,
    responseSerialize: serialize_interface_ti_users_v1_Connector,
    responseDeserialize: deserialize_interface_ti_users_v1_Connector,
  },
  // Manages the process of authorizing the specified Connector.
// Each Connector type will have custom workflows around the authorisation flow.
authorizeConnector: {
    path: '/interface.ti.users.v1.UsersService/AuthorizeConnector',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.AuthorizeConnectorRequest,
    responseType: google_longrunning_operations_pb.Operation,
    requestSerialize: serialize_interface_ti_users_v1_AuthorizeConnectorRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_AuthorizeConnectorRequest,
    responseSerialize: serialize_google_longrunning_Operation,
    responseDeserialize: deserialize_google_longrunning_Operation,
  },
  // Checks if the Connector is authorized and is valid and refreshes it if necessary.
fetchAccessToken: {
    path: '/interface.ti.users.v1.UsersService/FetchAccessToken',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.FetchAccessTokenRequest,
    responseType: interface_ti_users_v1_user_pb.FetchAccessTokenResponse,
    requestSerialize: serialize_interface_ti_users_v1_FetchAccessTokenRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_FetchAccessTokenRequest,
    responseSerialize: serialize_interface_ti_users_v1_FetchAccessTokenResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_FetchAccessTokenResponse,
  },
  // Revokes the Connector
// Users will have to go through the authorization process once revoked.
revokeConnector: {
    path: '/interface.ti.users.v1.UsersService/RevokeConnector',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.RevokeConnectorRequest,
    responseType: interface_ti_users_v1_user_pb.RevokeConnectorResponse,
    requestSerialize: serialize_interface_ti_users_v1_RevokeConnectorRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_RevokeConnectorRequest,
    responseSerialize: serialize_interface_ti_users_v1_RevokeConnectorResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_RevokeConnectorResponse,
  },
  // Custom method to lists all connectors (unauthenticated (i.e. not yet existing in the db), authenticated and expired)
listMyAvailableConnectors: {
    path: '/interface.ti.users.v1.UsersService/ListMyAvailableConnectors',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_user_pb.ListMyAvailableConnectorsRequest,
    responseType: interface_ti_users_v1_user_pb.ListMyAvailableConnectorsResponse,
    requestSerialize: serialize_interface_ti_users_v1_ListMyAvailableConnectorsRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_ListMyAvailableConnectorsRequest,
    responseSerialize: serialize_interface_ti_users_v1_ListMyAvailableConnectorsResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_ListMyAvailableConnectorsResponse,
  },
};

exports.UsersServiceClient = grpc.makeGenericClientConstructor(UsersServiceService, 'UsersService');