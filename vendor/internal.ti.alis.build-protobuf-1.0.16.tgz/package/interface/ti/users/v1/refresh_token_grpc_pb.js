// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('@grpc/grpc-js');
var interface_ti_users_v1_refresh_token_pb = require('../../../../interface/ti/users/v1/refresh_token_pb.js');
var google_protobuf_timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb.js');
var google_protobuf_field_mask_pb = require('google-protobuf/google/protobuf/field_mask_pb.js');

function serialize_interface_ti_users_v1_BatchDeleteRefreshTokensRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchDeleteRefreshTokensRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchDeleteRefreshTokensRequest(buffer_arg) {
  return interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchDeleteRefreshTokensResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchDeleteRefreshTokensResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchDeleteRefreshTokensResponse(buffer_arg) {
  return interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchGetRefreshTokensRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchGetRefreshTokensRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchGetRefreshTokensRequest(buffer_arg) {
  return interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_BatchGetRefreshTokensResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.BatchGetRefreshTokensResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_BatchGetRefreshTokensResponse(buffer_arg) {
  return interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_CreateRefreshTokenRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_refresh_token_pb.CreateRefreshTokenRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.CreateRefreshTokenRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_CreateRefreshTokenRequest(buffer_arg) {
  return interface_ti_users_v1_refresh_token_pb.CreateRefreshTokenRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_DeleteRefreshTokenRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_refresh_token_pb.DeleteRefreshTokenRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.DeleteRefreshTokenRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_DeleteRefreshTokenRequest(buffer_arg) {
  return interface_ti_users_v1_refresh_token_pb.DeleteRefreshTokenRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_GetRefreshTokenRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_refresh_token_pb.GetRefreshTokenRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.GetRefreshTokenRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_GetRefreshTokenRequest(buffer_arg) {
  return interface_ti_users_v1_refresh_token_pb.GetRefreshTokenRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListRefreshTokensRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_refresh_token_pb.ListRefreshTokensRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListRefreshTokensRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListRefreshTokensRequest(buffer_arg) {
  return interface_ti_users_v1_refresh_token_pb.ListRefreshTokensRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_ListRefreshTokensResponse(arg) {
  if (!(arg instanceof interface_ti_users_v1_refresh_token_pb.ListRefreshTokensResponse)) {
    throw new Error('Expected argument of type interface.ti.users.v1.ListRefreshTokensResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_ListRefreshTokensResponse(buffer_arg) {
  return interface_ti_users_v1_refresh_token_pb.ListRefreshTokensResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_RefreshToken(arg) {
  if (!(arg instanceof interface_ti_users_v1_refresh_token_pb.RefreshToken)) {
    throw new Error('Expected argument of type interface.ti.users.v1.RefreshToken');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_RefreshToken(buffer_arg) {
  return interface_ti_users_v1_refresh_token_pb.RefreshToken.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_StreamRefreshTokensRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_refresh_token_pb.StreamRefreshTokensRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.StreamRefreshTokensRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_StreamRefreshTokensRequest(buffer_arg) {
  return interface_ti_users_v1_refresh_token_pb.StreamRefreshTokensRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_users_v1_UpdateRefreshTokenRequest(arg) {
  if (!(arg instanceof interface_ti_users_v1_refresh_token_pb.UpdateRefreshTokenRequest)) {
    throw new Error('Expected argument of type interface.ti.users.v1.UpdateRefreshTokenRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_users_v1_UpdateRefreshTokenRequest(buffer_arg) {
  return interface_ti_users_v1_refresh_token_pb.UpdateRefreshTokenRequest.deserializeBinary(new Uint8Array(buffer_arg));
}


// RefreshTokensService
var RefreshTokensServiceService = exports.RefreshTokensServiceService = {
  // Creates a new refresh_token.
createRefreshToken: {
    path: '/interface.ti.users.v1.RefreshTokensService/CreateRefreshToken',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_refresh_token_pb.CreateRefreshTokenRequest,
    responseType: interface_ti_users_v1_refresh_token_pb.RefreshToken,
    requestSerialize: serialize_interface_ti_users_v1_CreateRefreshTokenRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_CreateRefreshTokenRequest,
    responseSerialize: serialize_interface_ti_users_v1_RefreshToken,
    responseDeserialize: deserialize_interface_ti_users_v1_RefreshToken,
  },
  // Gets an refresh_token by its resource name.
getRefreshToken: {
    path: '/interface.ti.users.v1.RefreshTokensService/GetRefreshToken',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_refresh_token_pb.GetRefreshTokenRequest,
    responseType: interface_ti_users_v1_refresh_token_pb.RefreshToken,
    requestSerialize: serialize_interface_ti_users_v1_GetRefreshTokenRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_GetRefreshTokenRequest,
    responseSerialize: serialize_interface_ti_users_v1_RefreshToken,
    responseDeserialize: deserialize_interface_ti_users_v1_RefreshToken,
  },
  // Updates an refresh_token.
updateRefreshToken: {
    path: '/interface.ti.users.v1.RefreshTokensService/UpdateRefreshToken',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_refresh_token_pb.UpdateRefreshTokenRequest,
    responseType: interface_ti_users_v1_refresh_token_pb.RefreshToken,
    requestSerialize: serialize_interface_ti_users_v1_UpdateRefreshTokenRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_UpdateRefreshTokenRequest,
    responseSerialize: serialize_interface_ti_users_v1_RefreshToken,
    responseDeserialize: deserialize_interface_ti_users_v1_RefreshToken,
  },
  // Lists all refreshToken.
listRefreshTokens: {
    path: '/interface.ti.users.v1.RefreshTokensService/ListRefreshTokens',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_refresh_token_pb.ListRefreshTokensRequest,
    responseType: interface_ti_users_v1_refresh_token_pb.ListRefreshTokensResponse,
    requestSerialize: serialize_interface_ti_users_v1_ListRefreshTokensRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_ListRefreshTokensRequest,
    responseSerialize: serialize_interface_ti_users_v1_ListRefreshTokensResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_ListRefreshTokensResponse,
  },
  // Deletes an refresh_token.
deleteRefreshToken: {
    path: '/interface.ti.users.v1.RefreshTokensService/DeleteRefreshToken',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_refresh_token_pb.DeleteRefreshTokenRequest,
    responseType: interface_ti_users_v1_refresh_token_pb.RefreshToken,
    requestSerialize: serialize_interface_ti_users_v1_DeleteRefreshTokenRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_DeleteRefreshTokenRequest,
    responseSerialize: serialize_interface_ti_users_v1_RefreshToken,
    responseDeserialize: deserialize_interface_ti_users_v1_RefreshToken,
  },
  // Get a batch of refreshToken by their resource names.
batchGetRefreshTokens: {
    path: '/interface.ti.users.v1.RefreshTokensService/BatchGetRefreshTokens',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensRequest,
    responseType: interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchGetRefreshTokensRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchGetRefreshTokensRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchGetRefreshTokensResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchGetRefreshTokensResponse,
  },
  // Batch deletes refreshToken.
batchDeleteRefreshTokens: {
    path: '/interface.ti.users.v1.RefreshTokensService/BatchDeleteRefreshTokens',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensRequest,
    responseType: interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensResponse,
    requestSerialize: serialize_interface_ti_users_v1_BatchDeleteRefreshTokensRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_BatchDeleteRefreshTokensRequest,
    responseSerialize: serialize_interface_ti_users_v1_BatchDeleteRefreshTokensResponse,
    responseDeserialize: deserialize_interface_ti_users_v1_BatchDeleteRefreshTokensResponse,
  },
  // Stream refreshToken.
streamRefreshTokens: {
    path: '/interface.ti.users.v1.RefreshTokensService/StreamRefreshTokens',
    requestStream: false,
    responseStream: true,
    requestType: interface_ti_users_v1_refresh_token_pb.StreamRefreshTokensRequest,
    responseType: interface_ti_users_v1_refresh_token_pb.RefreshToken,
    requestSerialize: serialize_interface_ti_users_v1_StreamRefreshTokensRequest,
    requestDeserialize: deserialize_interface_ti_users_v1_StreamRefreshTokensRequest,
    responseSerialize: serialize_interface_ti_users_v1_RefreshToken,
    responseDeserialize: deserialize_interface_ti_users_v1_RefreshToken,
  },
};

exports.RefreshTokensServiceClient = grpc.makeGenericClientConstructor(RefreshTokensServiceService, 'RefreshTokensService');