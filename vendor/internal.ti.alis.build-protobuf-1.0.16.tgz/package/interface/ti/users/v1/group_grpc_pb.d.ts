// GENERATED CODE -- DO NOT EDIT!

// package: interface.ti.users.v1
// file: interface/ti/users/v1/group.proto

import * as interface_ti_users_v1_group_pb from "../../../../interface/ti/users/v1/group_pb";
import * as grpc from "@grpc/grpc-js";

interface IGroupsServiceService extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
  createGroup: grpc.MethodDefinition<interface_ti_users_v1_group_pb.CreateGroupRequest, interface_ti_users_v1_group_pb.Group>;
  getGroup: grpc.MethodDefinition<interface_ti_users_v1_group_pb.GetGroupRequest, interface_ti_users_v1_group_pb.Group>;
  updateGroup: grpc.MethodDefinition<interface_ti_users_v1_group_pb.UpdateGroupRequest, interface_ti_users_v1_group_pb.Group>;
  listGroups: grpc.MethodDefinition<interface_ti_users_v1_group_pb.ListGroupsRequest, interface_ti_users_v1_group_pb.ListGroupsResponse>;
  deleteGroup: grpc.MethodDefinition<interface_ti_users_v1_group_pb.DeleteGroupRequest, interface_ti_users_v1_group_pb.Group>;
  batchGetGroups: grpc.MethodDefinition<interface_ti_users_v1_group_pb.BatchGetGroupsRequest, interface_ti_users_v1_group_pb.BatchGetGroupsResponse>;
  batchDeleteGroups: grpc.MethodDefinition<interface_ti_users_v1_group_pb.BatchDeleteGroupsRequest, interface_ti_users_v1_group_pb.BatchDeleteGroupsResponse>;
  streamGroups: grpc.MethodDefinition<interface_ti_users_v1_group_pb.StreamGroupsRequest, interface_ti_users_v1_group_pb.Group>;
  syncGroup: grpc.MethodDefinition<interface_ti_users_v1_group_pb.SyncGroupRequest, interface_ti_users_v1_group_pb.SyncGroupResponse>;
}

export const GroupsServiceService: IGroupsServiceService;

export interface IGroupsServiceServer extends grpc.UntypedServiceImplementation {
  createGroup: grpc.handleUnaryCall<interface_ti_users_v1_group_pb.CreateGroupRequest, interface_ti_users_v1_group_pb.Group>;
  getGroup: grpc.handleUnaryCall<interface_ti_users_v1_group_pb.GetGroupRequest, interface_ti_users_v1_group_pb.Group>;
  updateGroup: grpc.handleUnaryCall<interface_ti_users_v1_group_pb.UpdateGroupRequest, interface_ti_users_v1_group_pb.Group>;
  listGroups: grpc.handleUnaryCall<interface_ti_users_v1_group_pb.ListGroupsRequest, interface_ti_users_v1_group_pb.ListGroupsResponse>;
  deleteGroup: grpc.handleUnaryCall<interface_ti_users_v1_group_pb.DeleteGroupRequest, interface_ti_users_v1_group_pb.Group>;
  batchGetGroups: grpc.handleUnaryCall<interface_ti_users_v1_group_pb.BatchGetGroupsRequest, interface_ti_users_v1_group_pb.BatchGetGroupsResponse>;
  batchDeleteGroups: grpc.handleUnaryCall<interface_ti_users_v1_group_pb.BatchDeleteGroupsRequest, interface_ti_users_v1_group_pb.BatchDeleteGroupsResponse>;
  streamGroups: grpc.handleServerStreamingCall<interface_ti_users_v1_group_pb.StreamGroupsRequest, interface_ti_users_v1_group_pb.Group>;
  syncGroup: grpc.handleUnaryCall<interface_ti_users_v1_group_pb.SyncGroupRequest, interface_ti_users_v1_group_pb.SyncGroupResponse>;
}

export class GroupsServiceClient extends grpc.Client {
  constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
  createGroup(argument: interface_ti_users_v1_group_pb.CreateGroupRequest, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.Group>): grpc.ClientUnaryCall;
  createGroup(argument: interface_ti_users_v1_group_pb.CreateGroupRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.Group>): grpc.ClientUnaryCall;
  createGroup(argument: interface_ti_users_v1_group_pb.CreateGroupRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.Group>): grpc.ClientUnaryCall;
  getGroup(argument: interface_ti_users_v1_group_pb.GetGroupRequest, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.Group>): grpc.ClientUnaryCall;
  getGroup(argument: interface_ti_users_v1_group_pb.GetGroupRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.Group>): grpc.ClientUnaryCall;
  getGroup(argument: interface_ti_users_v1_group_pb.GetGroupRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.Group>): grpc.ClientUnaryCall;
  updateGroup(argument: interface_ti_users_v1_group_pb.UpdateGroupRequest, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.Group>): grpc.ClientUnaryCall;
  updateGroup(argument: interface_ti_users_v1_group_pb.UpdateGroupRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.Group>): grpc.ClientUnaryCall;
  updateGroup(argument: interface_ti_users_v1_group_pb.UpdateGroupRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.Group>): grpc.ClientUnaryCall;
  listGroups(argument: interface_ti_users_v1_group_pb.ListGroupsRequest, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.ListGroupsResponse>): grpc.ClientUnaryCall;
  listGroups(argument: interface_ti_users_v1_group_pb.ListGroupsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.ListGroupsResponse>): grpc.ClientUnaryCall;
  listGroups(argument: interface_ti_users_v1_group_pb.ListGroupsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.ListGroupsResponse>): grpc.ClientUnaryCall;
  deleteGroup(argument: interface_ti_users_v1_group_pb.DeleteGroupRequest, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.Group>): grpc.ClientUnaryCall;
  deleteGroup(argument: interface_ti_users_v1_group_pb.DeleteGroupRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.Group>): grpc.ClientUnaryCall;
  deleteGroup(argument: interface_ti_users_v1_group_pb.DeleteGroupRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.Group>): grpc.ClientUnaryCall;
  batchGetGroups(argument: interface_ti_users_v1_group_pb.BatchGetGroupsRequest, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.BatchGetGroupsResponse>): grpc.ClientUnaryCall;
  batchGetGroups(argument: interface_ti_users_v1_group_pb.BatchGetGroupsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.BatchGetGroupsResponse>): grpc.ClientUnaryCall;
  batchGetGroups(argument: interface_ti_users_v1_group_pb.BatchGetGroupsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.BatchGetGroupsResponse>): grpc.ClientUnaryCall;
  batchDeleteGroups(argument: interface_ti_users_v1_group_pb.BatchDeleteGroupsRequest, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.BatchDeleteGroupsResponse>): grpc.ClientUnaryCall;
  batchDeleteGroups(argument: interface_ti_users_v1_group_pb.BatchDeleteGroupsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.BatchDeleteGroupsResponse>): grpc.ClientUnaryCall;
  batchDeleteGroups(argument: interface_ti_users_v1_group_pb.BatchDeleteGroupsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.BatchDeleteGroupsResponse>): grpc.ClientUnaryCall;
  streamGroups(argument: interface_ti_users_v1_group_pb.StreamGroupsRequest, metadataOrOptions?: grpc.Metadata | grpc.CallOptions | null): grpc.ClientReadableStream<interface_ti_users_v1_group_pb.Group>;
  streamGroups(argument: interface_ti_users_v1_group_pb.StreamGroupsRequest, metadata?: grpc.Metadata | null, options?: grpc.CallOptions | null): grpc.ClientReadableStream<interface_ti_users_v1_group_pb.Group>;
  syncGroup(argument: interface_ti_users_v1_group_pb.SyncGroupRequest, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.SyncGroupResponse>): grpc.ClientUnaryCall;
  syncGroup(argument: interface_ti_users_v1_group_pb.SyncGroupRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.SyncGroupResponse>): grpc.ClientUnaryCall;
  syncGroup(argument: interface_ti_users_v1_group_pb.SyncGroupRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_users_v1_group_pb.SyncGroupResponse>): grpc.ClientUnaryCall;
}