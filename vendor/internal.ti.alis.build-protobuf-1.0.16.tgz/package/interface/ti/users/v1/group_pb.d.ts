import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb'; // proto import: "google/protobuf/timestamp.proto"
import * as google_protobuf_field_mask_pb from 'google-protobuf/google/protobuf/field_mask_pb'; // proto import: "google/protobuf/field_mask.proto"


export class Group extends jspb.Message {
  getName(): string;
  setName(value: string): Group;

  getDisplayName(): string;
  setDisplayName(value: string): Group;

  getDescription(): string;
  setDescription(value: string): Group;

  getEtag(): string;
  setEtag(value: string): Group;

  getCreateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreateTime(value?: google_protobuf_timestamp_pb.Timestamp): Group;
  hasCreateTime(): boolean;
  clearCreateTime(): Group;

  getUpdateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setUpdateTime(value?: google_protobuf_timestamp_pb.Timestamp): Group;
  hasUpdateTime(): boolean;
  clearUpdateTime(): Group;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Group.AsObject;
  static toObject(includeInstance: boolean, msg: Group): Group.AsObject;
  static serializeBinaryToWriter(message: Group, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Group;
  static deserializeBinaryFromReader(message: Group, reader: jspb.BinaryReader): Group;
}

export namespace Group {
  export type AsObject = {
    name: string,
    displayName: string,
    description: string,
    etag: string,
    createTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    updateTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }
}

export class CreateGroupRequest extends jspb.Message {
  getGroup(): Group | undefined;
  setGroup(value?: Group): CreateGroupRequest;
  hasGroup(): boolean;
  clearGroup(): CreateGroupRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateGroupRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateGroupRequest): CreateGroupRequest.AsObject;
  static serializeBinaryToWriter(message: CreateGroupRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateGroupRequest;
  static deserializeBinaryFromReader(message: CreateGroupRequest, reader: jspb.BinaryReader): CreateGroupRequest;
}

export namespace CreateGroupRequest {
  export type AsObject = {
    group?: Group.AsObject,
  }
}

export class GetGroupRequest extends jspb.Message {
  getName(): string;
  setName(value: string): GetGroupRequest;

  getView(): GroupView;
  setView(value: GroupView): GetGroupRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): GetGroupRequest;
  hasReadMask(): boolean;
  clearReadMask(): GetGroupRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetGroupRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetGroupRequest): GetGroupRequest.AsObject;
  static serializeBinaryToWriter(message: GetGroupRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetGroupRequest;
  static deserializeBinaryFromReader(message: GetGroupRequest, reader: jspb.BinaryReader): GetGroupRequest;
}

export namespace GetGroupRequest {
  export type AsObject = {
    name: string,
    view: GroupView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class UpdateGroupRequest extends jspb.Message {
  getGroup(): Group | undefined;
  setGroup(value?: Group): UpdateGroupRequest;
  hasGroup(): boolean;
  clearGroup(): UpdateGroupRequest;

  getUpdateMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setUpdateMask(value?: google_protobuf_field_mask_pb.FieldMask): UpdateGroupRequest;
  hasUpdateMask(): boolean;
  clearUpdateMask(): UpdateGroupRequest;

  getAllowMissing(): boolean;
  setAllowMissing(value: boolean): UpdateGroupRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateGroupRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateGroupRequest): UpdateGroupRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateGroupRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateGroupRequest;
  static deserializeBinaryFromReader(message: UpdateGroupRequest, reader: jspb.BinaryReader): UpdateGroupRequest;
}

export namespace UpdateGroupRequest {
  export type AsObject = {
    group?: Group.AsObject,
    updateMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    allowMissing: boolean,
  }
}

export class DeleteGroupRequest extends jspb.Message {
  getName(): string;
  setName(value: string): DeleteGroupRequest;

  getEtag(): string;
  setEtag(value: string): DeleteGroupRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteGroupRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteGroupRequest): DeleteGroupRequest.AsObject;
  static serializeBinaryToWriter(message: DeleteGroupRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteGroupRequest;
  static deserializeBinaryFromReader(message: DeleteGroupRequest, reader: jspb.BinaryReader): DeleteGroupRequest;
}

export namespace DeleteGroupRequest {
  export type AsObject = {
    name: string,
    etag: string,
  }
}

export class ListGroupsRequest extends jspb.Message {
  getPageSize(): number;
  setPageSize(value: number): ListGroupsRequest;

  getPageToken(): string;
  setPageToken(value: string): ListGroupsRequest;

  getView(): GroupView;
  setView(value: GroupView): ListGroupsRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): ListGroupsRequest;
  hasReadMask(): boolean;
  clearReadMask(): ListGroupsRequest;

  getFilter(): string;
  setFilter(value: string): ListGroupsRequest;

  getOrderBy(): string;
  setOrderBy(value: string): ListGroupsRequest;

  getShowDeleted(): boolean;
  setShowDeleted(value: boolean): ListGroupsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListGroupsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListGroupsRequest): ListGroupsRequest.AsObject;
  static serializeBinaryToWriter(message: ListGroupsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListGroupsRequest;
  static deserializeBinaryFromReader(message: ListGroupsRequest, reader: jspb.BinaryReader): ListGroupsRequest;
}

export namespace ListGroupsRequest {
  export type AsObject = {
    pageSize: number,
    pageToken: string,
    view: GroupView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
    orderBy: string,
    showDeleted: boolean,
  }
}

export class ListGroupsResponse extends jspb.Message {
  getGroupsList(): Array<Group>;
  setGroupsList(value: Array<Group>): ListGroupsResponse;
  clearGroupsList(): ListGroupsResponse;
  addGroups(value?: Group, index?: number): Group;

  getNextPageToken(): string;
  setNextPageToken(value: string): ListGroupsResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListGroupsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListGroupsResponse): ListGroupsResponse.AsObject;
  static serializeBinaryToWriter(message: ListGroupsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListGroupsResponse;
  static deserializeBinaryFromReader(message: ListGroupsResponse, reader: jspb.BinaryReader): ListGroupsResponse;
}

export namespace ListGroupsResponse {
  export type AsObject = {
    groupsList: Array<Group.AsObject>,
    nextPageToken: string,
  }
}

export class BatchGetGroupsRequest extends jspb.Message {
  getNamesList(): Array<string>;
  setNamesList(value: Array<string>): BatchGetGroupsRequest;
  clearNamesList(): BatchGetGroupsRequest;
  addNames(value: string, index?: number): BatchGetGroupsRequest;

  getView(): GroupView;
  setView(value: GroupView): BatchGetGroupsRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): BatchGetGroupsRequest;
  hasReadMask(): boolean;
  clearReadMask(): BatchGetGroupsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchGetGroupsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchGetGroupsRequest): BatchGetGroupsRequest.AsObject;
  static serializeBinaryToWriter(message: BatchGetGroupsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchGetGroupsRequest;
  static deserializeBinaryFromReader(message: BatchGetGroupsRequest, reader: jspb.BinaryReader): BatchGetGroupsRequest;
}

export namespace BatchGetGroupsRequest {
  export type AsObject = {
    namesList: Array<string>,
    view: GroupView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class BatchGetGroupsResponse extends jspb.Message {
  getGroupsList(): Array<Group>;
  setGroupsList(value: Array<Group>): BatchGetGroupsResponse;
  clearGroupsList(): BatchGetGroupsResponse;
  addGroups(value?: Group, index?: number): Group;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchGetGroupsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchGetGroupsResponse): BatchGetGroupsResponse.AsObject;
  static serializeBinaryToWriter(message: BatchGetGroupsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchGetGroupsResponse;
  static deserializeBinaryFromReader(message: BatchGetGroupsResponse, reader: jspb.BinaryReader): BatchGetGroupsResponse;
}

export namespace BatchGetGroupsResponse {
  export type AsObject = {
    groupsList: Array<Group.AsObject>,
  }
}

export class BatchDeleteGroupsRequest extends jspb.Message {
  getRequestsList(): Array<DeleteGroupRequest>;
  setRequestsList(value: Array<DeleteGroupRequest>): BatchDeleteGroupsRequest;
  clearRequestsList(): BatchDeleteGroupsRequest;
  addRequests(value?: DeleteGroupRequest, index?: number): DeleteGroupRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchDeleteGroupsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchDeleteGroupsRequest): BatchDeleteGroupsRequest.AsObject;
  static serializeBinaryToWriter(message: BatchDeleteGroupsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchDeleteGroupsRequest;
  static deserializeBinaryFromReader(message: BatchDeleteGroupsRequest, reader: jspb.BinaryReader): BatchDeleteGroupsRequest;
}

export namespace BatchDeleteGroupsRequest {
  export type AsObject = {
    requestsList: Array<DeleteGroupRequest.AsObject>,
  }
}

export class BatchDeleteGroupsResponse extends jspb.Message {
  getGroupsList(): Array<Group>;
  setGroupsList(value: Array<Group>): BatchDeleteGroupsResponse;
  clearGroupsList(): BatchDeleteGroupsResponse;
  addGroups(value?: Group, index?: number): Group;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchDeleteGroupsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchDeleteGroupsResponse): BatchDeleteGroupsResponse.AsObject;
  static serializeBinaryToWriter(message: BatchDeleteGroupsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchDeleteGroupsResponse;
  static deserializeBinaryFromReader(message: BatchDeleteGroupsResponse, reader: jspb.BinaryReader): BatchDeleteGroupsResponse;
}

export namespace BatchDeleteGroupsResponse {
  export type AsObject = {
    groupsList: Array<Group.AsObject>,
  }
}

export class StreamGroupsRequest extends jspb.Message {
  getView(): GroupView;
  setView(value: GroupView): StreamGroupsRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): StreamGroupsRequest;
  hasReadMask(): boolean;
  clearReadMask(): StreamGroupsRequest;

  getFilter(): string;
  setFilter(value: string): StreamGroupsRequest;

  getOrderBy(): string;
  setOrderBy(value: string): StreamGroupsRequest;

  getShowDeleted(): boolean;
  setShowDeleted(value: boolean): StreamGroupsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StreamGroupsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: StreamGroupsRequest): StreamGroupsRequest.AsObject;
  static serializeBinaryToWriter(message: StreamGroupsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StreamGroupsRequest;
  static deserializeBinaryFromReader(message: StreamGroupsRequest, reader: jspb.BinaryReader): StreamGroupsRequest;
}

export namespace StreamGroupsRequest {
  export type AsObject = {
    view: GroupView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
    orderBy: string,
    showDeleted: boolean,
  }
}

export class SyncGroupRequest extends jspb.Message {
  getGroup(): string;
  setGroup(value: string): SyncGroupRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SyncGroupRequest.AsObject;
  static toObject(includeInstance: boolean, msg: SyncGroupRequest): SyncGroupRequest.AsObject;
  static serializeBinaryToWriter(message: SyncGroupRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SyncGroupRequest;
  static deserializeBinaryFromReader(message: SyncGroupRequest, reader: jspb.BinaryReader): SyncGroupRequest;
}

export namespace SyncGroupRequest {
  export type AsObject = {
    group: string,
  }
}

export class SyncGroupResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SyncGroupResponse.AsObject;
  static toObject(includeInstance: boolean, msg: SyncGroupResponse): SyncGroupResponse.AsObject;
  static serializeBinaryToWriter(message: SyncGroupResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SyncGroupResponse;
  static deserializeBinaryFromReader(message: SyncGroupResponse, reader: jspb.BinaryReader): SyncGroupResponse;
}

export namespace SyncGroupResponse {
  export type AsObject = {
  }
}

export enum GroupView { 
  GROUP_VIEW_UNSPECIFIED = 0,
  GROUP_VIEW_BASIC = 1,
  GROUP_VIEW_FULL = 2,
}