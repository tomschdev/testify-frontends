import * as grpcWeb from 'grpc-web';

import * as alis_open_iam_v1_iam_pb from '@open.alis.services/protobuf/alis/open/iam/v1/iam_pb'; // proto import: "alis/open/iam/v1/iam.proto"
import * as google_iam_v1_iam_policy_pb from '@alis-build/google-common-protos/google/iam/v1/iam_policy_pb'; // proto import: "google/iam/v1/iam_policy.proto"
import * as google_iam_v1_policy_pb from '@alis-build/google-common-protos/google/iam/v1/policy_pb'; // proto import: "google/iam/v1/policy.proto"
import * as google_longrunning_operations_pb from '@alis-build/google-common-protos/google/longrunning/operations_pb'; // proto import: "google/longrunning/operations.proto"
import * as google_protobuf_empty_pb from 'google-protobuf/google/protobuf/empty_pb'; // proto import: "google/protobuf/empty.proto"
import * as interface_ti_users_v1_user_pb from '../../../../interface/ti/users/v1/user_pb'; // proto import: "interface/ti/users/v1/user.proto"


export class UsersServiceClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  getIamPolicy(
    request: google_iam_v1_iam_policy_pb.GetIamPolicyRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_policy_pb.Policy) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_policy_pb.Policy>;

  setIamPolicy(
    request: google_iam_v1_iam_policy_pb.SetIamPolicyRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_policy_pb.Policy) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_policy_pb.Policy>;

  testIamPermissions(
    request: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_iam_policy_pb.TestIamPermissionsResponse) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>;

  batchTestIamPermissions(
    request: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse) => void
  ): grpcWeb.ClientReadableStream<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>;

  addIamBindings(
    request: alis_open_iam_v1_iam_pb.AddIamBindingsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_policy_pb.Policy) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_policy_pb.Policy>;

  removeIamBindings(
    request: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_iam_v1_policy_pb.Policy) => void
  ): grpcWeb.ClientReadableStream<google_iam_v1_policy_pb.Policy>;

  createUser(
    request: interface_ti_users_v1_user_pb.CreateUserRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.User) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.User>;

  getUser(
    request: interface_ti_users_v1_user_pb.GetUserRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.User) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.User>;

  updateUser(
    request: interface_ti_users_v1_user_pb.UpdateUserRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.User) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.User>;

  listUsers(
    request: interface_ti_users_v1_user_pb.ListUsersRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.ListUsersResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.ListUsersResponse>;

  deleteUser(
    request: interface_ti_users_v1_user_pb.DeleteUserRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.User) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.User>;

  batchGetUsers(
    request: interface_ti_users_v1_user_pb.BatchGetUsersRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.BatchGetUsersResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.BatchGetUsersResponse>;

  batchDeleteUsers(
    request: interface_ti_users_v1_user_pb.BatchDeleteUsersRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.BatchDeleteUsersResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.BatchDeleteUsersResponse>;

  streamUsers(
    request: interface_ti_users_v1_user_pb.StreamUsersRequest,
    metadata?: grpcWeb.Metadata
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.User>;

  lookupUser(
    request: interface_ti_users_v1_user_pb.LookupUserRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.LookupUserResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.LookupUserResponse>;

  batchRetrieveMaskedUsers(
    request: interface_ti_users_v1_user_pb.BatchRetrieveMaskedUsersRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.BatchRetrieveMaskedUsersResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.BatchRetrieveMaskedUsersResponse>;

  retrieveMaskedUsers(
    request: interface_ti_users_v1_user_pb.RetrieveMaskedUsersRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.RetrieveMaskedUsersResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.RetrieveMaskedUsersResponse>;

  retrieveMaskedUser(
    request: interface_ti_users_v1_user_pb.RetrieveMaskedUserRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.MaskedUser) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.MaskedUser>;

  editUserInfo(
    request: interface_ti_users_v1_user_pb.EditUserInfoRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.User) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.User>;

  editUserMetadata(
    request: interface_ti_users_v1_user_pb.EditUserMetadataRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.User) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.User>;

  retrieveMyUser(
    request: interface_ti_users_v1_user_pb.RetrieveMyUserRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.User) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.User>;

  editMyInfo(
    request: interface_ti_users_v1_user_pb.EditMyInfoRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.User) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.User>;

  editMyMetadata(
    request: interface_ti_users_v1_user_pb.EditMyMetadataRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.User) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.User>;

  removeMyUser(
    request: interface_ti_users_v1_user_pb.RemoveMyUserRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_protobuf_empty_pb.Empty) => void
  ): grpcWeb.ClientReadableStream<google_protobuf_empty_pb.Empty>;

  syncToGoogleGroup(
    request: interface_ti_users_v1_user_pb.SyncToGoogleGroupRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.SyncToGoogleGroupResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.SyncToGoogleGroupResponse>;

  setUserPicture(
    request: interface_ti_users_v1_user_pb.SetUserPictureRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.SetUserPictureResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.SetUserPictureResponse>;

  retrieveUserByEmail(
    request: interface_ti_users_v1_user_pb.RetrieveUserByEmailRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.User) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.User>;

  createConnector(
    request: interface_ti_users_v1_user_pb.CreateConnectorRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.Connector) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.Connector>;

  getConnector(
    request: interface_ti_users_v1_user_pb.GetConnectorRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.Connector) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.Connector>;

  updateConnector(
    request: interface_ti_users_v1_user_pb.UpdateConnectorRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.Connector) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.Connector>;

  listConnectors(
    request: interface_ti_users_v1_user_pb.ListConnectorsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.ListConnectorsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.ListConnectorsResponse>;

  deleteConnector(
    request: interface_ti_users_v1_user_pb.DeleteConnectorRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.Connector) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.Connector>;

  undeleteConnector(
    request: interface_ti_users_v1_user_pb.UndeleteConnectorRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.Connector) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.Connector>;

  batchCreateConnectors(
    request: interface_ti_users_v1_user_pb.BatchCreateConnectorsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.BatchCreateConnectorsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.BatchCreateConnectorsResponse>;

  batchGetConnectors(
    request: interface_ti_users_v1_user_pb.BatchGetConnectorsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.BatchGetConnectorsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.BatchGetConnectorsResponse>;

  batchUpdateConnectors(
    request: interface_ti_users_v1_user_pb.BatchUpdateConnectorsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.BatchUpdateConnectorsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.BatchUpdateConnectorsResponse>;

  batchDeleteConnectors(
    request: interface_ti_users_v1_user_pb.BatchDeleteConnectorsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.BatchDeleteConnectorsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.BatchDeleteConnectorsResponse>;

  batchUndeleteConnectors(
    request: interface_ti_users_v1_user_pb.BatchUndeleteConnectorsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.BatchUndeleteConnectorsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.BatchUndeleteConnectorsResponse>;

  streamConnectors(
    request: interface_ti_users_v1_user_pb.StreamConnectorsRequest,
    metadata?: grpcWeb.Metadata
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.Connector>;

  authorizeConnector(
    request: interface_ti_users_v1_user_pb.AuthorizeConnectorRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: google_longrunning_operations_pb.Operation) => void
  ): grpcWeb.ClientReadableStream<google_longrunning_operations_pb.Operation>;

  fetchAccessToken(
    request: interface_ti_users_v1_user_pb.FetchAccessTokenRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.FetchAccessTokenResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.FetchAccessTokenResponse>;

  revokeConnector(
    request: interface_ti_users_v1_user_pb.RevokeConnectorRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.RevokeConnectorResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.RevokeConnectorResponse>;

  listMyAvailableConnectors(
    request: interface_ti_users_v1_user_pb.ListMyAvailableConnectorsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_user_pb.ListMyAvailableConnectorsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.ListMyAvailableConnectorsResponse>;

}

export class UsersServicePromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  getIamPolicy(
    request: google_iam_v1_iam_policy_pb.GetIamPolicyRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_policy_pb.Policy>;

  setIamPolicy(
    request: google_iam_v1_iam_policy_pb.SetIamPolicyRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_policy_pb.Policy>;

  testIamPermissions(
    request: google_iam_v1_iam_policy_pb.TestIamPermissionsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_iam_policy_pb.TestIamPermissionsResponse>;

  batchTestIamPermissions(
    request: alis_open_iam_v1_iam_pb.BatchTestIamPermissionsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<alis_open_iam_v1_iam_pb.BatchTestIamPermissionsResponse>;

  addIamBindings(
    request: alis_open_iam_v1_iam_pb.AddIamBindingsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_policy_pb.Policy>;

  removeIamBindings(
    request: alis_open_iam_v1_iam_pb.RemoveIamBindingsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_iam_v1_policy_pb.Policy>;

  createUser(
    request: interface_ti_users_v1_user_pb.CreateUserRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.User>;

  getUser(
    request: interface_ti_users_v1_user_pb.GetUserRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.User>;

  updateUser(
    request: interface_ti_users_v1_user_pb.UpdateUserRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.User>;

  listUsers(
    request: interface_ti_users_v1_user_pb.ListUsersRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.ListUsersResponse>;

  deleteUser(
    request: interface_ti_users_v1_user_pb.DeleteUserRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.User>;

  batchGetUsers(
    request: interface_ti_users_v1_user_pb.BatchGetUsersRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.BatchGetUsersResponse>;

  batchDeleteUsers(
    request: interface_ti_users_v1_user_pb.BatchDeleteUsersRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.BatchDeleteUsersResponse>;

  streamUsers(
    request: interface_ti_users_v1_user_pb.StreamUsersRequest,
    metadata?: grpcWeb.Metadata
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.User>;

  lookupUser(
    request: interface_ti_users_v1_user_pb.LookupUserRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.LookupUserResponse>;

  batchRetrieveMaskedUsers(
    request: interface_ti_users_v1_user_pb.BatchRetrieveMaskedUsersRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.BatchRetrieveMaskedUsersResponse>;

  retrieveMaskedUsers(
    request: interface_ti_users_v1_user_pb.RetrieveMaskedUsersRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.RetrieveMaskedUsersResponse>;

  retrieveMaskedUser(
    request: interface_ti_users_v1_user_pb.RetrieveMaskedUserRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.MaskedUser>;

  editUserInfo(
    request: interface_ti_users_v1_user_pb.EditUserInfoRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.User>;

  editUserMetadata(
    request: interface_ti_users_v1_user_pb.EditUserMetadataRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.User>;

  retrieveMyUser(
    request: interface_ti_users_v1_user_pb.RetrieveMyUserRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.User>;

  editMyInfo(
    request: interface_ti_users_v1_user_pb.EditMyInfoRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.User>;

  editMyMetadata(
    request: interface_ti_users_v1_user_pb.EditMyMetadataRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.User>;

  removeMyUser(
    request: interface_ti_users_v1_user_pb.RemoveMyUserRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_protobuf_empty_pb.Empty>;

  syncToGoogleGroup(
    request: interface_ti_users_v1_user_pb.SyncToGoogleGroupRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.SyncToGoogleGroupResponse>;

  setUserPicture(
    request: interface_ti_users_v1_user_pb.SetUserPictureRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.SetUserPictureResponse>;

  retrieveUserByEmail(
    request: interface_ti_users_v1_user_pb.RetrieveUserByEmailRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.User>;

  createConnector(
    request: interface_ti_users_v1_user_pb.CreateConnectorRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.Connector>;

  getConnector(
    request: interface_ti_users_v1_user_pb.GetConnectorRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.Connector>;

  updateConnector(
    request: interface_ti_users_v1_user_pb.UpdateConnectorRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.Connector>;

  listConnectors(
    request: interface_ti_users_v1_user_pb.ListConnectorsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.ListConnectorsResponse>;

  deleteConnector(
    request: interface_ti_users_v1_user_pb.DeleteConnectorRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.Connector>;

  undeleteConnector(
    request: interface_ti_users_v1_user_pb.UndeleteConnectorRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.Connector>;

  batchCreateConnectors(
    request: interface_ti_users_v1_user_pb.BatchCreateConnectorsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.BatchCreateConnectorsResponse>;

  batchGetConnectors(
    request: interface_ti_users_v1_user_pb.BatchGetConnectorsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.BatchGetConnectorsResponse>;

  batchUpdateConnectors(
    request: interface_ti_users_v1_user_pb.BatchUpdateConnectorsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.BatchUpdateConnectorsResponse>;

  batchDeleteConnectors(
    request: interface_ti_users_v1_user_pb.BatchDeleteConnectorsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.BatchDeleteConnectorsResponse>;

  batchUndeleteConnectors(
    request: interface_ti_users_v1_user_pb.BatchUndeleteConnectorsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.BatchUndeleteConnectorsResponse>;

  streamConnectors(
    request: interface_ti_users_v1_user_pb.StreamConnectorsRequest,
    metadata?: grpcWeb.Metadata
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_user_pb.Connector>;

  authorizeConnector(
    request: interface_ti_users_v1_user_pb.AuthorizeConnectorRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<google_longrunning_operations_pb.Operation>;

  fetchAccessToken(
    request: interface_ti_users_v1_user_pb.FetchAccessTokenRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.FetchAccessTokenResponse>;

  revokeConnector(
    request: interface_ti_users_v1_user_pb.RevokeConnectorRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.RevokeConnectorResponse>;

  listMyAvailableConnectors(
    request: interface_ti_users_v1_user_pb.ListMyAvailableConnectorsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_user_pb.ListMyAvailableConnectorsResponse>;

}
