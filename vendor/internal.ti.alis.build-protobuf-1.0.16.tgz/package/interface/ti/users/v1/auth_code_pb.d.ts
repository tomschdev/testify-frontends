import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb'; // proto import: "google/protobuf/timestamp.proto"
import * as google_protobuf_field_mask_pb from 'google-protobuf/google/protobuf/field_mask_pb'; // proto import: "google/protobuf/field_mask.proto"


export class AuthCode extends jspb.Message {
  getName(): string;
  setName(value: string): AuthCode;

  getUser(): string;
  setUser(value: string): AuthCode;

  getRedirectUri(): string;
  setRedirectUri(value: string): AuthCode;

  getExpiryTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setExpiryTime(value?: google_protobuf_timestamp_pb.Timestamp): AuthCode;
  hasExpiryTime(): boolean;
  clearExpiryTime(): AuthCode;

  getClientId(): string;
  setClientId(value: string): AuthCode;

  getScopesList(): Array<string>;
  setScopesList(value: Array<string>): AuthCode;
  clearScopesList(): AuthCode;
  addScopes(value: string, index?: number): AuthCode;

  getEtag(): string;
  setEtag(value: string): AuthCode;

  getCreateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreateTime(value?: google_protobuf_timestamp_pb.Timestamp): AuthCode;
  hasCreateTime(): boolean;
  clearCreateTime(): AuthCode;

  getUpdateTime(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setUpdateTime(value?: google_protobuf_timestamp_pb.Timestamp): AuthCode;
  hasUpdateTime(): boolean;
  clearUpdateTime(): AuthCode;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AuthCode.AsObject;
  static toObject(includeInstance: boolean, msg: AuthCode): AuthCode.AsObject;
  static serializeBinaryToWriter(message: AuthCode, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AuthCode;
  static deserializeBinaryFromReader(message: AuthCode, reader: jspb.BinaryReader): AuthCode;
}

export namespace AuthCode {
  export type AsObject = {
    name: string,
    user: string,
    redirectUri: string,
    expiryTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    clientId: string,
    scopesList: Array<string>,
    etag: string,
    createTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    updateTime?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }
}

export class CreateAuthCodeRequest extends jspb.Message {
  getAuthCode(): AuthCode | undefined;
  setAuthCode(value?: AuthCode): CreateAuthCodeRequest;
  hasAuthCode(): boolean;
  clearAuthCode(): CreateAuthCodeRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateAuthCodeRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateAuthCodeRequest): CreateAuthCodeRequest.AsObject;
  static serializeBinaryToWriter(message: CreateAuthCodeRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateAuthCodeRequest;
  static deserializeBinaryFromReader(message: CreateAuthCodeRequest, reader: jspb.BinaryReader): CreateAuthCodeRequest;
}

export namespace CreateAuthCodeRequest {
  export type AsObject = {
    authCode?: AuthCode.AsObject,
  }
}

export class GetAuthCodeRequest extends jspb.Message {
  getName(): string;
  setName(value: string): GetAuthCodeRequest;

  getView(): AuthCodeView;
  setView(value: AuthCodeView): GetAuthCodeRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): GetAuthCodeRequest;
  hasReadMask(): boolean;
  clearReadMask(): GetAuthCodeRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetAuthCodeRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetAuthCodeRequest): GetAuthCodeRequest.AsObject;
  static serializeBinaryToWriter(message: GetAuthCodeRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetAuthCodeRequest;
  static deserializeBinaryFromReader(message: GetAuthCodeRequest, reader: jspb.BinaryReader): GetAuthCodeRequest;
}

export namespace GetAuthCodeRequest {
  export type AsObject = {
    name: string,
    view: AuthCodeView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class UpdateAuthCodeRequest extends jspb.Message {
  getAuthCode(): AuthCode | undefined;
  setAuthCode(value?: AuthCode): UpdateAuthCodeRequest;
  hasAuthCode(): boolean;
  clearAuthCode(): UpdateAuthCodeRequest;

  getUpdateMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setUpdateMask(value?: google_protobuf_field_mask_pb.FieldMask): UpdateAuthCodeRequest;
  hasUpdateMask(): boolean;
  clearUpdateMask(): UpdateAuthCodeRequest;

  getAllowMissing(): boolean;
  setAllowMissing(value: boolean): UpdateAuthCodeRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateAuthCodeRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateAuthCodeRequest): UpdateAuthCodeRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateAuthCodeRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateAuthCodeRequest;
  static deserializeBinaryFromReader(message: UpdateAuthCodeRequest, reader: jspb.BinaryReader): UpdateAuthCodeRequest;
}

export namespace UpdateAuthCodeRequest {
  export type AsObject = {
    authCode?: AuthCode.AsObject,
    updateMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    allowMissing: boolean,
  }
}

export class DeleteAuthCodeRequest extends jspb.Message {
  getName(): string;
  setName(value: string): DeleteAuthCodeRequest;

  getEtag(): string;
  setEtag(value: string): DeleteAuthCodeRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteAuthCodeRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteAuthCodeRequest): DeleteAuthCodeRequest.AsObject;
  static serializeBinaryToWriter(message: DeleteAuthCodeRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteAuthCodeRequest;
  static deserializeBinaryFromReader(message: DeleteAuthCodeRequest, reader: jspb.BinaryReader): DeleteAuthCodeRequest;
}

export namespace DeleteAuthCodeRequest {
  export type AsObject = {
    name: string,
    etag: string,
  }
}

export class ListAuthCodesRequest extends jspb.Message {
  getPageSize(): number;
  setPageSize(value: number): ListAuthCodesRequest;

  getPageToken(): string;
  setPageToken(value: string): ListAuthCodesRequest;

  getView(): AuthCodeView;
  setView(value: AuthCodeView): ListAuthCodesRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): ListAuthCodesRequest;
  hasReadMask(): boolean;
  clearReadMask(): ListAuthCodesRequest;

  getFilter(): string;
  setFilter(value: string): ListAuthCodesRequest;

  getOrderBy(): string;
  setOrderBy(value: string): ListAuthCodesRequest;

  getShowDeleted(): boolean;
  setShowDeleted(value: boolean): ListAuthCodesRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListAuthCodesRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListAuthCodesRequest): ListAuthCodesRequest.AsObject;
  static serializeBinaryToWriter(message: ListAuthCodesRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListAuthCodesRequest;
  static deserializeBinaryFromReader(message: ListAuthCodesRequest, reader: jspb.BinaryReader): ListAuthCodesRequest;
}

export namespace ListAuthCodesRequest {
  export type AsObject = {
    pageSize: number,
    pageToken: string,
    view: AuthCodeView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
    orderBy: string,
    showDeleted: boolean,
  }
}

export class ListAuthCodesResponse extends jspb.Message {
  getAuthCodesList(): Array<AuthCode>;
  setAuthCodesList(value: Array<AuthCode>): ListAuthCodesResponse;
  clearAuthCodesList(): ListAuthCodesResponse;
  addAuthCodes(value?: AuthCode, index?: number): AuthCode;

  getNextPageToken(): string;
  setNextPageToken(value: string): ListAuthCodesResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListAuthCodesResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListAuthCodesResponse): ListAuthCodesResponse.AsObject;
  static serializeBinaryToWriter(message: ListAuthCodesResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListAuthCodesResponse;
  static deserializeBinaryFromReader(message: ListAuthCodesResponse, reader: jspb.BinaryReader): ListAuthCodesResponse;
}

export namespace ListAuthCodesResponse {
  export type AsObject = {
    authCodesList: Array<AuthCode.AsObject>,
    nextPageToken: string,
  }
}

export class BatchGetAuthCodesRequest extends jspb.Message {
  getNamesList(): Array<string>;
  setNamesList(value: Array<string>): BatchGetAuthCodesRequest;
  clearNamesList(): BatchGetAuthCodesRequest;
  addNames(value: string, index?: number): BatchGetAuthCodesRequest;

  getView(): AuthCodeView;
  setView(value: AuthCodeView): BatchGetAuthCodesRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): BatchGetAuthCodesRequest;
  hasReadMask(): boolean;
  clearReadMask(): BatchGetAuthCodesRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchGetAuthCodesRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchGetAuthCodesRequest): BatchGetAuthCodesRequest.AsObject;
  static serializeBinaryToWriter(message: BatchGetAuthCodesRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchGetAuthCodesRequest;
  static deserializeBinaryFromReader(message: BatchGetAuthCodesRequest, reader: jspb.BinaryReader): BatchGetAuthCodesRequest;
}

export namespace BatchGetAuthCodesRequest {
  export type AsObject = {
    namesList: Array<string>,
    view: AuthCodeView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
  }
}

export class BatchGetAuthCodesResponse extends jspb.Message {
  getAuthCodesList(): Array<AuthCode>;
  setAuthCodesList(value: Array<AuthCode>): BatchGetAuthCodesResponse;
  clearAuthCodesList(): BatchGetAuthCodesResponse;
  addAuthCodes(value?: AuthCode, index?: number): AuthCode;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchGetAuthCodesResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchGetAuthCodesResponse): BatchGetAuthCodesResponse.AsObject;
  static serializeBinaryToWriter(message: BatchGetAuthCodesResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchGetAuthCodesResponse;
  static deserializeBinaryFromReader(message: BatchGetAuthCodesResponse, reader: jspb.BinaryReader): BatchGetAuthCodesResponse;
}

export namespace BatchGetAuthCodesResponse {
  export type AsObject = {
    authCodesList: Array<AuthCode.AsObject>,
  }
}

export class BatchDeleteAuthCodesRequest extends jspb.Message {
  getRequestsList(): Array<DeleteAuthCodeRequest>;
  setRequestsList(value: Array<DeleteAuthCodeRequest>): BatchDeleteAuthCodesRequest;
  clearRequestsList(): BatchDeleteAuthCodesRequest;
  addRequests(value?: DeleteAuthCodeRequest, index?: number): DeleteAuthCodeRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchDeleteAuthCodesRequest.AsObject;
  static toObject(includeInstance: boolean, msg: BatchDeleteAuthCodesRequest): BatchDeleteAuthCodesRequest.AsObject;
  static serializeBinaryToWriter(message: BatchDeleteAuthCodesRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchDeleteAuthCodesRequest;
  static deserializeBinaryFromReader(message: BatchDeleteAuthCodesRequest, reader: jspb.BinaryReader): BatchDeleteAuthCodesRequest;
}

export namespace BatchDeleteAuthCodesRequest {
  export type AsObject = {
    requestsList: Array<DeleteAuthCodeRequest.AsObject>,
  }
}

export class BatchDeleteAuthCodesResponse extends jspb.Message {
  getAuthCodesList(): Array<AuthCode>;
  setAuthCodesList(value: Array<AuthCode>): BatchDeleteAuthCodesResponse;
  clearAuthCodesList(): BatchDeleteAuthCodesResponse;
  addAuthCodes(value?: AuthCode, index?: number): AuthCode;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BatchDeleteAuthCodesResponse.AsObject;
  static toObject(includeInstance: boolean, msg: BatchDeleteAuthCodesResponse): BatchDeleteAuthCodesResponse.AsObject;
  static serializeBinaryToWriter(message: BatchDeleteAuthCodesResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BatchDeleteAuthCodesResponse;
  static deserializeBinaryFromReader(message: BatchDeleteAuthCodesResponse, reader: jspb.BinaryReader): BatchDeleteAuthCodesResponse;
}

export namespace BatchDeleteAuthCodesResponse {
  export type AsObject = {
    authCodesList: Array<AuthCode.AsObject>,
  }
}

export class StreamAuthCodesRequest extends jspb.Message {
  getView(): AuthCodeView;
  setView(value: AuthCodeView): StreamAuthCodesRequest;

  getReadMask(): google_protobuf_field_mask_pb.FieldMask | undefined;
  setReadMask(value?: google_protobuf_field_mask_pb.FieldMask): StreamAuthCodesRequest;
  hasReadMask(): boolean;
  clearReadMask(): StreamAuthCodesRequest;

  getFilter(): string;
  setFilter(value: string): StreamAuthCodesRequest;

  getOrderBy(): string;
  setOrderBy(value: string): StreamAuthCodesRequest;

  getShowDeleted(): boolean;
  setShowDeleted(value: boolean): StreamAuthCodesRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StreamAuthCodesRequest.AsObject;
  static toObject(includeInstance: boolean, msg: StreamAuthCodesRequest): StreamAuthCodesRequest.AsObject;
  static serializeBinaryToWriter(message: StreamAuthCodesRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StreamAuthCodesRequest;
  static deserializeBinaryFromReader(message: StreamAuthCodesRequest, reader: jspb.BinaryReader): StreamAuthCodesRequest;
}

export namespace StreamAuthCodesRequest {
  export type AsObject = {
    view: AuthCodeView,
    readMask?: google_protobuf_field_mask_pb.FieldMask.AsObject,
    filter: string,
    orderBy: string,
    showDeleted: boolean,
  }
}

export enum AuthCodeView { 
  AUTH_CODE_VIEW_UNSPECIFIED = 0,
  AUTH_CODE_VIEW_BASIC = 1,
  AUTH_CODE_VIEW_FULL = 2,
}