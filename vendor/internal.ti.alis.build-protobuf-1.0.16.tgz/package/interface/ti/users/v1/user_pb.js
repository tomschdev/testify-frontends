// source: interface/ti/users/v1/user.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {missingRequire} reports error on implicit type usages.
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!
/* eslint-disable */
// @ts-nocheck

var jspb = require('google-protobuf');
var goog = jspb;
var global = globalThis;

var alis_open_iam_v1_iam_pb = require('@open.alis.services/protobuf/alis/open/iam/v1/iam_pb.js');
goog.object.extend(proto, alis_open_iam_v1_iam_pb);
var google_iam_v1_iam_policy_pb = require('@alis-build/google-common-protos/google/iam/v1/iam_policy_pb.js');
goog.object.extend(proto, google_iam_v1_iam_policy_pb);
var google_iam_v1_policy_pb = require('@alis-build/google-common-protos/google/iam/v1/policy_pb.js');
goog.object.extend(proto, google_iam_v1_policy_pb);
var google_longrunning_operations_pb = require('@alis-build/google-common-protos/google/longrunning/operations_pb.js');
goog.object.extend(proto, google_longrunning_operations_pb);
var google_protobuf_any_pb = require('google-protobuf/google/protobuf/any_pb.js');
goog.object.extend(proto, google_protobuf_any_pb);
var google_protobuf_empty_pb = require('google-protobuf/google/protobuf/empty_pb.js');
goog.object.extend(proto, google_protobuf_empty_pb);
var google_protobuf_field_mask_pb = require('google-protobuf/google/protobuf/field_mask_pb.js');
goog.object.extend(proto, google_protobuf_field_mask_pb);
var google_protobuf_timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb.js');
goog.object.extend(proto, google_protobuf_timestamp_pb);
goog.exportSymbol('proto.interface.ti.users.v1.AuthorizeConnectorMetadata', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.AuthorizeConnectorRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.AuthorizeConnectorResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchCreateConnectorsRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchCreateConnectorsResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchDeleteConnectorsRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchDeleteConnectorsResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchDeleteUsersRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchDeleteUsersResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchGetConnectorsRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchGetConnectorsResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchGetUsersRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchGetUsersResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchUpdateConnectorsRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.BatchUpdateConnectorsResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.Connector', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.ConnectorView', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.CreateConnectorRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.CreateUserRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.CredentialState', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.DeleteConnectorRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.DeleteUserRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.EditMyInfoRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.EditMyMetadataRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.EditUserInfoRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.EditUserMetadataRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.FetchAccessTokenRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.FetchAccessTokenResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.GetConnectorRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.GetUserRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.IdentityProvider', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.ListConnectorsRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.ListConnectorsResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.ConnectorStatus', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.ListUsersRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.ListUsersResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.LookupUserRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.LookupUserResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.LookupUserResponse.Result', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.MaskedUser', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.Profile', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.RemoveMyUserRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.ReputationCredential', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.RetrieveMaskedUserRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.RetrieveMaskedUserRequest.IdentifierCase', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.RetrieveMaskedUsersRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.RetrieveMaskedUsersResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.RetrieveMyUserRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.RetrieveUserByEmailRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.RevokeConnectorRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.RevokeConnectorResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.SetUserPictureRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.SetUserPictureResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.StreamConnectorsRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.StreamUsersRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.SyncToGoogleGroupRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.SyncToGoogleGroupResponse', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.UndeleteConnectorRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.UndeleteUserRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.UpdateConnectorRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.UpdateUserRequest', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.User', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.User.Account', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.User.Account.Seat', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.User.AppleIdentity', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.User.GoogleIdentity', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.User.LinkedinIdentity', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.User.MicrosoftIdentity', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.UserView', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.XPCredential', null, global);
goog.exportSymbol('proto.interface.ti.users.v1.XPToken', null, global);
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.User = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.User.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.User, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.User.displayName = 'proto.interface.ti.users.v1.User';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.User.GoogleIdentity = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.User.GoogleIdentity, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.User.GoogleIdentity.displayName = 'proto.interface.ti.users.v1.User.GoogleIdentity';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.User.MicrosoftIdentity = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.User.MicrosoftIdentity, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.User.MicrosoftIdentity.displayName = 'proto.interface.ti.users.v1.User.MicrosoftIdentity';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.User.LinkedinIdentity = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.User.LinkedinIdentity, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.User.LinkedinIdentity.displayName = 'proto.interface.ti.users.v1.User.LinkedinIdentity';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.User.AppleIdentity = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.User.AppleIdentity, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.User.AppleIdentity.displayName = 'proto.interface.ti.users.v1.User.AppleIdentity';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.User.Account = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.User.Account, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.User.Account.displayName = 'proto.interface.ti.users.v1.User.Account';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.User.Account.Seat = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.User.Account.Seat, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.User.Account.Seat.displayName = 'proto.interface.ti.users.v1.User.Account.Seat';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.Profile = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.Profile.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.Profile, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.Profile.displayName = 'proto.interface.ti.users.v1.Profile';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.XPCredential = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.XPCredential, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.XPCredential.displayName = 'proto.interface.ti.users.v1.XPCredential';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.ReputationCredential = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.ReputationCredential, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.ReputationCredential.displayName = 'proto.interface.ti.users.v1.ReputationCredential';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.XPToken = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.XPToken, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.XPToken.displayName = 'proto.interface.ti.users.v1.XPToken';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.Connector = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.Connector, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.Connector.displayName = 'proto.interface.ti.users.v1.Connector';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.CreateUserRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.CreateUserRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.CreateUserRequest.displayName = 'proto.interface.ti.users.v1.CreateUserRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.GetUserRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.GetUserRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.GetUserRequest.displayName = 'proto.interface.ti.users.v1.GetUserRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.UpdateUserRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.UpdateUserRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.UpdateUserRequest.displayName = 'proto.interface.ti.users.v1.UpdateUserRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.DeleteUserRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.DeleteUserRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.DeleteUserRequest.displayName = 'proto.interface.ti.users.v1.DeleteUserRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.UndeleteUserRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.UndeleteUserRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.UndeleteUserRequest.displayName = 'proto.interface.ti.users.v1.UndeleteUserRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.ListUsersRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.ListUsersRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.ListUsersRequest.displayName = 'proto.interface.ti.users.v1.ListUsersRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.ListUsersResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.ListUsersResponse.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.ListUsersResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.ListUsersResponse.displayName = 'proto.interface.ti.users.v1.ListUsersResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchGetUsersRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchGetUsersRequest.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchGetUsersRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchGetUsersRequest.displayName = 'proto.interface.ti.users.v1.BatchGetUsersRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchGetUsersResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchGetUsersResponse.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchGetUsersResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchGetUsersResponse.displayName = 'proto.interface.ti.users.v1.BatchGetUsersResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchDeleteUsersRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchDeleteUsersRequest.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchDeleteUsersRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchDeleteUsersRequest.displayName = 'proto.interface.ti.users.v1.BatchDeleteUsersRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchDeleteUsersResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchDeleteUsersResponse.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchDeleteUsersResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchDeleteUsersResponse.displayName = 'proto.interface.ti.users.v1.BatchDeleteUsersResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.StreamUsersRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.StreamUsersRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.StreamUsersRequest.displayName = 'proto.interface.ti.users.v1.StreamUsersRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.RetrieveUserByEmailRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.RetrieveUserByEmailRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.RetrieveUserByEmailRequest.displayName = 'proto.interface.ti.users.v1.RetrieveUserByEmailRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.displayName = 'proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.displayName = 'proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.LookupUserRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.LookupUserRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.LookupUserRequest.displayName = 'proto.interface.ti.users.v1.LookupUserRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.LookupUserResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.LookupUserResponse.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.LookupUserResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.LookupUserResponse.displayName = 'proto.interface.ti.users.v1.LookupUserResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.LookupUserResponse.Result = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.LookupUserResponse.Result, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.LookupUserResponse.Result.displayName = 'proto.interface.ti.users.v1.LookupUserResponse.Result';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.RetrieveMaskedUsersRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.displayName = 'proto.interface.ti.users.v1.RetrieveMaskedUsersRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.RetrieveMaskedUsersResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.displayName = 'proto.interface.ti.users.v1.RetrieveMaskedUsersResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, proto.interface.ti.users.v1.RetrieveMaskedUserRequest.oneofGroups_);
};
goog.inherits(proto.interface.ti.users.v1.RetrieveMaskedUserRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.RetrieveMaskedUserRequest.displayName = 'proto.interface.ti.users.v1.RetrieveMaskedUserRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.MaskedUser = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.MaskedUser, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.MaskedUser.displayName = 'proto.interface.ti.users.v1.MaskedUser';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.EditUserInfoRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.EditUserInfoRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.EditUserInfoRequest.displayName = 'proto.interface.ti.users.v1.EditUserInfoRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.EditUserMetadataRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.EditUserMetadataRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.EditUserMetadataRequest.displayName = 'proto.interface.ti.users.v1.EditUserMetadataRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.RetrieveMyUserRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.RetrieveMyUserRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.RetrieveMyUserRequest.displayName = 'proto.interface.ti.users.v1.RetrieveMyUserRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.EditMyInfoRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.EditMyInfoRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.EditMyInfoRequest.displayName = 'proto.interface.ti.users.v1.EditMyInfoRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.EditMyMetadataRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.EditMyMetadataRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.EditMyMetadataRequest.displayName = 'proto.interface.ti.users.v1.EditMyMetadataRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.RemoveMyUserRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.RemoveMyUserRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.RemoveMyUserRequest.displayName = 'proto.interface.ti.users.v1.RemoveMyUserRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.SyncToGoogleGroupRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.SyncToGoogleGroupRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.SyncToGoogleGroupRequest.displayName = 'proto.interface.ti.users.v1.SyncToGoogleGroupRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.SyncToGoogleGroupResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.SyncToGoogleGroupResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.SyncToGoogleGroupResponse.displayName = 'proto.interface.ti.users.v1.SyncToGoogleGroupResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.SetUserPictureRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.SetUserPictureRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.SetUserPictureRequest.displayName = 'proto.interface.ti.users.v1.SetUserPictureRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.SetUserPictureResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.SetUserPictureResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.SetUserPictureResponse.displayName = 'proto.interface.ti.users.v1.SetUserPictureResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.CreateConnectorRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.CreateConnectorRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.CreateConnectorRequest.displayName = 'proto.interface.ti.users.v1.CreateConnectorRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.GetConnectorRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.GetConnectorRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.GetConnectorRequest.displayName = 'proto.interface.ti.users.v1.GetConnectorRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.UpdateConnectorRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.UpdateConnectorRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.UpdateConnectorRequest.displayName = 'proto.interface.ti.users.v1.UpdateConnectorRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.DeleteConnectorRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.DeleteConnectorRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.DeleteConnectorRequest.displayName = 'proto.interface.ti.users.v1.DeleteConnectorRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.UndeleteConnectorRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.UndeleteConnectorRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.UndeleteConnectorRequest.displayName = 'proto.interface.ti.users.v1.UndeleteConnectorRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.ListConnectorsRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.ListConnectorsRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.ListConnectorsRequest.displayName = 'proto.interface.ti.users.v1.ListConnectorsRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.ListConnectorsResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.ListConnectorsResponse.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.ListConnectorsResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.ListConnectorsResponse.displayName = 'proto.interface.ti.users.v1.ListConnectorsResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchCreateConnectorsRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchCreateConnectorsRequest.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchCreateConnectorsRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchCreateConnectorsRequest.displayName = 'proto.interface.ti.users.v1.BatchCreateConnectorsRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchCreateConnectorsResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchCreateConnectorsResponse.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchCreateConnectorsResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchCreateConnectorsResponse.displayName = 'proto.interface.ti.users.v1.BatchCreateConnectorsResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchGetConnectorsRequest.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchGetConnectorsRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchGetConnectorsRequest.displayName = 'proto.interface.ti.users.v1.BatchGetConnectorsRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchGetConnectorsResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchGetConnectorsResponse.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchGetConnectorsResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchGetConnectorsResponse.displayName = 'proto.interface.ti.users.v1.BatchGetConnectorsResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchUpdateConnectorsRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.displayName = 'proto.interface.ti.users.v1.BatchUpdateConnectorsRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchUpdateConnectorsResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.displayName = 'proto.interface.ti.users.v1.BatchUpdateConnectorsResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchDeleteConnectorsRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.displayName = 'proto.interface.ti.users.v1.BatchDeleteConnectorsRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchDeleteConnectorsResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.displayName = 'proto.interface.ti.users.v1.BatchDeleteConnectorsResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.displayName = 'proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.displayName = 'proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.StreamConnectorsRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.StreamConnectorsRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.StreamConnectorsRequest.displayName = 'proto.interface.ti.users.v1.StreamConnectorsRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.FetchAccessTokenRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.FetchAccessTokenRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.FetchAccessTokenRequest.displayName = 'proto.interface.ti.users.v1.FetchAccessTokenRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.FetchAccessTokenResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.FetchAccessTokenResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.FetchAccessTokenResponse.displayName = 'proto.interface.ti.users.v1.FetchAccessTokenResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.AuthorizeConnectorRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.AuthorizeConnectorRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.AuthorizeConnectorRequest.displayName = 'proto.interface.ti.users.v1.AuthorizeConnectorRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.AuthorizeConnectorMetadata = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.AuthorizeConnectorMetadata, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.AuthorizeConnectorMetadata.displayName = 'proto.interface.ti.users.v1.AuthorizeConnectorMetadata';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.AuthorizeConnectorResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.AuthorizeConnectorResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.AuthorizeConnectorResponse.displayName = 'proto.interface.ti.users.v1.AuthorizeConnectorResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.RevokeConnectorRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.RevokeConnectorRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.RevokeConnectorRequest.displayName = 'proto.interface.ti.users.v1.RevokeConnectorRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.RevokeConnectorResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.RevokeConnectorResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.RevokeConnectorResponse.displayName = 'proto.interface.ti.users.v1.RevokeConnectorResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest.displayName = 'proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.repeatedFields_, null);
};
goog.inherits(proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.displayName = 'proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse';
}
/**
 * Generated by JsPbCodeGenerator.
 * @param {Array=} opt_data Optional initial data array, typically from a
 * server response, or constructed directly in Javascript. The array is used
 * in place and becomes part of the constructed object. It is not cloned.
 * If no data is provided, the constructed object will be empty, but still
 * valid.
 * @extends {jspb.Message}
 * @constructor
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.displayName = 'proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary';
}

/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.User.repeatedFields_ = [23];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.User.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.User.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.User} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.toObject = function(includeInstance, msg) {
  var f, obj = {
name: jspb.Message.getFieldWithDefault(msg, 1, ""),
email: jspb.Message.getFieldWithDefault(msg, 4, ""),
givenName: jspb.Message.getFieldWithDefault(msg, 7, ""),
familyName: jspb.Message.getFieldWithDefault(msg, 8, ""),
picture: jspb.Message.getFieldWithDefault(msg, 9, ""),
contactNumber: jspb.Message.getFieldWithDefault(msg, 10, ""),
position: jspb.Message.getFieldWithDefault(msg, 13, ""),
education: jspb.Message.getFieldWithDefault(msg, 14, ""),
linkedinUri: jspb.Message.getFieldWithDefault(msg, 15, ""),
verifiedEmail: jspb.Message.getBooleanFieldWithDefault(msg, 5, false),
identityProvider: jspb.Message.getFieldWithDefault(msg, 6, 0),
googleGroup: jspb.Message.getFieldWithDefault(msg, 12, ""),
metadata: (f = msg.getMetadata()) && google_protobuf_any_pb.Any.toObject(includeInstance, f),
internalMetadata: (f = msg.getInternalMetadata()) && google_protobuf_any_pb.Any.toObject(includeInstance, f),
createTime: (f = msg.getCreateTime()) && google_protobuf_timestamp_pb.Timestamp.toObject(includeInstance, f),
updateTime: (f = msg.getUpdateTime()) && google_protobuf_timestamp_pb.Timestamp.toObject(includeInstance, f),
lastSignInTime: (f = msg.getLastSignInTime()) && google_protobuf_timestamp_pb.Timestamp.toObject(includeInstance, f),
lastRefreshTime: (f = msg.getLastRefreshTime()) && google_protobuf_timestamp_pb.Timestamp.toObject(includeInstance, f),
googleIdentity: (f = msg.getGoogleIdentity()) && proto.interface.ti.users.v1.User.GoogleIdentity.toObject(includeInstance, f),
microsoftIdentity: (f = msg.getMicrosoftIdentity()) && proto.interface.ti.users.v1.User.MicrosoftIdentity.toObject(includeInstance, f),
linkedinIdentity: (f = msg.getLinkedinIdentity()) && proto.interface.ti.users.v1.User.LinkedinIdentity.toObject(includeInstance, f),
groupIdsList: (f = jspb.Message.getRepeatedField(msg, 23)) == null ? undefined : f,
appleIdentity: (f = msg.getAppleIdentity()) && proto.interface.ti.users.v1.User.AppleIdentity.toObject(includeInstance, f),
hederaAccountAddress: jspb.Message.getFieldWithDefault(msg, 25, ""),
publicKey: jspb.Message.getFieldWithDefault(msg, 27, ""),
privateKey: jspb.Message.getFieldWithDefault(msg, 28, ""),
profile: (f = msg.getProfile()) && proto.interface.ti.users.v1.Profile.toObject(includeInstance, f),
accountsMap: (f = msg.getAccountsMap()) ? f.toObject(includeInstance, proto.interface.ti.users.v1.User.Account.toObject) : [],
etag: jspb.Message.getFieldWithDefault(msg, 90, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.User}
 */
proto.interface.ti.users.v1.User.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.User;
  return proto.interface.ti.users.v1.User.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.User} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.User}
 */
proto.interface.ti.users.v1.User.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setName(value);
      break;
    case 4:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setEmail(value);
      break;
    case 7:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setGivenName(value);
      break;
    case 8:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setFamilyName(value);
      break;
    case 9:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPicture(value);
      break;
    case 10:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setContactNumber(value);
      break;
    case 13:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPosition(value);
      break;
    case 14:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setEducation(value);
      break;
    case 15:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setLinkedinUri(value);
      break;
    case 5:
      var value = /** @type {boolean} */ (reader.readBool());
      msg.setVerifiedEmail(value);
      break;
    case 6:
      var value = /** @type {!proto.interface.ti.users.v1.IdentityProvider} */ (reader.readEnum());
      msg.setIdentityProvider(value);
      break;
    case 12:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setGoogleGroup(value);
      break;
    case 11:
      var value = new google_protobuf_any_pb.Any;
      reader.readMessage(value,google_protobuf_any_pb.Any.deserializeBinaryFromReader);
      msg.setMetadata(value);
      break;
    case 19:
      var value = new google_protobuf_any_pb.Any;
      reader.readMessage(value,google_protobuf_any_pb.Any.deserializeBinaryFromReader);
      msg.setInternalMetadata(value);
      break;
    case 2:
      var value = new google_protobuf_timestamp_pb.Timestamp;
      reader.readMessage(value,google_protobuf_timestamp_pb.Timestamp.deserializeBinaryFromReader);
      msg.setCreateTime(value);
      break;
    case 3:
      var value = new google_protobuf_timestamp_pb.Timestamp;
      reader.readMessage(value,google_protobuf_timestamp_pb.Timestamp.deserializeBinaryFromReader);
      msg.setUpdateTime(value);
      break;
    case 16:
      var value = new google_protobuf_timestamp_pb.Timestamp;
      reader.readMessage(value,google_protobuf_timestamp_pb.Timestamp.deserializeBinaryFromReader);
      msg.setLastSignInTime(value);
      break;
    case 20:
      var value = new google_protobuf_timestamp_pb.Timestamp;
      reader.readMessage(value,google_protobuf_timestamp_pb.Timestamp.deserializeBinaryFromReader);
      msg.setLastRefreshTime(value);
      break;
    case 17:
      var value = new proto.interface.ti.users.v1.User.GoogleIdentity;
      reader.readMessage(value,proto.interface.ti.users.v1.User.GoogleIdentity.deserializeBinaryFromReader);
      msg.setGoogleIdentity(value);
      break;
    case 18:
      var value = new proto.interface.ti.users.v1.User.MicrosoftIdentity;
      reader.readMessage(value,proto.interface.ti.users.v1.User.MicrosoftIdentity.deserializeBinaryFromReader);
      msg.setMicrosoftIdentity(value);
      break;
    case 21:
      var value = new proto.interface.ti.users.v1.User.LinkedinIdentity;
      reader.readMessage(value,proto.interface.ti.users.v1.User.LinkedinIdentity.deserializeBinaryFromReader);
      msg.setLinkedinIdentity(value);
      break;
    case 23:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.addGroupIds(value);
      break;
    case 24:
      var value = new proto.interface.ti.users.v1.User.AppleIdentity;
      reader.readMessage(value,proto.interface.ti.users.v1.User.AppleIdentity.deserializeBinaryFromReader);
      msg.setAppleIdentity(value);
      break;
    case 25:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setHederaAccountAddress(value);
      break;
    case 27:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPublicKey(value);
      break;
    case 28:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPrivateKey(value);
      break;
    case 26:
      var value = new proto.interface.ti.users.v1.Profile;
      reader.readMessage(value,proto.interface.ti.users.v1.Profile.deserializeBinaryFromReader);
      msg.setProfile(value);
      break;
    case 99:
      var value = msg.getAccountsMap();
      reader.readMessage(value, function(message, reader) {
        jspb.Map.deserializeBinary(message, reader, jspb.BinaryReader.prototype.readStringRequireUtf8, jspb.BinaryReader.prototype.readMessage, proto.interface.ti.users.v1.User.Account.deserializeBinaryFromReader, "", new proto.interface.ti.users.v1.User.Account());
         });
      break;
    case 90:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setEtag(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.User.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.User.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.User} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getName();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getEmail();
  if (f.length > 0) {
    writer.writeString(
      4,
      f
    );
  }
  f = message.getGivenName();
  if (f.length > 0) {
    writer.writeString(
      7,
      f
    );
  }
  f = message.getFamilyName();
  if (f.length > 0) {
    writer.writeString(
      8,
      f
    );
  }
  f = message.getPicture();
  if (f.length > 0) {
    writer.writeString(
      9,
      f
    );
  }
  f = message.getContactNumber();
  if (f.length > 0) {
    writer.writeString(
      10,
      f
    );
  }
  f = message.getPosition();
  if (f.length > 0) {
    writer.writeString(
      13,
      f
    );
  }
  f = message.getEducation();
  if (f.length > 0) {
    writer.writeString(
      14,
      f
    );
  }
  f = message.getLinkedinUri();
  if (f.length > 0) {
    writer.writeString(
      15,
      f
    );
  }
  f = message.getVerifiedEmail();
  if (f) {
    writer.writeBool(
      5,
      f
    );
  }
  f = message.getIdentityProvider();
  if (f !== 0.0) {
    writer.writeEnum(
      6,
      f
    );
  }
  f = message.getGoogleGroup();
  if (f.length > 0) {
    writer.writeString(
      12,
      f
    );
  }
  f = message.getMetadata();
  if (f != null) {
    writer.writeMessage(
      11,
      f,
      google_protobuf_any_pb.Any.serializeBinaryToWriter
    );
  }
  f = message.getInternalMetadata();
  if (f != null) {
    writer.writeMessage(
      19,
      f,
      google_protobuf_any_pb.Any.serializeBinaryToWriter
    );
  }
  f = message.getCreateTime();
  if (f != null) {
    writer.writeMessage(
      2,
      f,
      google_protobuf_timestamp_pb.Timestamp.serializeBinaryToWriter
    );
  }
  f = message.getUpdateTime();
  if (f != null) {
    writer.writeMessage(
      3,
      f,
      google_protobuf_timestamp_pb.Timestamp.serializeBinaryToWriter
    );
  }
  f = message.getLastSignInTime();
  if (f != null) {
    writer.writeMessage(
      16,
      f,
      google_protobuf_timestamp_pb.Timestamp.serializeBinaryToWriter
    );
  }
  f = message.getLastRefreshTime();
  if (f != null) {
    writer.writeMessage(
      20,
      f,
      google_protobuf_timestamp_pb.Timestamp.serializeBinaryToWriter
    );
  }
  f = message.getGoogleIdentity();
  if (f != null) {
    writer.writeMessage(
      17,
      f,
      proto.interface.ti.users.v1.User.GoogleIdentity.serializeBinaryToWriter
    );
  }
  f = message.getMicrosoftIdentity();
  if (f != null) {
    writer.writeMessage(
      18,
      f,
      proto.interface.ti.users.v1.User.MicrosoftIdentity.serializeBinaryToWriter
    );
  }
  f = message.getLinkedinIdentity();
  if (f != null) {
    writer.writeMessage(
      21,
      f,
      proto.interface.ti.users.v1.User.LinkedinIdentity.serializeBinaryToWriter
    );
  }
  f = message.getGroupIdsList();
  if (f.length > 0) {
    writer.writeRepeatedString(
      23,
      f
    );
  }
  f = message.getAppleIdentity();
  if (f != null) {
    writer.writeMessage(
      24,
      f,
      proto.interface.ti.users.v1.User.AppleIdentity.serializeBinaryToWriter
    );
  }
  f = message.getHederaAccountAddress();
  if (f.length > 0) {
    writer.writeString(
      25,
      f
    );
  }
  f = message.getPublicKey();
  if (f.length > 0) {
    writer.writeString(
      27,
      f
    );
  }
  f = message.getPrivateKey();
  if (f.length > 0) {
    writer.writeString(
      28,
      f
    );
  }
  f = message.getProfile();
  if (f != null) {
    writer.writeMessage(
      26,
      f,
      proto.interface.ti.users.v1.Profile.serializeBinaryToWriter
    );
  }
  f = message.getAccountsMap(true);
  if (f && f.getLength() > 0) {
jspb.internal.public_for_gencode.serializeMapToBinary(
    message.getAccountsMap(true),
    99,
    writer,
    jspb.BinaryWriter.prototype.writeString,
    jspb.BinaryWriter.prototype.writeMessage,
    proto.interface.ti.users.v1.User.Account.serializeBinaryToWriter);
  }
  f = message.getEtag();
  if (f.length > 0) {
    writer.writeString(
      90,
      f
    );
  }
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.User.GoogleIdentity.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.User.GoogleIdentity.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.User.GoogleIdentity} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.GoogleIdentity.toObject = function(includeInstance, msg) {
  var f, obj = {
id: jspb.Message.getFieldWithDefault(msg, 1, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.User.GoogleIdentity}
 */
proto.interface.ti.users.v1.User.GoogleIdentity.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.User.GoogleIdentity;
  return proto.interface.ti.users.v1.User.GoogleIdentity.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.User.GoogleIdentity} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.User.GoogleIdentity}
 */
proto.interface.ti.users.v1.User.GoogleIdentity.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setId(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.User.GoogleIdentity.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.User.GoogleIdentity.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.User.GoogleIdentity} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.GoogleIdentity.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getId();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
};


/**
 * optional string id = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.User.GoogleIdentity.prototype.getId = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User.GoogleIdentity} returns this
 */
proto.interface.ti.users.v1.User.GoogleIdentity.prototype.setId = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.User.MicrosoftIdentity.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.User.MicrosoftIdentity.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.User.MicrosoftIdentity} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.MicrosoftIdentity.toObject = function(includeInstance, msg) {
  var f, obj = {
id: jspb.Message.getFieldWithDefault(msg, 1, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.User.MicrosoftIdentity}
 */
proto.interface.ti.users.v1.User.MicrosoftIdentity.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.User.MicrosoftIdentity;
  return proto.interface.ti.users.v1.User.MicrosoftIdentity.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.User.MicrosoftIdentity} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.User.MicrosoftIdentity}
 */
proto.interface.ti.users.v1.User.MicrosoftIdentity.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setId(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.User.MicrosoftIdentity.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.User.MicrosoftIdentity.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.User.MicrosoftIdentity} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.MicrosoftIdentity.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getId();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
};


/**
 * optional string id = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.User.MicrosoftIdentity.prototype.getId = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User.MicrosoftIdentity} returns this
 */
proto.interface.ti.users.v1.User.MicrosoftIdentity.prototype.setId = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.User.LinkedinIdentity.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.User.LinkedinIdentity.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.User.LinkedinIdentity} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.LinkedinIdentity.toObject = function(includeInstance, msg) {
  var f, obj = {
id: jspb.Message.getFieldWithDefault(msg, 1, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.User.LinkedinIdentity}
 */
proto.interface.ti.users.v1.User.LinkedinIdentity.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.User.LinkedinIdentity;
  return proto.interface.ti.users.v1.User.LinkedinIdentity.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.User.LinkedinIdentity} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.User.LinkedinIdentity}
 */
proto.interface.ti.users.v1.User.LinkedinIdentity.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setId(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.User.LinkedinIdentity.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.User.LinkedinIdentity.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.User.LinkedinIdentity} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.LinkedinIdentity.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getId();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
};


/**
 * optional string id = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.User.LinkedinIdentity.prototype.getId = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User.LinkedinIdentity} returns this
 */
proto.interface.ti.users.v1.User.LinkedinIdentity.prototype.setId = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.User.AppleIdentity.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.User.AppleIdentity.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.User.AppleIdentity} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.AppleIdentity.toObject = function(includeInstance, msg) {
  var f, obj = {
id: jspb.Message.getFieldWithDefault(msg, 1, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.User.AppleIdentity}
 */
proto.interface.ti.users.v1.User.AppleIdentity.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.User.AppleIdentity;
  return proto.interface.ti.users.v1.User.AppleIdentity.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.User.AppleIdentity} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.User.AppleIdentity}
 */
proto.interface.ti.users.v1.User.AppleIdentity.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setId(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.User.AppleIdentity.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.User.AppleIdentity.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.User.AppleIdentity} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.AppleIdentity.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getId();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
};


/**
 * optional string id = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.User.AppleIdentity.prototype.getId = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User.AppleIdentity} returns this
 */
proto.interface.ti.users.v1.User.AppleIdentity.prototype.setId = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.User.Account.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.User.Account.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.User.Account} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.Account.toObject = function(includeInstance, msg) {
  var f, obj = {
seatsMap: (f = msg.getSeatsMap()) ? f.toObject(includeInstance, proto.interface.ti.users.v1.User.Account.Seat.toObject) : []
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.User.Account}
 */
proto.interface.ti.users.v1.User.Account.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.User.Account;
  return proto.interface.ti.users.v1.User.Account.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.User.Account} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.User.Account}
 */
proto.interface.ti.users.v1.User.Account.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = msg.getSeatsMap();
      reader.readMessage(value, function(message, reader) {
        jspb.Map.deserializeBinary(message, reader, jspb.BinaryReader.prototype.readInt32, jspb.BinaryReader.prototype.readMessage, proto.interface.ti.users.v1.User.Account.Seat.deserializeBinaryFromReader, 0, new proto.interface.ti.users.v1.User.Account.Seat());
         });
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.User.Account.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.User.Account.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.User.Account} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.Account.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getSeatsMap(true);
  if (f && f.getLength() > 0) {
jspb.internal.public_for_gencode.serializeMapToBinary(
    message.getSeatsMap(true),
    1,
    writer,
    jspb.BinaryWriter.prototype.writeInt32,
    jspb.BinaryWriter.prototype.writeMessage,
    proto.interface.ti.users.v1.User.Account.Seat.serializeBinaryToWriter);
  }
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.User.Account.Seat.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.User.Account.Seat.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.User.Account.Seat} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.Account.Seat.toObject = function(includeInstance, msg) {
  var f, obj = {
plan: jspb.Message.getFieldWithDefault(msg, 1, 0),
seat: jspb.Message.getFieldWithDefault(msg, 2, 0)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.User.Account.Seat}
 */
proto.interface.ti.users.v1.User.Account.Seat.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.User.Account.Seat;
  return proto.interface.ti.users.v1.User.Account.Seat.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.User.Account.Seat} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.User.Account.Seat}
 */
proto.interface.ti.users.v1.User.Account.Seat.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {number} */ (reader.readInt32());
      msg.setPlan(value);
      break;
    case 2:
      var value = /** @type {number} */ (reader.readInt32());
      msg.setSeat(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.User.Account.Seat.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.User.Account.Seat.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.User.Account.Seat} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.User.Account.Seat.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getPlan();
  if (f !== 0) {
    writer.writeInt32(
      1,
      f
    );
  }
  f = message.getSeat();
  if (f !== 0) {
    writer.writeInt32(
      2,
      f
    );
  }
};


/**
 * optional int32 plan = 1;
 * @return {number}
 */
proto.interface.ti.users.v1.User.Account.Seat.prototype.getPlan = function() {
  return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};


/**
 * @param {number} value
 * @return {!proto.interface.ti.users.v1.User.Account.Seat} returns this
 */
proto.interface.ti.users.v1.User.Account.Seat.prototype.setPlan = function(value) {
  return jspb.Message.setProto3IntField(this, 1, value);
};


/**
 * optional int32 seat = 2;
 * @return {number}
 */
proto.interface.ti.users.v1.User.Account.Seat.prototype.getSeat = function() {
  return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};


/**
 * @param {number} value
 * @return {!proto.interface.ti.users.v1.User.Account.Seat} returns this
 */
proto.interface.ti.users.v1.User.Account.Seat.prototype.setSeat = function(value) {
  return jspb.Message.setProto3IntField(this, 2, value);
};


/**
 * map<int32, Seat> seats = 1;
 * @param {boolean=} opt_noLazyCreate Do not create the map if
 * empty, instead returning `undefined`
 * @return {!jspb.Map<number,!proto.interface.ti.users.v1.User.Account.Seat>}
 */
proto.interface.ti.users.v1.User.Account.prototype.getSeatsMap = function(opt_noLazyCreate) {
  return /** @type {!jspb.Map<number,!proto.interface.ti.users.v1.User.Account.Seat>} */ (
      jspb.Message.getMapField(this, 1, opt_noLazyCreate,
      proto.interface.ti.users.v1.User.Account.Seat));
};


/**
 * Clears values from the map. The map will be non-null.
 * @return {!proto.interface.ti.users.v1.User.Account} returns this
 */
proto.interface.ti.users.v1.User.Account.prototype.clearSeatsMap = function() {
  this.getSeatsMap().clear();
  return this;
};


/**
 * optional string name = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setName = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional string email = 4;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getEmail = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setEmail = function(value) {
  return jspb.Message.setProto3StringField(this, 4, value);
};


/**
 * optional string given_name = 7;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getGivenName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 7, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setGivenName = function(value) {
  return jspb.Message.setProto3StringField(this, 7, value);
};


/**
 * optional string family_name = 8;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getFamilyName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 8, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setFamilyName = function(value) {
  return jspb.Message.setProto3StringField(this, 8, value);
};


/**
 * optional string picture = 9;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getPicture = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 9, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setPicture = function(value) {
  return jspb.Message.setProto3StringField(this, 9, value);
};


/**
 * optional string contact_number = 10;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getContactNumber = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 10, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setContactNumber = function(value) {
  return jspb.Message.setProto3StringField(this, 10, value);
};


/**
 * optional string position = 13;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getPosition = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 13, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setPosition = function(value) {
  return jspb.Message.setProto3StringField(this, 13, value);
};


/**
 * optional string education = 14;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getEducation = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 14, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setEducation = function(value) {
  return jspb.Message.setProto3StringField(this, 14, value);
};


/**
 * optional string linkedin_uri = 15;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getLinkedinUri = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 15, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setLinkedinUri = function(value) {
  return jspb.Message.setProto3StringField(this, 15, value);
};


/**
 * optional bool verified_email = 5;
 * @return {boolean}
 */
proto.interface.ti.users.v1.User.prototype.getVerifiedEmail = function() {
  return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 5, false));
};


/**
 * @param {boolean} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setVerifiedEmail = function(value) {
  return jspb.Message.setProto3BooleanField(this, 5, value);
};


/**
 * optional IdentityProvider identity_provider = 6;
 * @return {!proto.interface.ti.users.v1.IdentityProvider}
 */
proto.interface.ti.users.v1.User.prototype.getIdentityProvider = function() {
  return /** @type {!proto.interface.ti.users.v1.IdentityProvider} */ (jspb.Message.getFieldWithDefault(this, 6, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.IdentityProvider} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setIdentityProvider = function(value) {
  return jspb.Message.setProto3EnumField(this, 6, value);
};


/**
 * optional string google_group = 12;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getGoogleGroup = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 12, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setGoogleGroup = function(value) {
  return jspb.Message.setProto3StringField(this, 12, value);
};


/**
 * optional google.protobuf.Any metadata = 11;
 * @return {?proto.google.protobuf.Any}
 */
proto.interface.ti.users.v1.User.prototype.getMetadata = function() {
  return /** @type{?proto.google.protobuf.Any} */ (
    jspb.Message.getWrapperField(this, google_protobuf_any_pb.Any, 11));
};


/**
 * @param {?proto.google.protobuf.Any|undefined} value
 * @return {!proto.interface.ti.users.v1.User} returns this
*/
proto.interface.ti.users.v1.User.prototype.setMetadata = function(value) {
  return jspb.Message.setWrapperField(this, 11, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.clearMetadata = function() {
  return this.setMetadata(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.User.prototype.hasMetadata = function() {
  return jspb.Message.getField(this, 11) != null;
};


/**
 * optional google.protobuf.Any internal_metadata = 19;
 * @return {?proto.google.protobuf.Any}
 */
proto.interface.ti.users.v1.User.prototype.getInternalMetadata = function() {
  return /** @type{?proto.google.protobuf.Any} */ (
    jspb.Message.getWrapperField(this, google_protobuf_any_pb.Any, 19));
};


/**
 * @param {?proto.google.protobuf.Any|undefined} value
 * @return {!proto.interface.ti.users.v1.User} returns this
*/
proto.interface.ti.users.v1.User.prototype.setInternalMetadata = function(value) {
  return jspb.Message.setWrapperField(this, 19, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.clearInternalMetadata = function() {
  return this.setInternalMetadata(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.User.prototype.hasInternalMetadata = function() {
  return jspb.Message.getField(this, 19) != null;
};


/**
 * optional google.protobuf.Timestamp create_time = 2;
 * @return {?proto.google.protobuf.Timestamp}
 */
proto.interface.ti.users.v1.User.prototype.getCreateTime = function() {
  return /** @type{?proto.google.protobuf.Timestamp} */ (
    jspb.Message.getWrapperField(this, google_protobuf_timestamp_pb.Timestamp, 2));
};


/**
 * @param {?proto.google.protobuf.Timestamp|undefined} value
 * @return {!proto.interface.ti.users.v1.User} returns this
*/
proto.interface.ti.users.v1.User.prototype.setCreateTime = function(value) {
  return jspb.Message.setWrapperField(this, 2, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.clearCreateTime = function() {
  return this.setCreateTime(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.User.prototype.hasCreateTime = function() {
  return jspb.Message.getField(this, 2) != null;
};


/**
 * optional google.protobuf.Timestamp update_time = 3;
 * @return {?proto.google.protobuf.Timestamp}
 */
proto.interface.ti.users.v1.User.prototype.getUpdateTime = function() {
  return /** @type{?proto.google.protobuf.Timestamp} */ (
    jspb.Message.getWrapperField(this, google_protobuf_timestamp_pb.Timestamp, 3));
};


/**
 * @param {?proto.google.protobuf.Timestamp|undefined} value
 * @return {!proto.interface.ti.users.v1.User} returns this
*/
proto.interface.ti.users.v1.User.prototype.setUpdateTime = function(value) {
  return jspb.Message.setWrapperField(this, 3, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.clearUpdateTime = function() {
  return this.setUpdateTime(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.User.prototype.hasUpdateTime = function() {
  return jspb.Message.getField(this, 3) != null;
};


/**
 * optional google.protobuf.Timestamp last_sign_in_time = 16;
 * @return {?proto.google.protobuf.Timestamp}
 */
proto.interface.ti.users.v1.User.prototype.getLastSignInTime = function() {
  return /** @type{?proto.google.protobuf.Timestamp} */ (
    jspb.Message.getWrapperField(this, google_protobuf_timestamp_pb.Timestamp, 16));
};


/**
 * @param {?proto.google.protobuf.Timestamp|undefined} value
 * @return {!proto.interface.ti.users.v1.User} returns this
*/
proto.interface.ti.users.v1.User.prototype.setLastSignInTime = function(value) {
  return jspb.Message.setWrapperField(this, 16, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.clearLastSignInTime = function() {
  return this.setLastSignInTime(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.User.prototype.hasLastSignInTime = function() {
  return jspb.Message.getField(this, 16) != null;
};


/**
 * optional google.protobuf.Timestamp last_refresh_time = 20;
 * @return {?proto.google.protobuf.Timestamp}
 */
proto.interface.ti.users.v1.User.prototype.getLastRefreshTime = function() {
  return /** @type{?proto.google.protobuf.Timestamp} */ (
    jspb.Message.getWrapperField(this, google_protobuf_timestamp_pb.Timestamp, 20));
};


/**
 * @param {?proto.google.protobuf.Timestamp|undefined} value
 * @return {!proto.interface.ti.users.v1.User} returns this
*/
proto.interface.ti.users.v1.User.prototype.setLastRefreshTime = function(value) {
  return jspb.Message.setWrapperField(this, 20, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.clearLastRefreshTime = function() {
  return this.setLastRefreshTime(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.User.prototype.hasLastRefreshTime = function() {
  return jspb.Message.getField(this, 20) != null;
};


/**
 * optional GoogleIdentity google_identity = 17;
 * @return {?proto.interface.ti.users.v1.User.GoogleIdentity}
 */
proto.interface.ti.users.v1.User.prototype.getGoogleIdentity = function() {
  return /** @type{?proto.interface.ti.users.v1.User.GoogleIdentity} */ (
    jspb.Message.getWrapperField(this, proto.interface.ti.users.v1.User.GoogleIdentity, 17));
};


/**
 * @param {?proto.interface.ti.users.v1.User.GoogleIdentity|undefined} value
 * @return {!proto.interface.ti.users.v1.User} returns this
*/
proto.interface.ti.users.v1.User.prototype.setGoogleIdentity = function(value) {
  return jspb.Message.setWrapperField(this, 17, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.clearGoogleIdentity = function() {
  return this.setGoogleIdentity(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.User.prototype.hasGoogleIdentity = function() {
  return jspb.Message.getField(this, 17) != null;
};


/**
 * optional MicrosoftIdentity microsoft_identity = 18;
 * @return {?proto.interface.ti.users.v1.User.MicrosoftIdentity}
 */
proto.interface.ti.users.v1.User.prototype.getMicrosoftIdentity = function() {
  return /** @type{?proto.interface.ti.users.v1.User.MicrosoftIdentity} */ (
    jspb.Message.getWrapperField(this, proto.interface.ti.users.v1.User.MicrosoftIdentity, 18));
};


/**
 * @param {?proto.interface.ti.users.v1.User.MicrosoftIdentity|undefined} value
 * @return {!proto.interface.ti.users.v1.User} returns this
*/
proto.interface.ti.users.v1.User.prototype.setMicrosoftIdentity = function(value) {
  return jspb.Message.setWrapperField(this, 18, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.clearMicrosoftIdentity = function() {
  return this.setMicrosoftIdentity(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.User.prototype.hasMicrosoftIdentity = function() {
  return jspb.Message.getField(this, 18) != null;
};


/**
 * optional LinkedinIdentity linkedin_identity = 21;
 * @return {?proto.interface.ti.users.v1.User.LinkedinIdentity}
 */
proto.interface.ti.users.v1.User.prototype.getLinkedinIdentity = function() {
  return /** @type{?proto.interface.ti.users.v1.User.LinkedinIdentity} */ (
    jspb.Message.getWrapperField(this, proto.interface.ti.users.v1.User.LinkedinIdentity, 21));
};


/**
 * @param {?proto.interface.ti.users.v1.User.LinkedinIdentity|undefined} value
 * @return {!proto.interface.ti.users.v1.User} returns this
*/
proto.interface.ti.users.v1.User.prototype.setLinkedinIdentity = function(value) {
  return jspb.Message.setWrapperField(this, 21, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.clearLinkedinIdentity = function() {
  return this.setLinkedinIdentity(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.User.prototype.hasLinkedinIdentity = function() {
  return jspb.Message.getField(this, 21) != null;
};


/**
 * repeated string group_ids = 23;
 * @return {!Array<string>}
 */
proto.interface.ti.users.v1.User.prototype.getGroupIdsList = function() {
  return /** @type {!Array<string>} */ (jspb.Message.getRepeatedField(this, 23));
};


/**
 * @param {!Array<string>} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setGroupIdsList = function(value) {
  return jspb.Message.setField(this, 23, value || []);
};


/**
 * @param {string} value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.addGroupIds = function(value, opt_index) {
  return jspb.Message.addToRepeatedField(this, 23, value, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.clearGroupIdsList = function() {
  return this.setGroupIdsList([]);
};


/**
 * optional AppleIdentity apple_identity = 24;
 * @return {?proto.interface.ti.users.v1.User.AppleIdentity}
 */
proto.interface.ti.users.v1.User.prototype.getAppleIdentity = function() {
  return /** @type{?proto.interface.ti.users.v1.User.AppleIdentity} */ (
    jspb.Message.getWrapperField(this, proto.interface.ti.users.v1.User.AppleIdentity, 24));
};


/**
 * @param {?proto.interface.ti.users.v1.User.AppleIdentity|undefined} value
 * @return {!proto.interface.ti.users.v1.User} returns this
*/
proto.interface.ti.users.v1.User.prototype.setAppleIdentity = function(value) {
  return jspb.Message.setWrapperField(this, 24, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.clearAppleIdentity = function() {
  return this.setAppleIdentity(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.User.prototype.hasAppleIdentity = function() {
  return jspb.Message.getField(this, 24) != null;
};


/**
 * optional string hedera_account_address = 25;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getHederaAccountAddress = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 25, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setHederaAccountAddress = function(value) {
  return jspb.Message.setProto3StringField(this, 25, value);
};


/**
 * optional string public_key = 27;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getPublicKey = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 27, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setPublicKey = function(value) {
  return jspb.Message.setProto3StringField(this, 27, value);
};


/**
 * optional string private_key = 28;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getPrivateKey = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 28, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setPrivateKey = function(value) {
  return jspb.Message.setProto3StringField(this, 28, value);
};


/**
 * optional Profile profile = 26;
 * @return {?proto.interface.ti.users.v1.Profile}
 */
proto.interface.ti.users.v1.User.prototype.getProfile = function() {
  return /** @type{?proto.interface.ti.users.v1.Profile} */ (
    jspb.Message.getWrapperField(this, proto.interface.ti.users.v1.Profile, 26));
};


/**
 * @param {?proto.interface.ti.users.v1.Profile|undefined} value
 * @return {!proto.interface.ti.users.v1.User} returns this
*/
proto.interface.ti.users.v1.User.prototype.setProfile = function(value) {
  return jspb.Message.setWrapperField(this, 26, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.clearProfile = function() {
  return this.setProfile(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.User.prototype.hasProfile = function() {
  return jspb.Message.getField(this, 26) != null;
};


/**
 * map<string, Account> accounts = 99;
 * @param {boolean=} opt_noLazyCreate Do not create the map if
 * empty, instead returning `undefined`
 * @return {!jspb.Map<string,!proto.interface.ti.users.v1.User.Account>}
 */
proto.interface.ti.users.v1.User.prototype.getAccountsMap = function(opt_noLazyCreate) {
  return /** @type {!jspb.Map<string,!proto.interface.ti.users.v1.User.Account>} */ (
      jspb.Message.getMapField(this, 99, opt_noLazyCreate,
      proto.interface.ti.users.v1.User.Account));
};


/**
 * Clears values from the map. The map will be non-null.
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.clearAccountsMap = function() {
  this.getAccountsMap().clear();
  return this;
};


/**
 * optional string etag = 90;
 * @return {string}
 */
proto.interface.ti.users.v1.User.prototype.getEtag = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 90, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.User} returns this
 */
proto.interface.ti.users.v1.User.prototype.setEtag = function(value) {
  return jspb.Message.setProto3StringField(this, 90, value);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.Profile.repeatedFields_ = [1,2,3];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.Profile.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.Profile.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.Profile} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.Profile.toObject = function(includeInstance, msg) {
  var f, obj = {
xpCredentialsList: jspb.Message.toObjectList(msg.getXpCredentialsList(),
    proto.interface.ti.users.v1.XPCredential.toObject, includeInstance),
reputationCredentialsList: jspb.Message.toObjectList(msg.getReputationCredentialsList(),
    proto.interface.ti.users.v1.ReputationCredential.toObject, includeInstance),
xpTokensList: jspb.Message.toObjectList(msg.getXpTokensList(),
    proto.interface.ti.users.v1.XPToken.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.Profile}
 */
proto.interface.ti.users.v1.Profile.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.Profile;
  return proto.interface.ti.users.v1.Profile.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.Profile} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.Profile}
 */
proto.interface.ti.users.v1.Profile.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.XPCredential;
      reader.readMessage(value,proto.interface.ti.users.v1.XPCredential.deserializeBinaryFromReader);
      msg.addXpCredentials(value);
      break;
    case 2:
      var value = new proto.interface.ti.users.v1.ReputationCredential;
      reader.readMessage(value,proto.interface.ti.users.v1.ReputationCredential.deserializeBinaryFromReader);
      msg.addReputationCredentials(value);
      break;
    case 3:
      var value = new proto.interface.ti.users.v1.XPToken;
      reader.readMessage(value,proto.interface.ti.users.v1.XPToken.deserializeBinaryFromReader);
      msg.addXpTokens(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.Profile.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.Profile.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.Profile} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.Profile.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getXpCredentialsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.XPCredential.serializeBinaryToWriter
    );
  }
  f = message.getReputationCredentialsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      2,
      f,
      proto.interface.ti.users.v1.ReputationCredential.serializeBinaryToWriter
    );
  }
  f = message.getXpTokensList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      3,
      f,
      proto.interface.ti.users.v1.XPToken.serializeBinaryToWriter
    );
  }
};


/**
 * repeated XPCredential xp_credentials = 1;
 * @return {!Array<!proto.interface.ti.users.v1.XPCredential>}
 */
proto.interface.ti.users.v1.Profile.prototype.getXpCredentialsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.XPCredential>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.XPCredential, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.XPCredential>} value
 * @return {!proto.interface.ti.users.v1.Profile} returns this
*/
proto.interface.ti.users.v1.Profile.prototype.setXpCredentialsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.XPCredential=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.XPCredential}
 */
proto.interface.ti.users.v1.Profile.prototype.addXpCredentials = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.XPCredential, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.Profile} returns this
 */
proto.interface.ti.users.v1.Profile.prototype.clearXpCredentialsList = function() {
  return this.setXpCredentialsList([]);
};


/**
 * repeated ReputationCredential reputation_credentials = 2;
 * @return {!Array<!proto.interface.ti.users.v1.ReputationCredential>}
 */
proto.interface.ti.users.v1.Profile.prototype.getReputationCredentialsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.ReputationCredential>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.ReputationCredential, 2));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.ReputationCredential>} value
 * @return {!proto.interface.ti.users.v1.Profile} returns this
*/
proto.interface.ti.users.v1.Profile.prototype.setReputationCredentialsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 2, value);
};


/**
 * @param {!proto.interface.ti.users.v1.ReputationCredential=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.ReputationCredential}
 */
proto.interface.ti.users.v1.Profile.prototype.addReputationCredentials = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 2, opt_value, proto.interface.ti.users.v1.ReputationCredential, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.Profile} returns this
 */
proto.interface.ti.users.v1.Profile.prototype.clearReputationCredentialsList = function() {
  return this.setReputationCredentialsList([]);
};


/**
 * repeated XPToken xp_tokens = 3;
 * @return {!Array<!proto.interface.ti.users.v1.XPToken>}
 */
proto.interface.ti.users.v1.Profile.prototype.getXpTokensList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.XPToken>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.XPToken, 3));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.XPToken>} value
 * @return {!proto.interface.ti.users.v1.Profile} returns this
*/
proto.interface.ti.users.v1.Profile.prototype.setXpTokensList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 3, value);
};


/**
 * @param {!proto.interface.ti.users.v1.XPToken=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.XPToken}
 */
proto.interface.ti.users.v1.Profile.prototype.addXpTokens = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 3, opt_value, proto.interface.ti.users.v1.XPToken, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.Profile} returns this
 */
proto.interface.ti.users.v1.Profile.prototype.clearXpTokensList = function() {
  return this.setXpTokensList([]);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.XPCredential.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.XPCredential.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.XPCredential} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.XPCredential.toObject = function(includeInstance, msg) {
  var f, obj = {
issuerPublicKey: jspb.Message.getFieldWithDefault(msg, 1, ""),
profilePublicKey: jspb.Message.getFieldWithDefault(msg, 2, ""),
hcsCredentialMessageHash: jspb.Message.getFieldWithDefault(msg, 3, ""),
issueTime: (f = msg.getIssueTime()) && google_protobuf_timestamp_pb.Timestamp.toObject(includeInstance, f),
state: jspb.Message.getFieldWithDefault(msg, 5, 0)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.XPCredential}
 */
proto.interface.ti.users.v1.XPCredential.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.XPCredential;
  return proto.interface.ti.users.v1.XPCredential.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.XPCredential} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.XPCredential}
 */
proto.interface.ti.users.v1.XPCredential.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setIssuerPublicKey(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setProfilePublicKey(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setHcsCredentialMessageHash(value);
      break;
    case 4:
      var value = new google_protobuf_timestamp_pb.Timestamp;
      reader.readMessage(value,google_protobuf_timestamp_pb.Timestamp.deserializeBinaryFromReader);
      msg.setIssueTime(value);
      break;
    case 5:
      var value = /** @type {!proto.interface.ti.users.v1.CredentialState} */ (reader.readEnum());
      msg.setState(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.XPCredential.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.XPCredential.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.XPCredential} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.XPCredential.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getIssuerPublicKey();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getProfilePublicKey();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
  f = message.getHcsCredentialMessageHash();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
  f = message.getIssueTime();
  if (f != null) {
    writer.writeMessage(
      4,
      f,
      google_protobuf_timestamp_pb.Timestamp.serializeBinaryToWriter
    );
  }
  f = message.getState();
  if (f !== 0.0) {
    writer.writeEnum(
      5,
      f
    );
  }
};


/**
 * optional string issuer_public_key = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.XPCredential.prototype.getIssuerPublicKey = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.XPCredential} returns this
 */
proto.interface.ti.users.v1.XPCredential.prototype.setIssuerPublicKey = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional string profile_public_key = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.XPCredential.prototype.getProfilePublicKey = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.XPCredential} returns this
 */
proto.interface.ti.users.v1.XPCredential.prototype.setProfilePublicKey = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};


/**
 * optional string hcs_credential_message_hash = 3;
 * @return {string}
 */
proto.interface.ti.users.v1.XPCredential.prototype.getHcsCredentialMessageHash = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.XPCredential} returns this
 */
proto.interface.ti.users.v1.XPCredential.prototype.setHcsCredentialMessageHash = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};


/**
 * optional google.protobuf.Timestamp issue_time = 4;
 * @return {?proto.google.protobuf.Timestamp}
 */
proto.interface.ti.users.v1.XPCredential.prototype.getIssueTime = function() {
  return /** @type{?proto.google.protobuf.Timestamp} */ (
    jspb.Message.getWrapperField(this, google_protobuf_timestamp_pb.Timestamp, 4));
};


/**
 * @param {?proto.google.protobuf.Timestamp|undefined} value
 * @return {!proto.interface.ti.users.v1.XPCredential} returns this
*/
proto.interface.ti.users.v1.XPCredential.prototype.setIssueTime = function(value) {
  return jspb.Message.setWrapperField(this, 4, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.XPCredential} returns this
 */
proto.interface.ti.users.v1.XPCredential.prototype.clearIssueTime = function() {
  return this.setIssueTime(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.XPCredential.prototype.hasIssueTime = function() {
  return jspb.Message.getField(this, 4) != null;
};


/**
 * optional CredentialState state = 5;
 * @return {!proto.interface.ti.users.v1.CredentialState}
 */
proto.interface.ti.users.v1.XPCredential.prototype.getState = function() {
  return /** @type {!proto.interface.ti.users.v1.CredentialState} */ (jspb.Message.getFieldWithDefault(this, 5, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.CredentialState} value
 * @return {!proto.interface.ti.users.v1.XPCredential} returns this
 */
proto.interface.ti.users.v1.XPCredential.prototype.setState = function(value) {
  return jspb.Message.setProto3EnumField(this, 5, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.ReputationCredential.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.ReputationCredential.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.ReputationCredential} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ReputationCredential.toObject = function(includeInstance, msg) {
  var f, obj = {
issuerPublicKey: jspb.Message.getFieldWithDefault(msg, 1, ""),
profilePublicKey: jspb.Message.getFieldWithDefault(msg, 2, ""),
hcsCredentialMessageHash: jspb.Message.getFieldWithDefault(msg, 3, ""),
issueTime: (f = msg.getIssueTime()) && google_protobuf_timestamp_pb.Timestamp.toObject(includeInstance, f),
state: jspb.Message.getFieldWithDefault(msg, 5, 0)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.ReputationCredential}
 */
proto.interface.ti.users.v1.ReputationCredential.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.ReputationCredential;
  return proto.interface.ti.users.v1.ReputationCredential.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.ReputationCredential} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.ReputationCredential}
 */
proto.interface.ti.users.v1.ReputationCredential.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setIssuerPublicKey(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setProfilePublicKey(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setHcsCredentialMessageHash(value);
      break;
    case 4:
      var value = new google_protobuf_timestamp_pb.Timestamp;
      reader.readMessage(value,google_protobuf_timestamp_pb.Timestamp.deserializeBinaryFromReader);
      msg.setIssueTime(value);
      break;
    case 5:
      var value = /** @type {!proto.interface.ti.users.v1.CredentialState} */ (reader.readEnum());
      msg.setState(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.ReputationCredential.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.ReputationCredential.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.ReputationCredential} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ReputationCredential.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getIssuerPublicKey();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getProfilePublicKey();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
  f = message.getHcsCredentialMessageHash();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
  f = message.getIssueTime();
  if (f != null) {
    writer.writeMessage(
      4,
      f,
      google_protobuf_timestamp_pb.Timestamp.serializeBinaryToWriter
    );
  }
  f = message.getState();
  if (f !== 0.0) {
    writer.writeEnum(
      5,
      f
    );
  }
};


/**
 * optional string issuer_public_key = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.ReputationCredential.prototype.getIssuerPublicKey = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ReputationCredential} returns this
 */
proto.interface.ti.users.v1.ReputationCredential.prototype.setIssuerPublicKey = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional string profile_public_key = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.ReputationCredential.prototype.getProfilePublicKey = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ReputationCredential} returns this
 */
proto.interface.ti.users.v1.ReputationCredential.prototype.setProfilePublicKey = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};


/**
 * optional string hcs_credential_message_hash = 3;
 * @return {string}
 */
proto.interface.ti.users.v1.ReputationCredential.prototype.getHcsCredentialMessageHash = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ReputationCredential} returns this
 */
proto.interface.ti.users.v1.ReputationCredential.prototype.setHcsCredentialMessageHash = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};


/**
 * optional google.protobuf.Timestamp issue_time = 4;
 * @return {?proto.google.protobuf.Timestamp}
 */
proto.interface.ti.users.v1.ReputationCredential.prototype.getIssueTime = function() {
  return /** @type{?proto.google.protobuf.Timestamp} */ (
    jspb.Message.getWrapperField(this, google_protobuf_timestamp_pb.Timestamp, 4));
};


/**
 * @param {?proto.google.protobuf.Timestamp|undefined} value
 * @return {!proto.interface.ti.users.v1.ReputationCredential} returns this
*/
proto.interface.ti.users.v1.ReputationCredential.prototype.setIssueTime = function(value) {
  return jspb.Message.setWrapperField(this, 4, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.ReputationCredential} returns this
 */
proto.interface.ti.users.v1.ReputationCredential.prototype.clearIssueTime = function() {
  return this.setIssueTime(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.ReputationCredential.prototype.hasIssueTime = function() {
  return jspb.Message.getField(this, 4) != null;
};


/**
 * optional CredentialState state = 5;
 * @return {!proto.interface.ti.users.v1.CredentialState}
 */
proto.interface.ti.users.v1.ReputationCredential.prototype.getState = function() {
  return /** @type {!proto.interface.ti.users.v1.CredentialState} */ (jspb.Message.getFieldWithDefault(this, 5, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.CredentialState} value
 * @return {!proto.interface.ti.users.v1.ReputationCredential} returns this
 */
proto.interface.ti.users.v1.ReputationCredential.prototype.setState = function(value) {
  return jspb.Message.setProto3EnumField(this, 5, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.XPToken.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.XPToken.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.XPToken} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.XPToken.toObject = function(includeInstance, msg) {
  var f, obj = {
issuerPublicKey: jspb.Message.getFieldWithDefault(msg, 1, ""),
profilePublicKey: jspb.Message.getFieldWithDefault(msg, 2, ""),
amount: jspb.Message.getFieldWithDefault(msg, 3, 0),
issueTime: (f = msg.getIssueTime()) && google_protobuf_timestamp_pb.Timestamp.toObject(includeInstance, f),
state: jspb.Message.getFieldWithDefault(msg, 5, 0)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.XPToken}
 */
proto.interface.ti.users.v1.XPToken.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.XPToken;
  return proto.interface.ti.users.v1.XPToken.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.XPToken} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.XPToken}
 */
proto.interface.ti.users.v1.XPToken.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setIssuerPublicKey(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setProfilePublicKey(value);
      break;
    case 3:
      var value = /** @type {number} */ (reader.readInt64());
      msg.setAmount(value);
      break;
    case 4:
      var value = new google_protobuf_timestamp_pb.Timestamp;
      reader.readMessage(value,google_protobuf_timestamp_pb.Timestamp.deserializeBinaryFromReader);
      msg.setIssueTime(value);
      break;
    case 5:
      var value = /** @type {!proto.interface.ti.users.v1.CredentialState} */ (reader.readEnum());
      msg.setState(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.XPToken.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.XPToken.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.XPToken} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.XPToken.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getIssuerPublicKey();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getProfilePublicKey();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
  f = message.getAmount();
  if (f !== 0) {
    writer.writeInt64(
      3,
      f
    );
  }
  f = message.getIssueTime();
  if (f != null) {
    writer.writeMessage(
      4,
      f,
      google_protobuf_timestamp_pb.Timestamp.serializeBinaryToWriter
    );
  }
  f = message.getState();
  if (f !== 0.0) {
    writer.writeEnum(
      5,
      f
    );
  }
};


/**
 * optional string issuer_public_key = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.XPToken.prototype.getIssuerPublicKey = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.XPToken} returns this
 */
proto.interface.ti.users.v1.XPToken.prototype.setIssuerPublicKey = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional string profile_public_key = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.XPToken.prototype.getProfilePublicKey = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.XPToken} returns this
 */
proto.interface.ti.users.v1.XPToken.prototype.setProfilePublicKey = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};


/**
 * optional int64 amount = 3;
 * @return {number}
 */
proto.interface.ti.users.v1.XPToken.prototype.getAmount = function() {
  return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};


/**
 * @param {number} value
 * @return {!proto.interface.ti.users.v1.XPToken} returns this
 */
proto.interface.ti.users.v1.XPToken.prototype.setAmount = function(value) {
  return jspb.Message.setProto3IntField(this, 3, value);
};


/**
 * optional google.protobuf.Timestamp issue_time = 4;
 * @return {?proto.google.protobuf.Timestamp}
 */
proto.interface.ti.users.v1.XPToken.prototype.getIssueTime = function() {
  return /** @type{?proto.google.protobuf.Timestamp} */ (
    jspb.Message.getWrapperField(this, google_protobuf_timestamp_pb.Timestamp, 4));
};


/**
 * @param {?proto.google.protobuf.Timestamp|undefined} value
 * @return {!proto.interface.ti.users.v1.XPToken} returns this
*/
proto.interface.ti.users.v1.XPToken.prototype.setIssueTime = function(value) {
  return jspb.Message.setWrapperField(this, 4, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.XPToken} returns this
 */
proto.interface.ti.users.v1.XPToken.prototype.clearIssueTime = function() {
  return this.setIssueTime(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.XPToken.prototype.hasIssueTime = function() {
  return jspb.Message.getField(this, 4) != null;
};


/**
 * optional CredentialState state = 5;
 * @return {!proto.interface.ti.users.v1.CredentialState}
 */
proto.interface.ti.users.v1.XPToken.prototype.getState = function() {
  return /** @type {!proto.interface.ti.users.v1.CredentialState} */ (jspb.Message.getFieldWithDefault(this, 5, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.CredentialState} value
 * @return {!proto.interface.ti.users.v1.XPToken} returns this
 */
proto.interface.ti.users.v1.XPToken.prototype.setState = function(value) {
  return jspb.Message.setProto3EnumField(this, 5, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.Connector.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.Connector.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.Connector} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.Connector.toObject = function(includeInstance, msg) {
  var f, obj = {
name: jspb.Message.getFieldWithDefault(msg, 1, ""),
displayName: jspb.Message.getFieldWithDefault(msg, 2, ""),
externalUserId: jspb.Message.getFieldWithDefault(msg, 3, ""),
accessToken: jspb.Message.getFieldWithDefault(msg, 4, ""),
refreshToken: jspb.Message.getFieldWithDefault(msg, 5, ""),
expiryTime: (f = msg.getExpiryTime()) && google_protobuf_timestamp_pb.Timestamp.toObject(includeInstance, f),
createTime: (f = msg.getCreateTime()) && google_protobuf_timestamp_pb.Timestamp.toObject(includeInstance, f),
updateTime: (f = msg.getUpdateTime()) && google_protobuf_timestamp_pb.Timestamp.toObject(includeInstance, f),
deleteTime: (f = msg.getDeleteTime()) && google_protobuf_timestamp_pb.Timestamp.toObject(includeInstance, f)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.Connector}
 */
proto.interface.ti.users.v1.Connector.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.Connector;
  return proto.interface.ti.users.v1.Connector.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.Connector} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.Connector}
 */
proto.interface.ti.users.v1.Connector.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setName(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setDisplayName(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setExternalUserId(value);
      break;
    case 4:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setAccessToken(value);
      break;
    case 5:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setRefreshToken(value);
      break;
    case 6:
      var value = new google_protobuf_timestamp_pb.Timestamp;
      reader.readMessage(value,google_protobuf_timestamp_pb.Timestamp.deserializeBinaryFromReader);
      msg.setExpiryTime(value);
      break;
    case 98:
      var value = new google_protobuf_timestamp_pb.Timestamp;
      reader.readMessage(value,google_protobuf_timestamp_pb.Timestamp.deserializeBinaryFromReader);
      msg.setCreateTime(value);
      break;
    case 99:
      var value = new google_protobuf_timestamp_pb.Timestamp;
      reader.readMessage(value,google_protobuf_timestamp_pb.Timestamp.deserializeBinaryFromReader);
      msg.setUpdateTime(value);
      break;
    case 100:
      var value = new google_protobuf_timestamp_pb.Timestamp;
      reader.readMessage(value,google_protobuf_timestamp_pb.Timestamp.deserializeBinaryFromReader);
      msg.setDeleteTime(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.Connector.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.Connector.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.Connector} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.Connector.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getName();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getDisplayName();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
  f = message.getExternalUserId();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
  f = message.getAccessToken();
  if (f.length > 0) {
    writer.writeString(
      4,
      f
    );
  }
  f = message.getRefreshToken();
  if (f.length > 0) {
    writer.writeString(
      5,
      f
    );
  }
  f = message.getExpiryTime();
  if (f != null) {
    writer.writeMessage(
      6,
      f,
      google_protobuf_timestamp_pb.Timestamp.serializeBinaryToWriter
    );
  }
  f = message.getCreateTime();
  if (f != null) {
    writer.writeMessage(
      98,
      f,
      google_protobuf_timestamp_pb.Timestamp.serializeBinaryToWriter
    );
  }
  f = message.getUpdateTime();
  if (f != null) {
    writer.writeMessage(
      99,
      f,
      google_protobuf_timestamp_pb.Timestamp.serializeBinaryToWriter
    );
  }
  f = message.getDeleteTime();
  if (f != null) {
    writer.writeMessage(
      100,
      f,
      google_protobuf_timestamp_pb.Timestamp.serializeBinaryToWriter
    );
  }
};


/**
 * optional string name = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.Connector.prototype.getName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.Connector} returns this
 */
proto.interface.ti.users.v1.Connector.prototype.setName = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional string display_name = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.Connector.prototype.getDisplayName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.Connector} returns this
 */
proto.interface.ti.users.v1.Connector.prototype.setDisplayName = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};


/**
 * optional string external_user_id = 3;
 * @return {string}
 */
proto.interface.ti.users.v1.Connector.prototype.getExternalUserId = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.Connector} returns this
 */
proto.interface.ti.users.v1.Connector.prototype.setExternalUserId = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};


/**
 * optional string access_token = 4;
 * @return {string}
 */
proto.interface.ti.users.v1.Connector.prototype.getAccessToken = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.Connector} returns this
 */
proto.interface.ti.users.v1.Connector.prototype.setAccessToken = function(value) {
  return jspb.Message.setProto3StringField(this, 4, value);
};


/**
 * optional string refresh_token = 5;
 * @return {string}
 */
proto.interface.ti.users.v1.Connector.prototype.getRefreshToken = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.Connector} returns this
 */
proto.interface.ti.users.v1.Connector.prototype.setRefreshToken = function(value) {
  return jspb.Message.setProto3StringField(this, 5, value);
};


/**
 * optional google.protobuf.Timestamp expiry_time = 6;
 * @return {?proto.google.protobuf.Timestamp}
 */
proto.interface.ti.users.v1.Connector.prototype.getExpiryTime = function() {
  return /** @type{?proto.google.protobuf.Timestamp} */ (
    jspb.Message.getWrapperField(this, google_protobuf_timestamp_pb.Timestamp, 6));
};


/**
 * @param {?proto.google.protobuf.Timestamp|undefined} value
 * @return {!proto.interface.ti.users.v1.Connector} returns this
*/
proto.interface.ti.users.v1.Connector.prototype.setExpiryTime = function(value) {
  return jspb.Message.setWrapperField(this, 6, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.Connector} returns this
 */
proto.interface.ti.users.v1.Connector.prototype.clearExpiryTime = function() {
  return this.setExpiryTime(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.Connector.prototype.hasExpiryTime = function() {
  return jspb.Message.getField(this, 6) != null;
};


/**
 * optional google.protobuf.Timestamp create_time = 98;
 * @return {?proto.google.protobuf.Timestamp}
 */
proto.interface.ti.users.v1.Connector.prototype.getCreateTime = function() {
  return /** @type{?proto.google.protobuf.Timestamp} */ (
    jspb.Message.getWrapperField(this, google_protobuf_timestamp_pb.Timestamp, 98));
};


/**
 * @param {?proto.google.protobuf.Timestamp|undefined} value
 * @return {!proto.interface.ti.users.v1.Connector} returns this
*/
proto.interface.ti.users.v1.Connector.prototype.setCreateTime = function(value) {
  return jspb.Message.setWrapperField(this, 98, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.Connector} returns this
 */
proto.interface.ti.users.v1.Connector.prototype.clearCreateTime = function() {
  return this.setCreateTime(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.Connector.prototype.hasCreateTime = function() {
  return jspb.Message.getField(this, 98) != null;
};


/**
 * optional google.protobuf.Timestamp update_time = 99;
 * @return {?proto.google.protobuf.Timestamp}
 */
proto.interface.ti.users.v1.Connector.prototype.getUpdateTime = function() {
  return /** @type{?proto.google.protobuf.Timestamp} */ (
    jspb.Message.getWrapperField(this, google_protobuf_timestamp_pb.Timestamp, 99));
};


/**
 * @param {?proto.google.protobuf.Timestamp|undefined} value
 * @return {!proto.interface.ti.users.v1.Connector} returns this
*/
proto.interface.ti.users.v1.Connector.prototype.setUpdateTime = function(value) {
  return jspb.Message.setWrapperField(this, 99, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.Connector} returns this
 */
proto.interface.ti.users.v1.Connector.prototype.clearUpdateTime = function() {
  return this.setUpdateTime(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.Connector.prototype.hasUpdateTime = function() {
  return jspb.Message.getField(this, 99) != null;
};


/**
 * optional google.protobuf.Timestamp delete_time = 100;
 * @return {?proto.google.protobuf.Timestamp}
 */
proto.interface.ti.users.v1.Connector.prototype.getDeleteTime = function() {
  return /** @type{?proto.google.protobuf.Timestamp} */ (
    jspb.Message.getWrapperField(this, google_protobuf_timestamp_pb.Timestamp, 100));
};


/**
 * @param {?proto.google.protobuf.Timestamp|undefined} value
 * @return {!proto.interface.ti.users.v1.Connector} returns this
*/
proto.interface.ti.users.v1.Connector.prototype.setDeleteTime = function(value) {
  return jspb.Message.setWrapperField(this, 100, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.Connector} returns this
 */
proto.interface.ti.users.v1.Connector.prototype.clearDeleteTime = function() {
  return this.setDeleteTime(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.Connector.prototype.hasDeleteTime = function() {
  return jspb.Message.getField(this, 100) != null;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.CreateUserRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.CreateUserRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.CreateUserRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.CreateUserRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
user: (f = msg.getUser()) && proto.interface.ti.users.v1.User.toObject(includeInstance, f)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.CreateUserRequest}
 */
proto.interface.ti.users.v1.CreateUserRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.CreateUserRequest;
  return proto.interface.ti.users.v1.CreateUserRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.CreateUserRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.CreateUserRequest}
 */
proto.interface.ti.users.v1.CreateUserRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 2:
      var value = new proto.interface.ti.users.v1.User;
      reader.readMessage(value,proto.interface.ti.users.v1.User.deserializeBinaryFromReader);
      msg.setUser(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.CreateUserRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.CreateUserRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.CreateUserRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.CreateUserRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getUser();
  if (f != null) {
    writer.writeMessage(
      2,
      f,
      proto.interface.ti.users.v1.User.serializeBinaryToWriter
    );
  }
};


/**
 * optional User user = 2;
 * @return {?proto.interface.ti.users.v1.User}
 */
proto.interface.ti.users.v1.CreateUserRequest.prototype.getUser = function() {
  return /** @type{?proto.interface.ti.users.v1.User} */ (
    jspb.Message.getWrapperField(this, proto.interface.ti.users.v1.User, 2));
};


/**
 * @param {?proto.interface.ti.users.v1.User|undefined} value
 * @return {!proto.interface.ti.users.v1.CreateUserRequest} returns this
*/
proto.interface.ti.users.v1.CreateUserRequest.prototype.setUser = function(value) {
  return jspb.Message.setWrapperField(this, 2, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.CreateUserRequest} returns this
 */
proto.interface.ti.users.v1.CreateUserRequest.prototype.clearUser = function() {
  return this.setUser(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.CreateUserRequest.prototype.hasUser = function() {
  return jspb.Message.getField(this, 2) != null;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.GetUserRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.GetUserRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.GetUserRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.GetUserRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
name: jspb.Message.getFieldWithDefault(msg, 1, ""),
view: jspb.Message.getFieldWithDefault(msg, 2, 0),
readMask: (f = msg.getReadMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.GetUserRequest}
 */
proto.interface.ti.users.v1.GetUserRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.GetUserRequest;
  return proto.interface.ti.users.v1.GetUserRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.GetUserRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.GetUserRequest}
 */
proto.interface.ti.users.v1.GetUserRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setName(value);
      break;
    case 2:
      var value = /** @type {!proto.interface.ti.users.v1.UserView} */ (reader.readEnum());
      msg.setView(value);
      break;
    case 3:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setReadMask(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.GetUserRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.GetUserRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.GetUserRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.GetUserRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getName();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getView();
  if (f !== 0.0) {
    writer.writeEnum(
      2,
      f
    );
  }
  f = message.getReadMask();
  if (f != null) {
    writer.writeMessage(
      3,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
};


/**
 * optional string name = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.GetUserRequest.prototype.getName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.GetUserRequest} returns this
 */
proto.interface.ti.users.v1.GetUserRequest.prototype.setName = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional UserView view = 2;
 * @return {!proto.interface.ti.users.v1.UserView}
 */
proto.interface.ti.users.v1.GetUserRequest.prototype.getView = function() {
  return /** @type {!proto.interface.ti.users.v1.UserView} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.UserView} value
 * @return {!proto.interface.ti.users.v1.GetUserRequest} returns this
 */
proto.interface.ti.users.v1.GetUserRequest.prototype.setView = function(value) {
  return jspb.Message.setProto3EnumField(this, 2, value);
};


/**
 * optional google.protobuf.FieldMask read_mask = 3;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.GetUserRequest.prototype.getReadMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 3));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.GetUserRequest} returns this
*/
proto.interface.ti.users.v1.GetUserRequest.prototype.setReadMask = function(value) {
  return jspb.Message.setWrapperField(this, 3, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.GetUserRequest} returns this
 */
proto.interface.ti.users.v1.GetUserRequest.prototype.clearReadMask = function() {
  return this.setReadMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.GetUserRequest.prototype.hasReadMask = function() {
  return jspb.Message.getField(this, 3) != null;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.UpdateUserRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.UpdateUserRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.UpdateUserRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.UpdateUserRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
user: (f = msg.getUser()) && proto.interface.ti.users.v1.User.toObject(includeInstance, f),
updateMask: (f = msg.getUpdateMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f),
allowMissing: jspb.Message.getBooleanFieldWithDefault(msg, 3, false)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.UpdateUserRequest}
 */
proto.interface.ti.users.v1.UpdateUserRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.UpdateUserRequest;
  return proto.interface.ti.users.v1.UpdateUserRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.UpdateUserRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.UpdateUserRequest}
 */
proto.interface.ti.users.v1.UpdateUserRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.User;
      reader.readMessage(value,proto.interface.ti.users.v1.User.deserializeBinaryFromReader);
      msg.setUser(value);
      break;
    case 2:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setUpdateMask(value);
      break;
    case 3:
      var value = /** @type {boolean} */ (reader.readBool());
      msg.setAllowMissing(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.UpdateUserRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.UpdateUserRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.UpdateUserRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.UpdateUserRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getUser();
  if (f != null) {
    writer.writeMessage(
      1,
      f,
      proto.interface.ti.users.v1.User.serializeBinaryToWriter
    );
  }
  f = message.getUpdateMask();
  if (f != null) {
    writer.writeMessage(
      2,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
  f = message.getAllowMissing();
  if (f) {
    writer.writeBool(
      3,
      f
    );
  }
};


/**
 * optional User user = 1;
 * @return {?proto.interface.ti.users.v1.User}
 */
proto.interface.ti.users.v1.UpdateUserRequest.prototype.getUser = function() {
  return /** @type{?proto.interface.ti.users.v1.User} */ (
    jspb.Message.getWrapperField(this, proto.interface.ti.users.v1.User, 1));
};


/**
 * @param {?proto.interface.ti.users.v1.User|undefined} value
 * @return {!proto.interface.ti.users.v1.UpdateUserRequest} returns this
*/
proto.interface.ti.users.v1.UpdateUserRequest.prototype.setUser = function(value) {
  return jspb.Message.setWrapperField(this, 1, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.UpdateUserRequest} returns this
 */
proto.interface.ti.users.v1.UpdateUserRequest.prototype.clearUser = function() {
  return this.setUser(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.UpdateUserRequest.prototype.hasUser = function() {
  return jspb.Message.getField(this, 1) != null;
};


/**
 * optional google.protobuf.FieldMask update_mask = 2;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.UpdateUserRequest.prototype.getUpdateMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 2));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.UpdateUserRequest} returns this
*/
proto.interface.ti.users.v1.UpdateUserRequest.prototype.setUpdateMask = function(value) {
  return jspb.Message.setWrapperField(this, 2, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.UpdateUserRequest} returns this
 */
proto.interface.ti.users.v1.UpdateUserRequest.prototype.clearUpdateMask = function() {
  return this.setUpdateMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.UpdateUserRequest.prototype.hasUpdateMask = function() {
  return jspb.Message.getField(this, 2) != null;
};


/**
 * optional bool allow_missing = 3;
 * @return {boolean}
 */
proto.interface.ti.users.v1.UpdateUserRequest.prototype.getAllowMissing = function() {
  return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 3, false));
};


/**
 * @param {boolean} value
 * @return {!proto.interface.ti.users.v1.UpdateUserRequest} returns this
 */
proto.interface.ti.users.v1.UpdateUserRequest.prototype.setAllowMissing = function(value) {
  return jspb.Message.setProto3BooleanField(this, 3, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.DeleteUserRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.DeleteUserRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.DeleteUserRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.DeleteUserRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
name: jspb.Message.getFieldWithDefault(msg, 1, ""),
etag: jspb.Message.getFieldWithDefault(msg, 2, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.DeleteUserRequest}
 */
proto.interface.ti.users.v1.DeleteUserRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.DeleteUserRequest;
  return proto.interface.ti.users.v1.DeleteUserRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.DeleteUserRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.DeleteUserRequest}
 */
proto.interface.ti.users.v1.DeleteUserRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setName(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setEtag(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.DeleteUserRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.DeleteUserRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.DeleteUserRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.DeleteUserRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getName();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getEtag();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
};


/**
 * optional string name = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.DeleteUserRequest.prototype.getName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.DeleteUserRequest} returns this
 */
proto.interface.ti.users.v1.DeleteUserRequest.prototype.setName = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional string etag = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.DeleteUserRequest.prototype.getEtag = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.DeleteUserRequest} returns this
 */
proto.interface.ti.users.v1.DeleteUserRequest.prototype.setEtag = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.UndeleteUserRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.UndeleteUserRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.UndeleteUserRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.UndeleteUserRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
name: jspb.Message.getFieldWithDefault(msg, 1, ""),
etag: jspb.Message.getFieldWithDefault(msg, 2, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.UndeleteUserRequest}
 */
proto.interface.ti.users.v1.UndeleteUserRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.UndeleteUserRequest;
  return proto.interface.ti.users.v1.UndeleteUserRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.UndeleteUserRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.UndeleteUserRequest}
 */
proto.interface.ti.users.v1.UndeleteUserRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setName(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setEtag(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.UndeleteUserRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.UndeleteUserRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.UndeleteUserRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.UndeleteUserRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getName();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getEtag();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
};


/**
 * optional string name = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.UndeleteUserRequest.prototype.getName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.UndeleteUserRequest} returns this
 */
proto.interface.ti.users.v1.UndeleteUserRequest.prototype.setName = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional string etag = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.UndeleteUserRequest.prototype.getEtag = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.UndeleteUserRequest} returns this
 */
proto.interface.ti.users.v1.UndeleteUserRequest.prototype.setEtag = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.ListUsersRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.ListUsersRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListUsersRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
pageSize: jspb.Message.getFieldWithDefault(msg, 2, 0),
pageToken: jspb.Message.getFieldWithDefault(msg, 3, ""),
view: jspb.Message.getFieldWithDefault(msg, 4, 0),
readMask: (f = msg.getReadMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f),
filter: jspb.Message.getFieldWithDefault(msg, 6, ""),
orderBy: jspb.Message.getFieldWithDefault(msg, 7, ""),
showDeleted: jspb.Message.getBooleanFieldWithDefault(msg, 8, false)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.ListUsersRequest}
 */
proto.interface.ti.users.v1.ListUsersRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.ListUsersRequest;
  return proto.interface.ti.users.v1.ListUsersRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.ListUsersRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.ListUsersRequest}
 */
proto.interface.ti.users.v1.ListUsersRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 2:
      var value = /** @type {number} */ (reader.readInt32());
      msg.setPageSize(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPageToken(value);
      break;
    case 4:
      var value = /** @type {!proto.interface.ti.users.v1.UserView} */ (reader.readEnum());
      msg.setView(value);
      break;
    case 5:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setReadMask(value);
      break;
    case 6:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setFilter(value);
      break;
    case 7:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setOrderBy(value);
      break;
    case 8:
      var value = /** @type {boolean} */ (reader.readBool());
      msg.setShowDeleted(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.ListUsersRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.ListUsersRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListUsersRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getPageSize();
  if (f !== 0) {
    writer.writeInt32(
      2,
      f
    );
  }
  f = message.getPageToken();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
  f = message.getView();
  if (f !== 0.0) {
    writer.writeEnum(
      4,
      f
    );
  }
  f = message.getReadMask();
  if (f != null) {
    writer.writeMessage(
      5,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
  f = message.getFilter();
  if (f.length > 0) {
    writer.writeString(
      6,
      f
    );
  }
  f = message.getOrderBy();
  if (f.length > 0) {
    writer.writeString(
      7,
      f
    );
  }
  f = message.getShowDeleted();
  if (f) {
    writer.writeBool(
      8,
      f
    );
  }
};


/**
 * optional int32 page_size = 2;
 * @return {number}
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.getPageSize = function() {
  return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};


/**
 * @param {number} value
 * @return {!proto.interface.ti.users.v1.ListUsersRequest} returns this
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.setPageSize = function(value) {
  return jspb.Message.setProto3IntField(this, 2, value);
};


/**
 * optional string page_token = 3;
 * @return {string}
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.getPageToken = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ListUsersRequest} returns this
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.setPageToken = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};


/**
 * optional UserView view = 4;
 * @return {!proto.interface.ti.users.v1.UserView}
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.getView = function() {
  return /** @type {!proto.interface.ti.users.v1.UserView} */ (jspb.Message.getFieldWithDefault(this, 4, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.UserView} value
 * @return {!proto.interface.ti.users.v1.ListUsersRequest} returns this
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.setView = function(value) {
  return jspb.Message.setProto3EnumField(this, 4, value);
};


/**
 * optional google.protobuf.FieldMask read_mask = 5;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.getReadMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 5));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.ListUsersRequest} returns this
*/
proto.interface.ti.users.v1.ListUsersRequest.prototype.setReadMask = function(value) {
  return jspb.Message.setWrapperField(this, 5, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.ListUsersRequest} returns this
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.clearReadMask = function() {
  return this.setReadMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.hasReadMask = function() {
  return jspb.Message.getField(this, 5) != null;
};


/**
 * optional string filter = 6;
 * @return {string}
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.getFilter = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 6, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ListUsersRequest} returns this
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.setFilter = function(value) {
  return jspb.Message.setProto3StringField(this, 6, value);
};


/**
 * optional string order_by = 7;
 * @return {string}
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.getOrderBy = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 7, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ListUsersRequest} returns this
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.setOrderBy = function(value) {
  return jspb.Message.setProto3StringField(this, 7, value);
};


/**
 * optional bool show_deleted = 8;
 * @return {boolean}
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.getShowDeleted = function() {
  return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 8, false));
};


/**
 * @param {boolean} value
 * @return {!proto.interface.ti.users.v1.ListUsersRequest} returns this
 */
proto.interface.ti.users.v1.ListUsersRequest.prototype.setShowDeleted = function(value) {
  return jspb.Message.setProto3BooleanField(this, 8, value);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.ListUsersResponse.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.ListUsersResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.ListUsersResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.ListUsersResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListUsersResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
usersList: jspb.Message.toObjectList(msg.getUsersList(),
    proto.interface.ti.users.v1.User.toObject, includeInstance),
nextPageToken: jspb.Message.getFieldWithDefault(msg, 2, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.ListUsersResponse}
 */
proto.interface.ti.users.v1.ListUsersResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.ListUsersResponse;
  return proto.interface.ti.users.v1.ListUsersResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.ListUsersResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.ListUsersResponse}
 */
proto.interface.ti.users.v1.ListUsersResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.User;
      reader.readMessage(value,proto.interface.ti.users.v1.User.deserializeBinaryFromReader);
      msg.addUsers(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setNextPageToken(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.ListUsersResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.ListUsersResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.ListUsersResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListUsersResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getUsersList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.User.serializeBinaryToWriter
    );
  }
  f = message.getNextPageToken();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
};


/**
 * repeated User users = 1;
 * @return {!Array<!proto.interface.ti.users.v1.User>}
 */
proto.interface.ti.users.v1.ListUsersResponse.prototype.getUsersList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.User>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.User, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.User>} value
 * @return {!proto.interface.ti.users.v1.ListUsersResponse} returns this
*/
proto.interface.ti.users.v1.ListUsersResponse.prototype.setUsersList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.User=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.User}
 */
proto.interface.ti.users.v1.ListUsersResponse.prototype.addUsers = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.User, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.ListUsersResponse} returns this
 */
proto.interface.ti.users.v1.ListUsersResponse.prototype.clearUsersList = function() {
  return this.setUsersList([]);
};


/**
 * optional string next_page_token = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.ListUsersResponse.prototype.getNextPageToken = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ListUsersResponse} returns this
 */
proto.interface.ti.users.v1.ListUsersResponse.prototype.setNextPageToken = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.repeatedFields_ = [2];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchGetUsersRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchGetUsersRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
namesList: (f = jspb.Message.getRepeatedField(msg, 2)) == null ? undefined : f,
view: jspb.Message.getFieldWithDefault(msg, 3, 0),
readMask: (f = msg.getReadMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchGetUsersRequest}
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchGetUsersRequest;
  return proto.interface.ti.users.v1.BatchGetUsersRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchGetUsersRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchGetUsersRequest}
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.addNames(value);
      break;
    case 3:
      var value = /** @type {!proto.interface.ti.users.v1.UserView} */ (reader.readEnum());
      msg.setView(value);
      break;
    case 4:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setReadMask(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchGetUsersRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchGetUsersRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getNamesList();
  if (f.length > 0) {
    writer.writeRepeatedString(
      2,
      f
    );
  }
  f = message.getView();
  if (f !== 0.0) {
    writer.writeEnum(
      3,
      f
    );
  }
  f = message.getReadMask();
  if (f != null) {
    writer.writeMessage(
      4,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
};


/**
 * repeated string names = 2;
 * @return {!Array<string>}
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.prototype.getNamesList = function() {
  return /** @type {!Array<string>} */ (jspb.Message.getRepeatedField(this, 2));
};


/**
 * @param {!Array<string>} value
 * @return {!proto.interface.ti.users.v1.BatchGetUsersRequest} returns this
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.prototype.setNamesList = function(value) {
  return jspb.Message.setField(this, 2, value || []);
};


/**
 * @param {string} value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.BatchGetUsersRequest} returns this
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.prototype.addNames = function(value, opt_index) {
  return jspb.Message.addToRepeatedField(this, 2, value, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchGetUsersRequest} returns this
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.prototype.clearNamesList = function() {
  return this.setNamesList([]);
};


/**
 * optional UserView view = 3;
 * @return {!proto.interface.ti.users.v1.UserView}
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.prototype.getView = function() {
  return /** @type {!proto.interface.ti.users.v1.UserView} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.UserView} value
 * @return {!proto.interface.ti.users.v1.BatchGetUsersRequest} returns this
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.prototype.setView = function(value) {
  return jspb.Message.setProto3EnumField(this, 3, value);
};


/**
 * optional google.protobuf.FieldMask read_mask = 4;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.prototype.getReadMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 4));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.BatchGetUsersRequest} returns this
*/
proto.interface.ti.users.v1.BatchGetUsersRequest.prototype.setReadMask = function(value) {
  return jspb.Message.setWrapperField(this, 4, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.BatchGetUsersRequest} returns this
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.prototype.clearReadMask = function() {
  return this.setReadMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.BatchGetUsersRequest.prototype.hasReadMask = function() {
  return jspb.Message.getField(this, 4) != null;
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchGetUsersResponse.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchGetUsersResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchGetUsersResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchGetUsersResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchGetUsersResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
usersList: jspb.Message.toObjectList(msg.getUsersList(),
    proto.interface.ti.users.v1.User.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchGetUsersResponse}
 */
proto.interface.ti.users.v1.BatchGetUsersResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchGetUsersResponse;
  return proto.interface.ti.users.v1.BatchGetUsersResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchGetUsersResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchGetUsersResponse}
 */
proto.interface.ti.users.v1.BatchGetUsersResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.User;
      reader.readMessage(value,proto.interface.ti.users.v1.User.deserializeBinaryFromReader);
      msg.addUsers(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchGetUsersResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchGetUsersResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchGetUsersResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchGetUsersResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getUsersList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.User.serializeBinaryToWriter
    );
  }
};


/**
 * repeated User users = 1;
 * @return {!Array<!proto.interface.ti.users.v1.User>}
 */
proto.interface.ti.users.v1.BatchGetUsersResponse.prototype.getUsersList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.User>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.User, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.User>} value
 * @return {!proto.interface.ti.users.v1.BatchGetUsersResponse} returns this
*/
proto.interface.ti.users.v1.BatchGetUsersResponse.prototype.setUsersList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.User=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.User}
 */
proto.interface.ti.users.v1.BatchGetUsersResponse.prototype.addUsers = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.User, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchGetUsersResponse} returns this
 */
proto.interface.ti.users.v1.BatchGetUsersResponse.prototype.clearUsersList = function() {
  return this.setUsersList([]);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchDeleteUsersRequest.repeatedFields_ = [2];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchDeleteUsersRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchDeleteUsersRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchDeleteUsersRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchDeleteUsersRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
requestsList: jspb.Message.toObjectList(msg.getRequestsList(),
    proto.interface.ti.users.v1.DeleteUserRequest.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchDeleteUsersRequest}
 */
proto.interface.ti.users.v1.BatchDeleteUsersRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchDeleteUsersRequest;
  return proto.interface.ti.users.v1.BatchDeleteUsersRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchDeleteUsersRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchDeleteUsersRequest}
 */
proto.interface.ti.users.v1.BatchDeleteUsersRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 2:
      var value = new proto.interface.ti.users.v1.DeleteUserRequest;
      reader.readMessage(value,proto.interface.ti.users.v1.DeleteUserRequest.deserializeBinaryFromReader);
      msg.addRequests(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchDeleteUsersRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchDeleteUsersRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchDeleteUsersRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchDeleteUsersRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getRequestsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      2,
      f,
      proto.interface.ti.users.v1.DeleteUserRequest.serializeBinaryToWriter
    );
  }
};


/**
 * repeated DeleteUserRequest requests = 2;
 * @return {!Array<!proto.interface.ti.users.v1.DeleteUserRequest>}
 */
proto.interface.ti.users.v1.BatchDeleteUsersRequest.prototype.getRequestsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.DeleteUserRequest>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.DeleteUserRequest, 2));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.DeleteUserRequest>} value
 * @return {!proto.interface.ti.users.v1.BatchDeleteUsersRequest} returns this
*/
proto.interface.ti.users.v1.BatchDeleteUsersRequest.prototype.setRequestsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 2, value);
};


/**
 * @param {!proto.interface.ti.users.v1.DeleteUserRequest=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.DeleteUserRequest}
 */
proto.interface.ti.users.v1.BatchDeleteUsersRequest.prototype.addRequests = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 2, opt_value, proto.interface.ti.users.v1.DeleteUserRequest, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchDeleteUsersRequest} returns this
 */
proto.interface.ti.users.v1.BatchDeleteUsersRequest.prototype.clearRequestsList = function() {
  return this.setRequestsList([]);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchDeleteUsersResponse.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchDeleteUsersResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchDeleteUsersResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchDeleteUsersResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchDeleteUsersResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
usersList: jspb.Message.toObjectList(msg.getUsersList(),
    proto.interface.ti.users.v1.User.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchDeleteUsersResponse}
 */
proto.interface.ti.users.v1.BatchDeleteUsersResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchDeleteUsersResponse;
  return proto.interface.ti.users.v1.BatchDeleteUsersResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchDeleteUsersResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchDeleteUsersResponse}
 */
proto.interface.ti.users.v1.BatchDeleteUsersResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.User;
      reader.readMessage(value,proto.interface.ti.users.v1.User.deserializeBinaryFromReader);
      msg.addUsers(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchDeleteUsersResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchDeleteUsersResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchDeleteUsersResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchDeleteUsersResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getUsersList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.User.serializeBinaryToWriter
    );
  }
};


/**
 * repeated User users = 1;
 * @return {!Array<!proto.interface.ti.users.v1.User>}
 */
proto.interface.ti.users.v1.BatchDeleteUsersResponse.prototype.getUsersList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.User>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.User, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.User>} value
 * @return {!proto.interface.ti.users.v1.BatchDeleteUsersResponse} returns this
*/
proto.interface.ti.users.v1.BatchDeleteUsersResponse.prototype.setUsersList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.User=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.User}
 */
proto.interface.ti.users.v1.BatchDeleteUsersResponse.prototype.addUsers = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.User, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchDeleteUsersResponse} returns this
 */
proto.interface.ti.users.v1.BatchDeleteUsersResponse.prototype.clearUsersList = function() {
  return this.setUsersList([]);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.StreamUsersRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.StreamUsersRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.StreamUsersRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.StreamUsersRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
view: jspb.Message.getFieldWithDefault(msg, 2, 0),
readMask: (f = msg.getReadMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f),
filter: jspb.Message.getFieldWithDefault(msg, 4, ""),
orderBy: jspb.Message.getFieldWithDefault(msg, 5, ""),
showDeleted: jspb.Message.getBooleanFieldWithDefault(msg, 6, false)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.StreamUsersRequest}
 */
proto.interface.ti.users.v1.StreamUsersRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.StreamUsersRequest;
  return proto.interface.ti.users.v1.StreamUsersRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.StreamUsersRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.StreamUsersRequest}
 */
proto.interface.ti.users.v1.StreamUsersRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 2:
      var value = /** @type {!proto.interface.ti.users.v1.UserView} */ (reader.readEnum());
      msg.setView(value);
      break;
    case 3:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setReadMask(value);
      break;
    case 4:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setFilter(value);
      break;
    case 5:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setOrderBy(value);
      break;
    case 6:
      var value = /** @type {boolean} */ (reader.readBool());
      msg.setShowDeleted(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.StreamUsersRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.StreamUsersRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.StreamUsersRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.StreamUsersRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getView();
  if (f !== 0.0) {
    writer.writeEnum(
      2,
      f
    );
  }
  f = message.getReadMask();
  if (f != null) {
    writer.writeMessage(
      3,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
  f = message.getFilter();
  if (f.length > 0) {
    writer.writeString(
      4,
      f
    );
  }
  f = message.getOrderBy();
  if (f.length > 0) {
    writer.writeString(
      5,
      f
    );
  }
  f = message.getShowDeleted();
  if (f) {
    writer.writeBool(
      6,
      f
    );
  }
};


/**
 * optional UserView view = 2;
 * @return {!proto.interface.ti.users.v1.UserView}
 */
proto.interface.ti.users.v1.StreamUsersRequest.prototype.getView = function() {
  return /** @type {!proto.interface.ti.users.v1.UserView} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.UserView} value
 * @return {!proto.interface.ti.users.v1.StreamUsersRequest} returns this
 */
proto.interface.ti.users.v1.StreamUsersRequest.prototype.setView = function(value) {
  return jspb.Message.setProto3EnumField(this, 2, value);
};


/**
 * optional google.protobuf.FieldMask read_mask = 3;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.StreamUsersRequest.prototype.getReadMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 3));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.StreamUsersRequest} returns this
*/
proto.interface.ti.users.v1.StreamUsersRequest.prototype.setReadMask = function(value) {
  return jspb.Message.setWrapperField(this, 3, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.StreamUsersRequest} returns this
 */
proto.interface.ti.users.v1.StreamUsersRequest.prototype.clearReadMask = function() {
  return this.setReadMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.StreamUsersRequest.prototype.hasReadMask = function() {
  return jspb.Message.getField(this, 3) != null;
};


/**
 * optional string filter = 4;
 * @return {string}
 */
proto.interface.ti.users.v1.StreamUsersRequest.prototype.getFilter = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.StreamUsersRequest} returns this
 */
proto.interface.ti.users.v1.StreamUsersRequest.prototype.setFilter = function(value) {
  return jspb.Message.setProto3StringField(this, 4, value);
};


/**
 * optional string order_by = 5;
 * @return {string}
 */
proto.interface.ti.users.v1.StreamUsersRequest.prototype.getOrderBy = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.StreamUsersRequest} returns this
 */
proto.interface.ti.users.v1.StreamUsersRequest.prototype.setOrderBy = function(value) {
  return jspb.Message.setProto3StringField(this, 5, value);
};


/**
 * optional bool show_deleted = 6;
 * @return {boolean}
 */
proto.interface.ti.users.v1.StreamUsersRequest.prototype.getShowDeleted = function() {
  return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 6, false));
};


/**
 * @param {boolean} value
 * @return {!proto.interface.ti.users.v1.StreamUsersRequest} returns this
 */
proto.interface.ti.users.v1.StreamUsersRequest.prototype.setShowDeleted = function(value) {
  return jspb.Message.setProto3BooleanField(this, 6, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.RetrieveUserByEmailRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.RetrieveUserByEmailRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.RetrieveUserByEmailRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RetrieveUserByEmailRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
email: jspb.Message.getFieldWithDefault(msg, 1, ""),
readMask: (f = msg.getReadMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.RetrieveUserByEmailRequest}
 */
proto.interface.ti.users.v1.RetrieveUserByEmailRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.RetrieveUserByEmailRequest;
  return proto.interface.ti.users.v1.RetrieveUserByEmailRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.RetrieveUserByEmailRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.RetrieveUserByEmailRequest}
 */
proto.interface.ti.users.v1.RetrieveUserByEmailRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setEmail(value);
      break;
    case 2:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setReadMask(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.RetrieveUserByEmailRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.RetrieveUserByEmailRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.RetrieveUserByEmailRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RetrieveUserByEmailRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getEmail();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getReadMask();
  if (f != null) {
    writer.writeMessage(
      2,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
};


/**
 * optional string email = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.RetrieveUserByEmailRequest.prototype.getEmail = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.RetrieveUserByEmailRequest} returns this
 */
proto.interface.ti.users.v1.RetrieveUserByEmailRequest.prototype.setEmail = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional google.protobuf.FieldMask read_mask = 2;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.RetrieveUserByEmailRequest.prototype.getReadMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 2));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.RetrieveUserByEmailRequest} returns this
*/
proto.interface.ti.users.v1.RetrieveUserByEmailRequest.prototype.setReadMask = function(value) {
  return jspb.Message.setWrapperField(this, 2, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.RetrieveUserByEmailRequest} returns this
 */
proto.interface.ti.users.v1.RetrieveUserByEmailRequest.prototype.clearReadMask = function() {
  return this.setReadMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.RetrieveUserByEmailRequest.prototype.hasReadMask = function() {
  return jspb.Message.getField(this, 2) != null;
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
usersList: (f = jspb.Message.getRepeatedField(msg, 1)) == null ? undefined : f,
readMask: (f = msg.getReadMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest}
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest;
  return proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest}
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.addUsers(value);
      break;
    case 2:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setReadMask(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getUsersList();
  if (f.length > 0) {
    writer.writeRepeatedString(
      1,
      f
    );
  }
  f = message.getReadMask();
  if (f != null) {
    writer.writeMessage(
      2,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
};


/**
 * repeated string users = 1;
 * @return {!Array<string>}
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.prototype.getUsersList = function() {
  return /** @type {!Array<string>} */ (jspb.Message.getRepeatedField(this, 1));
};


/**
 * @param {!Array<string>} value
 * @return {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest} returns this
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.prototype.setUsersList = function(value) {
  return jspb.Message.setField(this, 1, value || []);
};


/**
 * @param {string} value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest} returns this
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.prototype.addUsers = function(value, opt_index) {
  return jspb.Message.addToRepeatedField(this, 1, value, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest} returns this
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.prototype.clearUsersList = function() {
  return this.setUsersList([]);
};


/**
 * optional google.protobuf.FieldMask read_mask = 2;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.prototype.getReadMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 2));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest} returns this
*/
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.prototype.setReadMask = function(value) {
  return jspb.Message.setWrapperField(this, 2, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest} returns this
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.prototype.clearReadMask = function() {
  return this.setReadMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersRequest.prototype.hasReadMask = function() {
  return jspb.Message.getField(this, 2) != null;
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
maskedUsersList: jspb.Message.toObjectList(msg.getMaskedUsersList(),
    proto.interface.ti.users.v1.MaskedUser.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse}
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse;
  return proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse}
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.MaskedUser;
      reader.readMessage(value,proto.interface.ti.users.v1.MaskedUser.deserializeBinaryFromReader);
      msg.addMaskedUsers(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getMaskedUsersList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.MaskedUser.serializeBinaryToWriter
    );
  }
};


/**
 * repeated MaskedUser masked_users = 1;
 * @return {!Array<!proto.interface.ti.users.v1.MaskedUser>}
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.prototype.getMaskedUsersList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.MaskedUser>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.MaskedUser, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.MaskedUser>} value
 * @return {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse} returns this
*/
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.prototype.setMaskedUsersList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.MaskedUser=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.MaskedUser}
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.prototype.addMaskedUsers = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.MaskedUser, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse} returns this
 */
proto.interface.ti.users.v1.BatchRetrieveMaskedUsersResponse.prototype.clearMaskedUsersList = function() {
  return this.setMaskedUsersList([]);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.LookupUserRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.LookupUserRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.LookupUserRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.LookupUserRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
searchText: jspb.Message.getFieldWithDefault(msg, 1, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.LookupUserRequest}
 */
proto.interface.ti.users.v1.LookupUserRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.LookupUserRequest;
  return proto.interface.ti.users.v1.LookupUserRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.LookupUserRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.LookupUserRequest}
 */
proto.interface.ti.users.v1.LookupUserRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setSearchText(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.LookupUserRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.LookupUserRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.LookupUserRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.LookupUserRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getSearchText();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
};


/**
 * optional string search_text = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.LookupUserRequest.prototype.getSearchText = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.LookupUserRequest} returns this
 */
proto.interface.ti.users.v1.LookupUserRequest.prototype.setSearchText = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.LookupUserResponse.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.LookupUserResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.LookupUserResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.LookupUserResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.LookupUserResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
resultsList: jspb.Message.toObjectList(msg.getResultsList(),
    proto.interface.ti.users.v1.LookupUserResponse.Result.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.LookupUserResponse}
 */
proto.interface.ti.users.v1.LookupUserResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.LookupUserResponse;
  return proto.interface.ti.users.v1.LookupUserResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.LookupUserResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.LookupUserResponse}
 */
proto.interface.ti.users.v1.LookupUserResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.LookupUserResponse.Result;
      reader.readMessage(value,proto.interface.ti.users.v1.LookupUserResponse.Result.deserializeBinaryFromReader);
      msg.addResults(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.LookupUserResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.LookupUserResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.LookupUserResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.LookupUserResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getResultsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.LookupUserResponse.Result.serializeBinaryToWriter
    );
  }
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.LookupUserResponse.Result.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.LookupUserResponse.Result.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.LookupUserResponse.Result} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.LookupUserResponse.Result.toObject = function(includeInstance, msg) {
  var f, obj = {
user: jspb.Message.getFieldWithDefault(msg, 1, ""),
displayName: jspb.Message.getFieldWithDefault(msg, 2, ""),
maskedEmail: jspb.Message.getFieldWithDefault(msg, 3, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.LookupUserResponse.Result}
 */
proto.interface.ti.users.v1.LookupUserResponse.Result.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.LookupUserResponse.Result;
  return proto.interface.ti.users.v1.LookupUserResponse.Result.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.LookupUserResponse.Result} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.LookupUserResponse.Result}
 */
proto.interface.ti.users.v1.LookupUserResponse.Result.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setUser(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setDisplayName(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setMaskedEmail(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.LookupUserResponse.Result.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.LookupUserResponse.Result.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.LookupUserResponse.Result} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.LookupUserResponse.Result.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getUser();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getDisplayName();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
  f = message.getMaskedEmail();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
};


/**
 * optional string user = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.LookupUserResponse.Result.prototype.getUser = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.LookupUserResponse.Result} returns this
 */
proto.interface.ti.users.v1.LookupUserResponse.Result.prototype.setUser = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional string display_name = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.LookupUserResponse.Result.prototype.getDisplayName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.LookupUserResponse.Result} returns this
 */
proto.interface.ti.users.v1.LookupUserResponse.Result.prototype.setDisplayName = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};


/**
 * optional string masked_email = 3;
 * @return {string}
 */
proto.interface.ti.users.v1.LookupUserResponse.Result.prototype.getMaskedEmail = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.LookupUserResponse.Result} returns this
 */
proto.interface.ti.users.v1.LookupUserResponse.Result.prototype.setMaskedEmail = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};


/**
 * repeated Result results = 1;
 * @return {!Array<!proto.interface.ti.users.v1.LookupUserResponse.Result>}
 */
proto.interface.ti.users.v1.LookupUserResponse.prototype.getResultsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.LookupUserResponse.Result>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.LookupUserResponse.Result, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.LookupUserResponse.Result>} value
 * @return {!proto.interface.ti.users.v1.LookupUserResponse} returns this
*/
proto.interface.ti.users.v1.LookupUserResponse.prototype.setResultsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.LookupUserResponse.Result=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.LookupUserResponse.Result}
 */
proto.interface.ti.users.v1.LookupUserResponse.prototype.addResults = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.LookupUserResponse.Result, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.LookupUserResponse} returns this
 */
proto.interface.ti.users.v1.LookupUserResponse.prototype.clearResultsList = function() {
  return this.setResultsList([]);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.RetrieveMaskedUsersRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
pageSize: jspb.Message.getFieldWithDefault(msg, 2, 0),
pageToken: jspb.Message.getFieldWithDefault(msg, 3, ""),
readMask: (f = msg.getReadMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f),
filter: jspb.Message.getFieldWithDefault(msg, 5, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUsersRequest}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.RetrieveMaskedUsersRequest;
  return proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.RetrieveMaskedUsersRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUsersRequest}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 2:
      var value = /** @type {number} */ (reader.readInt32());
      msg.setPageSize(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPageToken(value);
      break;
    case 4:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setReadMask(value);
      break;
    case 5:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setFilter(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.RetrieveMaskedUsersRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getPageSize();
  if (f !== 0) {
    writer.writeInt32(
      2,
      f
    );
  }
  f = message.getPageToken();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
  f = message.getReadMask();
  if (f != null) {
    writer.writeMessage(
      4,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
  f = message.getFilter();
  if (f.length > 0) {
    writer.writeString(
      5,
      f
    );
  }
};


/**
 * optional int32 page_size = 2;
 * @return {number}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.prototype.getPageSize = function() {
  return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};


/**
 * @param {number} value
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUsersRequest} returns this
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.prototype.setPageSize = function(value) {
  return jspb.Message.setProto3IntField(this, 2, value);
};


/**
 * optional string page_token = 3;
 * @return {string}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.prototype.getPageToken = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUsersRequest} returns this
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.prototype.setPageToken = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};


/**
 * optional google.protobuf.FieldMask read_mask = 4;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.prototype.getReadMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 4));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUsersRequest} returns this
*/
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.prototype.setReadMask = function(value) {
  return jspb.Message.setWrapperField(this, 4, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUsersRequest} returns this
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.prototype.clearReadMask = function() {
  return this.setReadMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.prototype.hasReadMask = function() {
  return jspb.Message.getField(this, 4) != null;
};


/**
 * optional string filter = 5;
 * @return {string}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.prototype.getFilter = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUsersRequest} returns this
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersRequest.prototype.setFilter = function(value) {
  return jspb.Message.setProto3StringField(this, 5, value);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.RetrieveMaskedUsersResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
usersList: jspb.Message.toObjectList(msg.getUsersList(),
    proto.interface.ti.users.v1.MaskedUser.toObject, includeInstance),
nextPageToken: jspb.Message.getFieldWithDefault(msg, 2, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUsersResponse}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.RetrieveMaskedUsersResponse;
  return proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.RetrieveMaskedUsersResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUsersResponse}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.MaskedUser;
      reader.readMessage(value,proto.interface.ti.users.v1.MaskedUser.deserializeBinaryFromReader);
      msg.addUsers(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setNextPageToken(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.RetrieveMaskedUsersResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getUsersList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.MaskedUser.serializeBinaryToWriter
    );
  }
  f = message.getNextPageToken();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
};


/**
 * repeated MaskedUser users = 1;
 * @return {!Array<!proto.interface.ti.users.v1.MaskedUser>}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.prototype.getUsersList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.MaskedUser>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.MaskedUser, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.MaskedUser>} value
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUsersResponse} returns this
*/
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.prototype.setUsersList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.MaskedUser=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.MaskedUser}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.prototype.addUsers = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.MaskedUser, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUsersResponse} returns this
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.prototype.clearUsersList = function() {
  return this.setUsersList([]);
};


/**
 * optional string next_page_token = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.prototype.getNextPageToken = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUsersResponse} returns this
 */
proto.interface.ti.users.v1.RetrieveMaskedUsersResponse.prototype.setNextPageToken = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};



/**
 * Oneof group definitions for this message. Each group defines the field
 * numbers belonging to that group. When of these fields' value is set, all
 * other fields in the group are cleared. During deserialization, if multiple
 * fields are encountered for a group, only the last value seen will be kept.
 * @private {!Array<!Array<number>>}
 * @const
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.oneofGroups_ = [[1,2]];

/**
 * @enum {number}
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.IdentifierCase = {
  IDENTIFIER_NOT_SET: 0,
  USER: 1,
  EMAIL: 2
};

/**
 * @return {proto.interface.ti.users.v1.RetrieveMaskedUserRequest.IdentifierCase}
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.prototype.getIdentifierCase = function() {
  return /** @type {proto.interface.ti.users.v1.RetrieveMaskedUserRequest.IdentifierCase} */(jspb.Message.computeOneofCase(this, proto.interface.ti.users.v1.RetrieveMaskedUserRequest.oneofGroups_[0]));
};



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.RetrieveMaskedUserRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.RetrieveMaskedUserRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
user: (f = jspb.Message.getField(msg, 1)) == null ? undefined : f,
email: (f = jspb.Message.getField(msg, 2)) == null ? undefined : f
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUserRequest}
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.RetrieveMaskedUserRequest;
  return proto.interface.ti.users.v1.RetrieveMaskedUserRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.RetrieveMaskedUserRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUserRequest}
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setUser(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setEmail(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.RetrieveMaskedUserRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.RetrieveMaskedUserRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = /** @type {string} */ (jspb.Message.getField(message, 1));
  if (f != null) {
    writer.writeString(
      1,
      f
    );
  }
  f = /** @type {string} */ (jspb.Message.getField(message, 2));
  if (f != null) {
    writer.writeString(
      2,
      f
    );
  }
};


/**
 * optional string user = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.prototype.getUser = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUserRequest} returns this
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.prototype.setUser = function(value) {
  return jspb.Message.setOneofField(this, 1, proto.interface.ti.users.v1.RetrieveMaskedUserRequest.oneofGroups_[0], value);
};


/**
 * Clears the field making it undefined.
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUserRequest} returns this
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.prototype.clearUser = function() {
  return jspb.Message.setOneofField(this, 1, proto.interface.ti.users.v1.RetrieveMaskedUserRequest.oneofGroups_[0], undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.prototype.hasUser = function() {
  return jspb.Message.getField(this, 1) != null;
};


/**
 * optional string email = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.prototype.getEmail = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUserRequest} returns this
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.prototype.setEmail = function(value) {
  return jspb.Message.setOneofField(this, 2, proto.interface.ti.users.v1.RetrieveMaskedUserRequest.oneofGroups_[0], value);
};


/**
 * Clears the field making it undefined.
 * @return {!proto.interface.ti.users.v1.RetrieveMaskedUserRequest} returns this
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.prototype.clearEmail = function() {
  return jspb.Message.setOneofField(this, 2, proto.interface.ti.users.v1.RetrieveMaskedUserRequest.oneofGroups_[0], undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.RetrieveMaskedUserRequest.prototype.hasEmail = function() {
  return jspb.Message.getField(this, 2) != null;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.MaskedUser.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.MaskedUser} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.MaskedUser.toObject = function(includeInstance, msg) {
  var f, obj = {
name: jspb.Message.getFieldWithDefault(msg, 1, ""),
createTime: (f = msg.getCreateTime()) && google_protobuf_timestamp_pb.Timestamp.toObject(includeInstance, f),
updateTime: (f = msg.getUpdateTime()) && google_protobuf_timestamp_pb.Timestamp.toObject(includeInstance, f),
maskedEmail: jspb.Message.getFieldWithDefault(msg, 4, ""),
identityProvider: jspb.Message.getFieldWithDefault(msg, 6, 0),
givenName: jspb.Message.getFieldWithDefault(msg, 7, ""),
familyName: jspb.Message.getFieldWithDefault(msg, 8, ""),
picture: jspb.Message.getFieldWithDefault(msg, 9, ""),
position: jspb.Message.getFieldWithDefault(msg, 10, ""),
education: jspb.Message.getFieldWithDefault(msg, 11, ""),
linkedinUri: jspb.Message.getFieldWithDefault(msg, 12, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.MaskedUser}
 */
proto.interface.ti.users.v1.MaskedUser.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.MaskedUser;
  return proto.interface.ti.users.v1.MaskedUser.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.MaskedUser} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.MaskedUser}
 */
proto.interface.ti.users.v1.MaskedUser.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setName(value);
      break;
    case 2:
      var value = new google_protobuf_timestamp_pb.Timestamp;
      reader.readMessage(value,google_protobuf_timestamp_pb.Timestamp.deserializeBinaryFromReader);
      msg.setCreateTime(value);
      break;
    case 3:
      var value = new google_protobuf_timestamp_pb.Timestamp;
      reader.readMessage(value,google_protobuf_timestamp_pb.Timestamp.deserializeBinaryFromReader);
      msg.setUpdateTime(value);
      break;
    case 4:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setMaskedEmail(value);
      break;
    case 6:
      var value = /** @type {!proto.interface.ti.users.v1.IdentityProvider} */ (reader.readEnum());
      msg.setIdentityProvider(value);
      break;
    case 7:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setGivenName(value);
      break;
    case 8:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setFamilyName(value);
      break;
    case 9:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPicture(value);
      break;
    case 10:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPosition(value);
      break;
    case 11:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setEducation(value);
      break;
    case 12:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setLinkedinUri(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.MaskedUser.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.MaskedUser} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.MaskedUser.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getName();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getCreateTime();
  if (f != null) {
    writer.writeMessage(
      2,
      f,
      google_protobuf_timestamp_pb.Timestamp.serializeBinaryToWriter
    );
  }
  f = message.getUpdateTime();
  if (f != null) {
    writer.writeMessage(
      3,
      f,
      google_protobuf_timestamp_pb.Timestamp.serializeBinaryToWriter
    );
  }
  f = message.getMaskedEmail();
  if (f.length > 0) {
    writer.writeString(
      4,
      f
    );
  }
  f = message.getIdentityProvider();
  if (f !== 0.0) {
    writer.writeEnum(
      6,
      f
    );
  }
  f = message.getGivenName();
  if (f.length > 0) {
    writer.writeString(
      7,
      f
    );
  }
  f = message.getFamilyName();
  if (f.length > 0) {
    writer.writeString(
      8,
      f
    );
  }
  f = message.getPicture();
  if (f.length > 0) {
    writer.writeString(
      9,
      f
    );
  }
  f = message.getPosition();
  if (f.length > 0) {
    writer.writeString(
      10,
      f
    );
  }
  f = message.getEducation();
  if (f.length > 0) {
    writer.writeString(
      11,
      f
    );
  }
  f = message.getLinkedinUri();
  if (f.length > 0) {
    writer.writeString(
      12,
      f
    );
  }
};


/**
 * optional string name = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.getName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.MaskedUser} returns this
 */
proto.interface.ti.users.v1.MaskedUser.prototype.setName = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional google.protobuf.Timestamp create_time = 2;
 * @return {?proto.google.protobuf.Timestamp}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.getCreateTime = function() {
  return /** @type{?proto.google.protobuf.Timestamp} */ (
    jspb.Message.getWrapperField(this, google_protobuf_timestamp_pb.Timestamp, 2));
};


/**
 * @param {?proto.google.protobuf.Timestamp|undefined} value
 * @return {!proto.interface.ti.users.v1.MaskedUser} returns this
*/
proto.interface.ti.users.v1.MaskedUser.prototype.setCreateTime = function(value) {
  return jspb.Message.setWrapperField(this, 2, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.MaskedUser} returns this
 */
proto.interface.ti.users.v1.MaskedUser.prototype.clearCreateTime = function() {
  return this.setCreateTime(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.hasCreateTime = function() {
  return jspb.Message.getField(this, 2) != null;
};


/**
 * optional google.protobuf.Timestamp update_time = 3;
 * @return {?proto.google.protobuf.Timestamp}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.getUpdateTime = function() {
  return /** @type{?proto.google.protobuf.Timestamp} */ (
    jspb.Message.getWrapperField(this, google_protobuf_timestamp_pb.Timestamp, 3));
};


/**
 * @param {?proto.google.protobuf.Timestamp|undefined} value
 * @return {!proto.interface.ti.users.v1.MaskedUser} returns this
*/
proto.interface.ti.users.v1.MaskedUser.prototype.setUpdateTime = function(value) {
  return jspb.Message.setWrapperField(this, 3, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.MaskedUser} returns this
 */
proto.interface.ti.users.v1.MaskedUser.prototype.clearUpdateTime = function() {
  return this.setUpdateTime(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.hasUpdateTime = function() {
  return jspb.Message.getField(this, 3) != null;
};


/**
 * optional string masked_email = 4;
 * @return {string}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.getMaskedEmail = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.MaskedUser} returns this
 */
proto.interface.ti.users.v1.MaskedUser.prototype.setMaskedEmail = function(value) {
  return jspb.Message.setProto3StringField(this, 4, value);
};


/**
 * optional IdentityProvider identity_provider = 6;
 * @return {!proto.interface.ti.users.v1.IdentityProvider}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.getIdentityProvider = function() {
  return /** @type {!proto.interface.ti.users.v1.IdentityProvider} */ (jspb.Message.getFieldWithDefault(this, 6, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.IdentityProvider} value
 * @return {!proto.interface.ti.users.v1.MaskedUser} returns this
 */
proto.interface.ti.users.v1.MaskedUser.prototype.setIdentityProvider = function(value) {
  return jspb.Message.setProto3EnumField(this, 6, value);
};


/**
 * optional string given_name = 7;
 * @return {string}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.getGivenName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 7, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.MaskedUser} returns this
 */
proto.interface.ti.users.v1.MaskedUser.prototype.setGivenName = function(value) {
  return jspb.Message.setProto3StringField(this, 7, value);
};


/**
 * optional string family_name = 8;
 * @return {string}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.getFamilyName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 8, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.MaskedUser} returns this
 */
proto.interface.ti.users.v1.MaskedUser.prototype.setFamilyName = function(value) {
  return jspb.Message.setProto3StringField(this, 8, value);
};


/**
 * optional string picture = 9;
 * @return {string}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.getPicture = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 9, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.MaskedUser} returns this
 */
proto.interface.ti.users.v1.MaskedUser.prototype.setPicture = function(value) {
  return jspb.Message.setProto3StringField(this, 9, value);
};


/**
 * optional string position = 10;
 * @return {string}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.getPosition = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 10, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.MaskedUser} returns this
 */
proto.interface.ti.users.v1.MaskedUser.prototype.setPosition = function(value) {
  return jspb.Message.setProto3StringField(this, 10, value);
};


/**
 * optional string education = 11;
 * @return {string}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.getEducation = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 11, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.MaskedUser} returns this
 */
proto.interface.ti.users.v1.MaskedUser.prototype.setEducation = function(value) {
  return jspb.Message.setProto3StringField(this, 11, value);
};


/**
 * optional string linkedin_uri = 12;
 * @return {string}
 */
proto.interface.ti.users.v1.MaskedUser.prototype.getLinkedinUri = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 12, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.MaskedUser} returns this
 */
proto.interface.ti.users.v1.MaskedUser.prototype.setLinkedinUri = function(value) {
  return jspb.Message.setProto3StringField(this, 12, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.EditUserInfoRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.EditUserInfoRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.EditUserInfoRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
user: jspb.Message.getFieldWithDefault(msg, 1, ""),
givenName: jspb.Message.getFieldWithDefault(msg, 2, ""),
familyName: jspb.Message.getFieldWithDefault(msg, 3, ""),
picture: jspb.Message.getFieldWithDefault(msg, 4, ""),
contactNumber: jspb.Message.getFieldWithDefault(msg, 5, ""),
position: jspb.Message.getFieldWithDefault(msg, 6, ""),
education: jspb.Message.getFieldWithDefault(msg, 7, ""),
linkedinUri: jspb.Message.getFieldWithDefault(msg, 8, ""),
updateMask: (f = msg.getUpdateMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.EditUserInfoRequest}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.EditUserInfoRequest;
  return proto.interface.ti.users.v1.EditUserInfoRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.EditUserInfoRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.EditUserInfoRequest}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setUser(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setGivenName(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setFamilyName(value);
      break;
    case 4:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPicture(value);
      break;
    case 5:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setContactNumber(value);
      break;
    case 6:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPosition(value);
      break;
    case 7:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setEducation(value);
      break;
    case 8:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setLinkedinUri(value);
      break;
    case 99:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setUpdateMask(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.EditUserInfoRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.EditUserInfoRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.EditUserInfoRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getUser();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getGivenName();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
  f = message.getFamilyName();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
  f = message.getPicture();
  if (f.length > 0) {
    writer.writeString(
      4,
      f
    );
  }
  f = message.getContactNumber();
  if (f.length > 0) {
    writer.writeString(
      5,
      f
    );
  }
  f = message.getPosition();
  if (f.length > 0) {
    writer.writeString(
      6,
      f
    );
  }
  f = message.getEducation();
  if (f.length > 0) {
    writer.writeString(
      7,
      f
    );
  }
  f = message.getLinkedinUri();
  if (f.length > 0) {
    writer.writeString(
      8,
      f
    );
  }
  f = message.getUpdateMask();
  if (f != null) {
    writer.writeMessage(
      99,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
};


/**
 * optional string user = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.getUser = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditUserInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.setUser = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional string given_name = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.getGivenName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditUserInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.setGivenName = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};


/**
 * optional string family_name = 3;
 * @return {string}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.getFamilyName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditUserInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.setFamilyName = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};


/**
 * optional string picture = 4;
 * @return {string}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.getPicture = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditUserInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.setPicture = function(value) {
  return jspb.Message.setProto3StringField(this, 4, value);
};


/**
 * optional string contact_number = 5;
 * @return {string}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.getContactNumber = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditUserInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.setContactNumber = function(value) {
  return jspb.Message.setProto3StringField(this, 5, value);
};


/**
 * optional string position = 6;
 * @return {string}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.getPosition = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 6, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditUserInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.setPosition = function(value) {
  return jspb.Message.setProto3StringField(this, 6, value);
};


/**
 * optional string education = 7;
 * @return {string}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.getEducation = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 7, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditUserInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.setEducation = function(value) {
  return jspb.Message.setProto3StringField(this, 7, value);
};


/**
 * optional string linkedin_uri = 8;
 * @return {string}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.getLinkedinUri = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 8, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditUserInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.setLinkedinUri = function(value) {
  return jspb.Message.setProto3StringField(this, 8, value);
};


/**
 * optional google.protobuf.FieldMask update_mask = 99;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.getUpdateMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 99));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.EditUserInfoRequest} returns this
*/
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.setUpdateMask = function(value) {
  return jspb.Message.setWrapperField(this, 99, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.EditUserInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.clearUpdateMask = function() {
  return this.setUpdateMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.EditUserInfoRequest.prototype.hasUpdateMask = function() {
  return jspb.Message.getField(this, 99) != null;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.EditUserMetadataRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.EditUserMetadataRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.EditUserMetadataRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.EditUserMetadataRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
user: jspb.Message.getFieldWithDefault(msg, 1, ""),
metadata: (f = msg.getMetadata()) && google_protobuf_any_pb.Any.toObject(includeInstance, f)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.EditUserMetadataRequest}
 */
proto.interface.ti.users.v1.EditUserMetadataRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.EditUserMetadataRequest;
  return proto.interface.ti.users.v1.EditUserMetadataRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.EditUserMetadataRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.EditUserMetadataRequest}
 */
proto.interface.ti.users.v1.EditUserMetadataRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setUser(value);
      break;
    case 2:
      var value = new google_protobuf_any_pb.Any;
      reader.readMessage(value,google_protobuf_any_pb.Any.deserializeBinaryFromReader);
      msg.setMetadata(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.EditUserMetadataRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.EditUserMetadataRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.EditUserMetadataRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.EditUserMetadataRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getUser();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getMetadata();
  if (f != null) {
    writer.writeMessage(
      2,
      f,
      google_protobuf_any_pb.Any.serializeBinaryToWriter
    );
  }
};


/**
 * optional string user = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.EditUserMetadataRequest.prototype.getUser = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditUserMetadataRequest} returns this
 */
proto.interface.ti.users.v1.EditUserMetadataRequest.prototype.setUser = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional google.protobuf.Any metadata = 2;
 * @return {?proto.google.protobuf.Any}
 */
proto.interface.ti.users.v1.EditUserMetadataRequest.prototype.getMetadata = function() {
  return /** @type{?proto.google.protobuf.Any} */ (
    jspb.Message.getWrapperField(this, google_protobuf_any_pb.Any, 2));
};


/**
 * @param {?proto.google.protobuf.Any|undefined} value
 * @return {!proto.interface.ti.users.v1.EditUserMetadataRequest} returns this
*/
proto.interface.ti.users.v1.EditUserMetadataRequest.prototype.setMetadata = function(value) {
  return jspb.Message.setWrapperField(this, 2, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.EditUserMetadataRequest} returns this
 */
proto.interface.ti.users.v1.EditUserMetadataRequest.prototype.clearMetadata = function() {
  return this.setMetadata(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.EditUserMetadataRequest.prototype.hasMetadata = function() {
  return jspb.Message.getField(this, 2) != null;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.RetrieveMyUserRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.RetrieveMyUserRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.RetrieveMyUserRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RetrieveMyUserRequest.toObject = function(includeInstance, msg) {
  var f, obj = {

  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.RetrieveMyUserRequest}
 */
proto.interface.ti.users.v1.RetrieveMyUserRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.RetrieveMyUserRequest;
  return proto.interface.ti.users.v1.RetrieveMyUserRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.RetrieveMyUserRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.RetrieveMyUserRequest}
 */
proto.interface.ti.users.v1.RetrieveMyUserRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.RetrieveMyUserRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.RetrieveMyUserRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.RetrieveMyUserRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RetrieveMyUserRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.EditMyInfoRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.EditMyInfoRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.EditMyInfoRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
givenName: jspb.Message.getFieldWithDefault(msg, 1, ""),
familyName: jspb.Message.getFieldWithDefault(msg, 2, ""),
picture: jspb.Message.getFieldWithDefault(msg, 3, ""),
contactNumber: jspb.Message.getFieldWithDefault(msg, 4, ""),
position: jspb.Message.getFieldWithDefault(msg, 5, ""),
education: jspb.Message.getFieldWithDefault(msg, 6, ""),
linkedinUri: jspb.Message.getFieldWithDefault(msg, 7, ""),
updateMask: (f = msg.getUpdateMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.EditMyInfoRequest}
 */
proto.interface.ti.users.v1.EditMyInfoRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.EditMyInfoRequest;
  return proto.interface.ti.users.v1.EditMyInfoRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.EditMyInfoRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.EditMyInfoRequest}
 */
proto.interface.ti.users.v1.EditMyInfoRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setGivenName(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setFamilyName(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPicture(value);
      break;
    case 4:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setContactNumber(value);
      break;
    case 5:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPosition(value);
      break;
    case 6:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setEducation(value);
      break;
    case 7:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setLinkedinUri(value);
      break;
    case 10:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setUpdateMask(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.EditMyInfoRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.EditMyInfoRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.EditMyInfoRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getGivenName();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getFamilyName();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
  f = message.getPicture();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
  f = message.getContactNumber();
  if (f.length > 0) {
    writer.writeString(
      4,
      f
    );
  }
  f = message.getPosition();
  if (f.length > 0) {
    writer.writeString(
      5,
      f
    );
  }
  f = message.getEducation();
  if (f.length > 0) {
    writer.writeString(
      6,
      f
    );
  }
  f = message.getLinkedinUri();
  if (f.length > 0) {
    writer.writeString(
      7,
      f
    );
  }
  f = message.getUpdateMask();
  if (f != null) {
    writer.writeMessage(
      10,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
};


/**
 * optional string given_name = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.getGivenName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditMyInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.setGivenName = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional string family_name = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.getFamilyName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditMyInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.setFamilyName = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};


/**
 * optional string picture = 3;
 * @return {string}
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.getPicture = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditMyInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.setPicture = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};


/**
 * optional string contact_number = 4;
 * @return {string}
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.getContactNumber = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditMyInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.setContactNumber = function(value) {
  return jspb.Message.setProto3StringField(this, 4, value);
};


/**
 * optional string position = 5;
 * @return {string}
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.getPosition = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditMyInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.setPosition = function(value) {
  return jspb.Message.setProto3StringField(this, 5, value);
};


/**
 * optional string education = 6;
 * @return {string}
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.getEducation = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 6, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditMyInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.setEducation = function(value) {
  return jspb.Message.setProto3StringField(this, 6, value);
};


/**
 * optional string linkedin_uri = 7;
 * @return {string}
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.getLinkedinUri = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 7, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.EditMyInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.setLinkedinUri = function(value) {
  return jspb.Message.setProto3StringField(this, 7, value);
};


/**
 * optional google.protobuf.FieldMask update_mask = 10;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.getUpdateMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 10));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.EditMyInfoRequest} returns this
*/
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.setUpdateMask = function(value) {
  return jspb.Message.setWrapperField(this, 10, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.EditMyInfoRequest} returns this
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.clearUpdateMask = function() {
  return this.setUpdateMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.EditMyInfoRequest.prototype.hasUpdateMask = function() {
  return jspb.Message.getField(this, 10) != null;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.EditMyMetadataRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.EditMyMetadataRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.EditMyMetadataRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.EditMyMetadataRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
metadata: (f = msg.getMetadata()) && google_protobuf_any_pb.Any.toObject(includeInstance, f)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.EditMyMetadataRequest}
 */
proto.interface.ti.users.v1.EditMyMetadataRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.EditMyMetadataRequest;
  return proto.interface.ti.users.v1.EditMyMetadataRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.EditMyMetadataRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.EditMyMetadataRequest}
 */
proto.interface.ti.users.v1.EditMyMetadataRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new google_protobuf_any_pb.Any;
      reader.readMessage(value,google_protobuf_any_pb.Any.deserializeBinaryFromReader);
      msg.setMetadata(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.EditMyMetadataRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.EditMyMetadataRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.EditMyMetadataRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.EditMyMetadataRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getMetadata();
  if (f != null) {
    writer.writeMessage(
      1,
      f,
      google_protobuf_any_pb.Any.serializeBinaryToWriter
    );
  }
};


/**
 * optional google.protobuf.Any metadata = 1;
 * @return {?proto.google.protobuf.Any}
 */
proto.interface.ti.users.v1.EditMyMetadataRequest.prototype.getMetadata = function() {
  return /** @type{?proto.google.protobuf.Any} */ (
    jspb.Message.getWrapperField(this, google_protobuf_any_pb.Any, 1));
};


/**
 * @param {?proto.google.protobuf.Any|undefined} value
 * @return {!proto.interface.ti.users.v1.EditMyMetadataRequest} returns this
*/
proto.interface.ti.users.v1.EditMyMetadataRequest.prototype.setMetadata = function(value) {
  return jspb.Message.setWrapperField(this, 1, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.EditMyMetadataRequest} returns this
 */
proto.interface.ti.users.v1.EditMyMetadataRequest.prototype.clearMetadata = function() {
  return this.setMetadata(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.EditMyMetadataRequest.prototype.hasMetadata = function() {
  return jspb.Message.getField(this, 1) != null;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.RemoveMyUserRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.RemoveMyUserRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.RemoveMyUserRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RemoveMyUserRequest.toObject = function(includeInstance, msg) {
  var f, obj = {

  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.RemoveMyUserRequest}
 */
proto.interface.ti.users.v1.RemoveMyUserRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.RemoveMyUserRequest;
  return proto.interface.ti.users.v1.RemoveMyUserRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.RemoveMyUserRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.RemoveMyUserRequest}
 */
proto.interface.ti.users.v1.RemoveMyUserRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.RemoveMyUserRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.RemoveMyUserRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.RemoveMyUserRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RemoveMyUserRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.SyncToGoogleGroupRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.SyncToGoogleGroupRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.SyncToGoogleGroupRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.SyncToGoogleGroupRequest.toObject = function(includeInstance, msg) {
  var f, obj = {

  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.SyncToGoogleGroupRequest}
 */
proto.interface.ti.users.v1.SyncToGoogleGroupRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.SyncToGoogleGroupRequest;
  return proto.interface.ti.users.v1.SyncToGoogleGroupRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.SyncToGoogleGroupRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.SyncToGoogleGroupRequest}
 */
proto.interface.ti.users.v1.SyncToGoogleGroupRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.SyncToGoogleGroupRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.SyncToGoogleGroupRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.SyncToGoogleGroupRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.SyncToGoogleGroupRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.SyncToGoogleGroupResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.SyncToGoogleGroupResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.SyncToGoogleGroupResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.SyncToGoogleGroupResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
nrAdded: jspb.Message.getFieldWithDefault(msg, 1, 0),
nrRemoved: jspb.Message.getFieldWithDefault(msg, 2, 0)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.SyncToGoogleGroupResponse}
 */
proto.interface.ti.users.v1.SyncToGoogleGroupResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.SyncToGoogleGroupResponse;
  return proto.interface.ti.users.v1.SyncToGoogleGroupResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.SyncToGoogleGroupResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.SyncToGoogleGroupResponse}
 */
proto.interface.ti.users.v1.SyncToGoogleGroupResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {number} */ (reader.readInt32());
      msg.setNrAdded(value);
      break;
    case 2:
      var value = /** @type {number} */ (reader.readInt32());
      msg.setNrRemoved(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.SyncToGoogleGroupResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.SyncToGoogleGroupResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.SyncToGoogleGroupResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.SyncToGoogleGroupResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getNrAdded();
  if (f !== 0) {
    writer.writeInt32(
      1,
      f
    );
  }
  f = message.getNrRemoved();
  if (f !== 0) {
    writer.writeInt32(
      2,
      f
    );
  }
};


/**
 * optional int32 nr_added = 1;
 * @return {number}
 */
proto.interface.ti.users.v1.SyncToGoogleGroupResponse.prototype.getNrAdded = function() {
  return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};


/**
 * @param {number} value
 * @return {!proto.interface.ti.users.v1.SyncToGoogleGroupResponse} returns this
 */
proto.interface.ti.users.v1.SyncToGoogleGroupResponse.prototype.setNrAdded = function(value) {
  return jspb.Message.setProto3IntField(this, 1, value);
};


/**
 * optional int32 nr_removed = 2;
 * @return {number}
 */
proto.interface.ti.users.v1.SyncToGoogleGroupResponse.prototype.getNrRemoved = function() {
  return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};


/**
 * @param {number} value
 * @return {!proto.interface.ti.users.v1.SyncToGoogleGroupResponse} returns this
 */
proto.interface.ti.users.v1.SyncToGoogleGroupResponse.prototype.setNrRemoved = function(value) {
  return jspb.Message.setProto3IntField(this, 2, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.SetUserPictureRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.SetUserPictureRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.SetUserPictureRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.SetUserPictureRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
user: jspb.Message.getFieldWithDefault(msg, 1, ""),
data: msg.getData_asB64(),
mimeType: jspb.Message.getFieldWithDefault(msg, 3, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.SetUserPictureRequest}
 */
proto.interface.ti.users.v1.SetUserPictureRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.SetUserPictureRequest;
  return proto.interface.ti.users.v1.SetUserPictureRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.SetUserPictureRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.SetUserPictureRequest}
 */
proto.interface.ti.users.v1.SetUserPictureRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setUser(value);
      break;
    case 2:
      var value = /** @type {!Uint8Array} */ (reader.readBytes());
      msg.setData(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setMimeType(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.SetUserPictureRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.SetUserPictureRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.SetUserPictureRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.SetUserPictureRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getUser();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getData_asU8();
  if (f.length > 0) {
    writer.writeBytes(
      2,
      f
    );
  }
  f = message.getMimeType();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
};


/**
 * optional string user = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.SetUserPictureRequest.prototype.getUser = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.SetUserPictureRequest} returns this
 */
proto.interface.ti.users.v1.SetUserPictureRequest.prototype.setUser = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional bytes data = 2;
 * @return {!(string|Uint8Array)}
 */
proto.interface.ti.users.v1.SetUserPictureRequest.prototype.getData = function() {
  return /** @type {!(string|Uint8Array)} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * optional bytes data = 2;
 * This is a type-conversion wrapper around `getData()`
 * @return {string}
 */
proto.interface.ti.users.v1.SetUserPictureRequest.prototype.getData_asB64 = function() {
  return /** @type {string} */ (jspb.Message.bytesAsB64(
      this.getData()));
};


/**
 * optional bytes data = 2;
 * Note that Uint8Array is not supported on all browsers.
 * @see http://caniuse.com/Uint8Array
 * This is a type-conversion wrapper around `getData()`
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.SetUserPictureRequest.prototype.getData_asU8 = function() {
  return /** @type {!Uint8Array} */ (jspb.Message.bytesAsU8(
      this.getData()));
};


/**
 * @param {!(string|Uint8Array)} value
 * @return {!proto.interface.ti.users.v1.SetUserPictureRequest} returns this
 */
proto.interface.ti.users.v1.SetUserPictureRequest.prototype.setData = function(value) {
  return jspb.Message.setProto3BytesField(this, 2, value);
};


/**
 * optional string mime_type = 3;
 * @return {string}
 */
proto.interface.ti.users.v1.SetUserPictureRequest.prototype.getMimeType = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.SetUserPictureRequest} returns this
 */
proto.interface.ti.users.v1.SetUserPictureRequest.prototype.setMimeType = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.SetUserPictureResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.SetUserPictureResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.SetUserPictureResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.SetUserPictureResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
publicUri: jspb.Message.getFieldWithDefault(msg, 1, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.SetUserPictureResponse}
 */
proto.interface.ti.users.v1.SetUserPictureResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.SetUserPictureResponse;
  return proto.interface.ti.users.v1.SetUserPictureResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.SetUserPictureResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.SetUserPictureResponse}
 */
proto.interface.ti.users.v1.SetUserPictureResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPublicUri(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.SetUserPictureResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.SetUserPictureResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.SetUserPictureResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.SetUserPictureResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getPublicUri();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
};


/**
 * optional string public_uri = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.SetUserPictureResponse.prototype.getPublicUri = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.SetUserPictureResponse} returns this
 */
proto.interface.ti.users.v1.SetUserPictureResponse.prototype.setPublicUri = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.CreateConnectorRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.CreateConnectorRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.CreateConnectorRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.CreateConnectorRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
parent: jspb.Message.getFieldWithDefault(msg, 1, ""),
connector: (f = msg.getConnector()) && proto.interface.ti.users.v1.Connector.toObject(includeInstance, f),
connectorId: jspb.Message.getFieldWithDefault(msg, 3, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.CreateConnectorRequest}
 */
proto.interface.ti.users.v1.CreateConnectorRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.CreateConnectorRequest;
  return proto.interface.ti.users.v1.CreateConnectorRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.CreateConnectorRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.CreateConnectorRequest}
 */
proto.interface.ti.users.v1.CreateConnectorRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setParent(value);
      break;
    case 2:
      var value = new proto.interface.ti.users.v1.Connector;
      reader.readMessage(value,proto.interface.ti.users.v1.Connector.deserializeBinaryFromReader);
      msg.setConnector(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setConnectorId(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.CreateConnectorRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.CreateConnectorRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.CreateConnectorRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.CreateConnectorRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getParent();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getConnector();
  if (f != null) {
    writer.writeMessage(
      2,
      f,
      proto.interface.ti.users.v1.Connector.serializeBinaryToWriter
    );
  }
  f = message.getConnectorId();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
};


/**
 * optional string parent = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.CreateConnectorRequest.prototype.getParent = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.CreateConnectorRequest} returns this
 */
proto.interface.ti.users.v1.CreateConnectorRequest.prototype.setParent = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional Connector connector = 2;
 * @return {?proto.interface.ti.users.v1.Connector}
 */
proto.interface.ti.users.v1.CreateConnectorRequest.prototype.getConnector = function() {
  return /** @type{?proto.interface.ti.users.v1.Connector} */ (
    jspb.Message.getWrapperField(this, proto.interface.ti.users.v1.Connector, 2));
};


/**
 * @param {?proto.interface.ti.users.v1.Connector|undefined} value
 * @return {!proto.interface.ti.users.v1.CreateConnectorRequest} returns this
*/
proto.interface.ti.users.v1.CreateConnectorRequest.prototype.setConnector = function(value) {
  return jspb.Message.setWrapperField(this, 2, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.CreateConnectorRequest} returns this
 */
proto.interface.ti.users.v1.CreateConnectorRequest.prototype.clearConnector = function() {
  return this.setConnector(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.CreateConnectorRequest.prototype.hasConnector = function() {
  return jspb.Message.getField(this, 2) != null;
};


/**
 * optional string connector_id = 3;
 * @return {string}
 */
proto.interface.ti.users.v1.CreateConnectorRequest.prototype.getConnectorId = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.CreateConnectorRequest} returns this
 */
proto.interface.ti.users.v1.CreateConnectorRequest.prototype.setConnectorId = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.GetConnectorRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.GetConnectorRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.GetConnectorRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.GetConnectorRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
name: jspb.Message.getFieldWithDefault(msg, 1, ""),
view: jspb.Message.getFieldWithDefault(msg, 2, 0),
readMask: (f = msg.getReadMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.GetConnectorRequest}
 */
proto.interface.ti.users.v1.GetConnectorRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.GetConnectorRequest;
  return proto.interface.ti.users.v1.GetConnectorRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.GetConnectorRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.GetConnectorRequest}
 */
proto.interface.ti.users.v1.GetConnectorRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setName(value);
      break;
    case 2:
      var value = /** @type {!proto.interface.ti.users.v1.ConnectorView} */ (reader.readEnum());
      msg.setView(value);
      break;
    case 3:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setReadMask(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.GetConnectorRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.GetConnectorRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.GetConnectorRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.GetConnectorRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getName();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getView();
  if (f !== 0.0) {
    writer.writeEnum(
      2,
      f
    );
  }
  f = message.getReadMask();
  if (f != null) {
    writer.writeMessage(
      3,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
};


/**
 * optional string name = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.GetConnectorRequest.prototype.getName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.GetConnectorRequest} returns this
 */
proto.interface.ti.users.v1.GetConnectorRequest.prototype.setName = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional ConnectorView view = 2;
 * @return {!proto.interface.ti.users.v1.ConnectorView}
 */
proto.interface.ti.users.v1.GetConnectorRequest.prototype.getView = function() {
  return /** @type {!proto.interface.ti.users.v1.ConnectorView} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.ConnectorView} value
 * @return {!proto.interface.ti.users.v1.GetConnectorRequest} returns this
 */
proto.interface.ti.users.v1.GetConnectorRequest.prototype.setView = function(value) {
  return jspb.Message.setProto3EnumField(this, 2, value);
};


/**
 * optional google.protobuf.FieldMask read_mask = 3;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.GetConnectorRequest.prototype.getReadMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 3));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.GetConnectorRequest} returns this
*/
proto.interface.ti.users.v1.GetConnectorRequest.prototype.setReadMask = function(value) {
  return jspb.Message.setWrapperField(this, 3, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.GetConnectorRequest} returns this
 */
proto.interface.ti.users.v1.GetConnectorRequest.prototype.clearReadMask = function() {
  return this.setReadMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.GetConnectorRequest.prototype.hasReadMask = function() {
  return jspb.Message.getField(this, 3) != null;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.UpdateConnectorRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.UpdateConnectorRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
connector: (f = msg.getConnector()) && proto.interface.ti.users.v1.Connector.toObject(includeInstance, f),
updateMask: (f = msg.getUpdateMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f),
allowMissing: jspb.Message.getBooleanFieldWithDefault(msg, 3, false)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.UpdateConnectorRequest}
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.UpdateConnectorRequest;
  return proto.interface.ti.users.v1.UpdateConnectorRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.UpdateConnectorRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.UpdateConnectorRequest}
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.Connector;
      reader.readMessage(value,proto.interface.ti.users.v1.Connector.deserializeBinaryFromReader);
      msg.setConnector(value);
      break;
    case 2:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setUpdateMask(value);
      break;
    case 3:
      var value = /** @type {boolean} */ (reader.readBool());
      msg.setAllowMissing(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.UpdateConnectorRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.UpdateConnectorRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getConnector();
  if (f != null) {
    writer.writeMessage(
      1,
      f,
      proto.interface.ti.users.v1.Connector.serializeBinaryToWriter
    );
  }
  f = message.getUpdateMask();
  if (f != null) {
    writer.writeMessage(
      2,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
  f = message.getAllowMissing();
  if (f) {
    writer.writeBool(
      3,
      f
    );
  }
};


/**
 * optional Connector connector = 1;
 * @return {?proto.interface.ti.users.v1.Connector}
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.prototype.getConnector = function() {
  return /** @type{?proto.interface.ti.users.v1.Connector} */ (
    jspb.Message.getWrapperField(this, proto.interface.ti.users.v1.Connector, 1));
};


/**
 * @param {?proto.interface.ti.users.v1.Connector|undefined} value
 * @return {!proto.interface.ti.users.v1.UpdateConnectorRequest} returns this
*/
proto.interface.ti.users.v1.UpdateConnectorRequest.prototype.setConnector = function(value) {
  return jspb.Message.setWrapperField(this, 1, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.UpdateConnectorRequest} returns this
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.prototype.clearConnector = function() {
  return this.setConnector(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.prototype.hasConnector = function() {
  return jspb.Message.getField(this, 1) != null;
};


/**
 * optional google.protobuf.FieldMask update_mask = 2;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.prototype.getUpdateMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 2));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.UpdateConnectorRequest} returns this
*/
proto.interface.ti.users.v1.UpdateConnectorRequest.prototype.setUpdateMask = function(value) {
  return jspb.Message.setWrapperField(this, 2, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.UpdateConnectorRequest} returns this
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.prototype.clearUpdateMask = function() {
  return this.setUpdateMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.prototype.hasUpdateMask = function() {
  return jspb.Message.getField(this, 2) != null;
};


/**
 * optional bool allow_missing = 3;
 * @return {boolean}
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.prototype.getAllowMissing = function() {
  return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 3, false));
};


/**
 * @param {boolean} value
 * @return {!proto.interface.ti.users.v1.UpdateConnectorRequest} returns this
 */
proto.interface.ti.users.v1.UpdateConnectorRequest.prototype.setAllowMissing = function(value) {
  return jspb.Message.setProto3BooleanField(this, 3, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.DeleteConnectorRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.DeleteConnectorRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.DeleteConnectorRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.DeleteConnectorRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
name: jspb.Message.getFieldWithDefault(msg, 1, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.DeleteConnectorRequest}
 */
proto.interface.ti.users.v1.DeleteConnectorRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.DeleteConnectorRequest;
  return proto.interface.ti.users.v1.DeleteConnectorRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.DeleteConnectorRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.DeleteConnectorRequest}
 */
proto.interface.ti.users.v1.DeleteConnectorRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setName(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.DeleteConnectorRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.DeleteConnectorRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.DeleteConnectorRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.DeleteConnectorRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getName();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
};


/**
 * optional string name = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.DeleteConnectorRequest.prototype.getName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.DeleteConnectorRequest} returns this
 */
proto.interface.ti.users.v1.DeleteConnectorRequest.prototype.setName = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.UndeleteConnectorRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.UndeleteConnectorRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.UndeleteConnectorRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.UndeleteConnectorRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
name: jspb.Message.getFieldWithDefault(msg, 1, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.UndeleteConnectorRequest}
 */
proto.interface.ti.users.v1.UndeleteConnectorRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.UndeleteConnectorRequest;
  return proto.interface.ti.users.v1.UndeleteConnectorRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.UndeleteConnectorRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.UndeleteConnectorRequest}
 */
proto.interface.ti.users.v1.UndeleteConnectorRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setName(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.UndeleteConnectorRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.UndeleteConnectorRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.UndeleteConnectorRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.UndeleteConnectorRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getName();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
};


/**
 * optional string name = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.UndeleteConnectorRequest.prototype.getName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.UndeleteConnectorRequest} returns this
 */
proto.interface.ti.users.v1.UndeleteConnectorRequest.prototype.setName = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.ListConnectorsRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.ListConnectorsRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListConnectorsRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
parent: jspb.Message.getFieldWithDefault(msg, 1, ""),
pageSize: jspb.Message.getFieldWithDefault(msg, 2, 0),
pageToken: jspb.Message.getFieldWithDefault(msg, 3, ""),
view: jspb.Message.getFieldWithDefault(msg, 4, 0),
readMask: (f = msg.getReadMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f),
filter: jspb.Message.getFieldWithDefault(msg, 6, ""),
orderBy: jspb.Message.getFieldWithDefault(msg, 7, ""),
showDeleted: jspb.Message.getBooleanFieldWithDefault(msg, 8, false)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.ListConnectorsRequest}
 */
proto.interface.ti.users.v1.ListConnectorsRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.ListConnectorsRequest;
  return proto.interface.ti.users.v1.ListConnectorsRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.ListConnectorsRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.ListConnectorsRequest}
 */
proto.interface.ti.users.v1.ListConnectorsRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setParent(value);
      break;
    case 2:
      var value = /** @type {number} */ (reader.readInt32());
      msg.setPageSize(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setPageToken(value);
      break;
    case 4:
      var value = /** @type {!proto.interface.ti.users.v1.ConnectorView} */ (reader.readEnum());
      msg.setView(value);
      break;
    case 5:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setReadMask(value);
      break;
    case 6:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setFilter(value);
      break;
    case 7:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setOrderBy(value);
      break;
    case 8:
      var value = /** @type {boolean} */ (reader.readBool());
      msg.setShowDeleted(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.ListConnectorsRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.ListConnectorsRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListConnectorsRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getParent();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getPageSize();
  if (f !== 0) {
    writer.writeInt32(
      2,
      f
    );
  }
  f = message.getPageToken();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
  f = message.getView();
  if (f !== 0.0) {
    writer.writeEnum(
      4,
      f
    );
  }
  f = message.getReadMask();
  if (f != null) {
    writer.writeMessage(
      5,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
  f = message.getFilter();
  if (f.length > 0) {
    writer.writeString(
      6,
      f
    );
  }
  f = message.getOrderBy();
  if (f.length > 0) {
    writer.writeString(
      7,
      f
    );
  }
  f = message.getShowDeleted();
  if (f) {
    writer.writeBool(
      8,
      f
    );
  }
};


/**
 * optional string parent = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.getParent = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ListConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.setParent = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional int32 page_size = 2;
 * @return {number}
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.getPageSize = function() {
  return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};


/**
 * @param {number} value
 * @return {!proto.interface.ti.users.v1.ListConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.setPageSize = function(value) {
  return jspb.Message.setProto3IntField(this, 2, value);
};


/**
 * optional string page_token = 3;
 * @return {string}
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.getPageToken = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ListConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.setPageToken = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};


/**
 * optional ConnectorView view = 4;
 * @return {!proto.interface.ti.users.v1.ConnectorView}
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.getView = function() {
  return /** @type {!proto.interface.ti.users.v1.ConnectorView} */ (jspb.Message.getFieldWithDefault(this, 4, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.ConnectorView} value
 * @return {!proto.interface.ti.users.v1.ListConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.setView = function(value) {
  return jspb.Message.setProto3EnumField(this, 4, value);
};


/**
 * optional google.protobuf.FieldMask read_mask = 5;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.getReadMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 5));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.ListConnectorsRequest} returns this
*/
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.setReadMask = function(value) {
  return jspb.Message.setWrapperField(this, 5, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.ListConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.clearReadMask = function() {
  return this.setReadMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.hasReadMask = function() {
  return jspb.Message.getField(this, 5) != null;
};


/**
 * optional string filter = 6;
 * @return {string}
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.getFilter = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 6, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ListConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.setFilter = function(value) {
  return jspb.Message.setProto3StringField(this, 6, value);
};


/**
 * optional string order_by = 7;
 * @return {string}
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.getOrderBy = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 7, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ListConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.setOrderBy = function(value) {
  return jspb.Message.setProto3StringField(this, 7, value);
};


/**
 * optional bool show_deleted = 8;
 * @return {boolean}
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.getShowDeleted = function() {
  return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 8, false));
};


/**
 * @param {boolean} value
 * @return {!proto.interface.ti.users.v1.ListConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.ListConnectorsRequest.prototype.setShowDeleted = function(value) {
  return jspb.Message.setProto3BooleanField(this, 8, value);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.ListConnectorsResponse.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.ListConnectorsResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.ListConnectorsResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.ListConnectorsResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListConnectorsResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
connectorsList: jspb.Message.toObjectList(msg.getConnectorsList(),
    proto.interface.ti.users.v1.Connector.toObject, includeInstance),
nextPageToken: jspb.Message.getFieldWithDefault(msg, 2, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.ListConnectorsResponse}
 */
proto.interface.ti.users.v1.ListConnectorsResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.ListConnectorsResponse;
  return proto.interface.ti.users.v1.ListConnectorsResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.ListConnectorsResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.ListConnectorsResponse}
 */
proto.interface.ti.users.v1.ListConnectorsResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.Connector;
      reader.readMessage(value,proto.interface.ti.users.v1.Connector.deserializeBinaryFromReader);
      msg.addConnectors(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setNextPageToken(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.ListConnectorsResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.ListConnectorsResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.ListConnectorsResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListConnectorsResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getConnectorsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.Connector.serializeBinaryToWriter
    );
  }
  f = message.getNextPageToken();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
};


/**
 * repeated Connector connectors = 1;
 * @return {!Array<!proto.interface.ti.users.v1.Connector>}
 */
proto.interface.ti.users.v1.ListConnectorsResponse.prototype.getConnectorsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.Connector>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.Connector, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.Connector>} value
 * @return {!proto.interface.ti.users.v1.ListConnectorsResponse} returns this
*/
proto.interface.ti.users.v1.ListConnectorsResponse.prototype.setConnectorsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.Connector=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.Connector}
 */
proto.interface.ti.users.v1.ListConnectorsResponse.prototype.addConnectors = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.Connector, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.ListConnectorsResponse} returns this
 */
proto.interface.ti.users.v1.ListConnectorsResponse.prototype.clearConnectorsList = function() {
  return this.setConnectorsList([]);
};


/**
 * optional string next_page_token = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.ListConnectorsResponse.prototype.getNextPageToken = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ListConnectorsResponse} returns this
 */
proto.interface.ti.users.v1.ListConnectorsResponse.prototype.setNextPageToken = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchCreateConnectorsRequest.repeatedFields_ = [2];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchCreateConnectorsRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchCreateConnectorsRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchCreateConnectorsRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchCreateConnectorsRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
parent: jspb.Message.getFieldWithDefault(msg, 1, ""),
requestsList: jspb.Message.toObjectList(msg.getRequestsList(),
    proto.interface.ti.users.v1.CreateConnectorRequest.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchCreateConnectorsRequest}
 */
proto.interface.ti.users.v1.BatchCreateConnectorsRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchCreateConnectorsRequest;
  return proto.interface.ti.users.v1.BatchCreateConnectorsRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchCreateConnectorsRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchCreateConnectorsRequest}
 */
proto.interface.ti.users.v1.BatchCreateConnectorsRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setParent(value);
      break;
    case 2:
      var value = new proto.interface.ti.users.v1.CreateConnectorRequest;
      reader.readMessage(value,proto.interface.ti.users.v1.CreateConnectorRequest.deserializeBinaryFromReader);
      msg.addRequests(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchCreateConnectorsRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchCreateConnectorsRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchCreateConnectorsRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchCreateConnectorsRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getParent();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getRequestsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      2,
      f,
      proto.interface.ti.users.v1.CreateConnectorRequest.serializeBinaryToWriter
    );
  }
};


/**
 * optional string parent = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.BatchCreateConnectorsRequest.prototype.getParent = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.BatchCreateConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchCreateConnectorsRequest.prototype.setParent = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * repeated CreateConnectorRequest requests = 2;
 * @return {!Array<!proto.interface.ti.users.v1.CreateConnectorRequest>}
 */
proto.interface.ti.users.v1.BatchCreateConnectorsRequest.prototype.getRequestsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.CreateConnectorRequest>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.CreateConnectorRequest, 2));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.CreateConnectorRequest>} value
 * @return {!proto.interface.ti.users.v1.BatchCreateConnectorsRequest} returns this
*/
proto.interface.ti.users.v1.BatchCreateConnectorsRequest.prototype.setRequestsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 2, value);
};


/**
 * @param {!proto.interface.ti.users.v1.CreateConnectorRequest=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.CreateConnectorRequest}
 */
proto.interface.ti.users.v1.BatchCreateConnectorsRequest.prototype.addRequests = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 2, opt_value, proto.interface.ti.users.v1.CreateConnectorRequest, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchCreateConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchCreateConnectorsRequest.prototype.clearRequestsList = function() {
  return this.setRequestsList([]);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchCreateConnectorsResponse.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchCreateConnectorsResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchCreateConnectorsResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchCreateConnectorsResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchCreateConnectorsResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
connectorsList: jspb.Message.toObjectList(msg.getConnectorsList(),
    proto.interface.ti.users.v1.Connector.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchCreateConnectorsResponse}
 */
proto.interface.ti.users.v1.BatchCreateConnectorsResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchCreateConnectorsResponse;
  return proto.interface.ti.users.v1.BatchCreateConnectorsResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchCreateConnectorsResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchCreateConnectorsResponse}
 */
proto.interface.ti.users.v1.BatchCreateConnectorsResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.Connector;
      reader.readMessage(value,proto.interface.ti.users.v1.Connector.deserializeBinaryFromReader);
      msg.addConnectors(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchCreateConnectorsResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchCreateConnectorsResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchCreateConnectorsResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchCreateConnectorsResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getConnectorsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.Connector.serializeBinaryToWriter
    );
  }
};


/**
 * repeated Connector connectors = 1;
 * @return {!Array<!proto.interface.ti.users.v1.Connector>}
 */
proto.interface.ti.users.v1.BatchCreateConnectorsResponse.prototype.getConnectorsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.Connector>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.Connector, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.Connector>} value
 * @return {!proto.interface.ti.users.v1.BatchCreateConnectorsResponse} returns this
*/
proto.interface.ti.users.v1.BatchCreateConnectorsResponse.prototype.setConnectorsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.Connector=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.Connector}
 */
proto.interface.ti.users.v1.BatchCreateConnectorsResponse.prototype.addConnectors = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.Connector, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchCreateConnectorsResponse} returns this
 */
proto.interface.ti.users.v1.BatchCreateConnectorsResponse.prototype.clearConnectorsList = function() {
  return this.setConnectorsList([]);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.repeatedFields_ = [2];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchGetConnectorsRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchGetConnectorsRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
parent: jspb.Message.getFieldWithDefault(msg, 1, ""),
namesList: (f = jspb.Message.getRepeatedField(msg, 2)) == null ? undefined : f,
view: jspb.Message.getFieldWithDefault(msg, 3, 0),
readMask: (f = msg.getReadMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchGetConnectorsRequest}
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchGetConnectorsRequest;
  return proto.interface.ti.users.v1.BatchGetConnectorsRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchGetConnectorsRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchGetConnectorsRequest}
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setParent(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.addNames(value);
      break;
    case 3:
      var value = /** @type {!proto.interface.ti.users.v1.ConnectorView} */ (reader.readEnum());
      msg.setView(value);
      break;
    case 4:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setReadMask(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchGetConnectorsRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchGetConnectorsRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getParent();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getNamesList();
  if (f.length > 0) {
    writer.writeRepeatedString(
      2,
      f
    );
  }
  f = message.getView();
  if (f !== 0.0) {
    writer.writeEnum(
      3,
      f
    );
  }
  f = message.getReadMask();
  if (f != null) {
    writer.writeMessage(
      4,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
};


/**
 * optional string parent = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.getParent = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.BatchGetConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.setParent = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * repeated string names = 2;
 * @return {!Array<string>}
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.getNamesList = function() {
  return /** @type {!Array<string>} */ (jspb.Message.getRepeatedField(this, 2));
};


/**
 * @param {!Array<string>} value
 * @return {!proto.interface.ti.users.v1.BatchGetConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.setNamesList = function(value) {
  return jspb.Message.setField(this, 2, value || []);
};


/**
 * @param {string} value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.BatchGetConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.addNames = function(value, opt_index) {
  return jspb.Message.addToRepeatedField(this, 2, value, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchGetConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.clearNamesList = function() {
  return this.setNamesList([]);
};


/**
 * optional ConnectorView view = 3;
 * @return {!proto.interface.ti.users.v1.ConnectorView}
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.getView = function() {
  return /** @type {!proto.interface.ti.users.v1.ConnectorView} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.ConnectorView} value
 * @return {!proto.interface.ti.users.v1.BatchGetConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.setView = function(value) {
  return jspb.Message.setProto3EnumField(this, 3, value);
};


/**
 * optional google.protobuf.FieldMask read_mask = 4;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.getReadMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 4));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.BatchGetConnectorsRequest} returns this
*/
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.setReadMask = function(value) {
  return jspb.Message.setWrapperField(this, 4, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.BatchGetConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.clearReadMask = function() {
  return this.setReadMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.BatchGetConnectorsRequest.prototype.hasReadMask = function() {
  return jspb.Message.getField(this, 4) != null;
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchGetConnectorsResponse.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchGetConnectorsResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchGetConnectorsResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchGetConnectorsResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchGetConnectorsResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
connectorsList: jspb.Message.toObjectList(msg.getConnectorsList(),
    proto.interface.ti.users.v1.Connector.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchGetConnectorsResponse}
 */
proto.interface.ti.users.v1.BatchGetConnectorsResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchGetConnectorsResponse;
  return proto.interface.ti.users.v1.BatchGetConnectorsResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchGetConnectorsResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchGetConnectorsResponse}
 */
proto.interface.ti.users.v1.BatchGetConnectorsResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.Connector;
      reader.readMessage(value,proto.interface.ti.users.v1.Connector.deserializeBinaryFromReader);
      msg.addConnectors(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchGetConnectorsResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchGetConnectorsResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchGetConnectorsResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchGetConnectorsResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getConnectorsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.Connector.serializeBinaryToWriter
    );
  }
};


/**
 * repeated Connector connectors = 1;
 * @return {!Array<!proto.interface.ti.users.v1.Connector>}
 */
proto.interface.ti.users.v1.BatchGetConnectorsResponse.prototype.getConnectorsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.Connector>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.Connector, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.Connector>} value
 * @return {!proto.interface.ti.users.v1.BatchGetConnectorsResponse} returns this
*/
proto.interface.ti.users.v1.BatchGetConnectorsResponse.prototype.setConnectorsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.Connector=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.Connector}
 */
proto.interface.ti.users.v1.BatchGetConnectorsResponse.prototype.addConnectors = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.Connector, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchGetConnectorsResponse} returns this
 */
proto.interface.ti.users.v1.BatchGetConnectorsResponse.prototype.clearConnectorsList = function() {
  return this.setConnectorsList([]);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.repeatedFields_ = [2];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchUpdateConnectorsRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
parent: jspb.Message.getFieldWithDefault(msg, 1, ""),
requestsList: jspb.Message.toObjectList(msg.getRequestsList(),
    proto.interface.ti.users.v1.UpdateConnectorRequest.toObject, includeInstance),
updateMask: (f = msg.getUpdateMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f),
allowMissing: jspb.Message.getBooleanFieldWithDefault(msg, 4, false)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchUpdateConnectorsRequest}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchUpdateConnectorsRequest;
  return proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchUpdateConnectorsRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchUpdateConnectorsRequest}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setParent(value);
      break;
    case 2:
      var value = new proto.interface.ti.users.v1.UpdateConnectorRequest;
      reader.readMessage(value,proto.interface.ti.users.v1.UpdateConnectorRequest.deserializeBinaryFromReader);
      msg.addRequests(value);
      break;
    case 3:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setUpdateMask(value);
      break;
    case 4:
      var value = /** @type {boolean} */ (reader.readBool());
      msg.setAllowMissing(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchUpdateConnectorsRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getParent();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getRequestsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      2,
      f,
      proto.interface.ti.users.v1.UpdateConnectorRequest.serializeBinaryToWriter
    );
  }
  f = message.getUpdateMask();
  if (f != null) {
    writer.writeMessage(
      3,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
  f = message.getAllowMissing();
  if (f) {
    writer.writeBool(
      4,
      f
    );
  }
};


/**
 * optional string parent = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.getParent = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.BatchUpdateConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.setParent = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * repeated UpdateConnectorRequest requests = 2;
 * @return {!Array<!proto.interface.ti.users.v1.UpdateConnectorRequest>}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.getRequestsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.UpdateConnectorRequest>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.UpdateConnectorRequest, 2));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.UpdateConnectorRequest>} value
 * @return {!proto.interface.ti.users.v1.BatchUpdateConnectorsRequest} returns this
*/
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.setRequestsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 2, value);
};


/**
 * @param {!proto.interface.ti.users.v1.UpdateConnectorRequest=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.UpdateConnectorRequest}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.addRequests = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 2, opt_value, proto.interface.ti.users.v1.UpdateConnectorRequest, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchUpdateConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.clearRequestsList = function() {
  return this.setRequestsList([]);
};


/**
 * optional google.protobuf.FieldMask update_mask = 3;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.getUpdateMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 3));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.BatchUpdateConnectorsRequest} returns this
*/
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.setUpdateMask = function(value) {
  return jspb.Message.setWrapperField(this, 3, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.BatchUpdateConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.clearUpdateMask = function() {
  return this.setUpdateMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.hasUpdateMask = function() {
  return jspb.Message.getField(this, 3) != null;
};


/**
 * optional bool allow_missing = 4;
 * @return {boolean}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.getAllowMissing = function() {
  return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 4, false));
};


/**
 * @param {boolean} value
 * @return {!proto.interface.ti.users.v1.BatchUpdateConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsRequest.prototype.setAllowMissing = function(value) {
  return jspb.Message.setProto3BooleanField(this, 4, value);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchUpdateConnectorsResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
connectorsList: jspb.Message.toObjectList(msg.getConnectorsList(),
    proto.interface.ti.users.v1.Connector.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchUpdateConnectorsResponse}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchUpdateConnectorsResponse;
  return proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchUpdateConnectorsResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchUpdateConnectorsResponse}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.Connector;
      reader.readMessage(value,proto.interface.ti.users.v1.Connector.deserializeBinaryFromReader);
      msg.addConnectors(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchUpdateConnectorsResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getConnectorsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.Connector.serializeBinaryToWriter
    );
  }
};


/**
 * repeated Connector connectors = 1;
 * @return {!Array<!proto.interface.ti.users.v1.Connector>}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.prototype.getConnectorsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.Connector>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.Connector, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.Connector>} value
 * @return {!proto.interface.ti.users.v1.BatchUpdateConnectorsResponse} returns this
*/
proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.prototype.setConnectorsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.Connector=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.Connector}
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.prototype.addConnectors = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.Connector, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchUpdateConnectorsResponse} returns this
 */
proto.interface.ti.users.v1.BatchUpdateConnectorsResponse.prototype.clearConnectorsList = function() {
  return this.setConnectorsList([]);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.repeatedFields_ = [2];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchDeleteConnectorsRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
parent: jspb.Message.getFieldWithDefault(msg, 1, ""),
requestsList: jspb.Message.toObjectList(msg.getRequestsList(),
    proto.interface.ti.users.v1.DeleteConnectorRequest.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchDeleteConnectorsRequest}
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchDeleteConnectorsRequest;
  return proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchDeleteConnectorsRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchDeleteConnectorsRequest}
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setParent(value);
      break;
    case 2:
      var value = new proto.interface.ti.users.v1.DeleteConnectorRequest;
      reader.readMessage(value,proto.interface.ti.users.v1.DeleteConnectorRequest.deserializeBinaryFromReader);
      msg.addRequests(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchDeleteConnectorsRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getParent();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getRequestsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      2,
      f,
      proto.interface.ti.users.v1.DeleteConnectorRequest.serializeBinaryToWriter
    );
  }
};


/**
 * optional string parent = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.prototype.getParent = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.BatchDeleteConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.prototype.setParent = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * repeated DeleteConnectorRequest requests = 2;
 * @return {!Array<!proto.interface.ti.users.v1.DeleteConnectorRequest>}
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.prototype.getRequestsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.DeleteConnectorRequest>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.DeleteConnectorRequest, 2));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.DeleteConnectorRequest>} value
 * @return {!proto.interface.ti.users.v1.BatchDeleteConnectorsRequest} returns this
*/
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.prototype.setRequestsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 2, value);
};


/**
 * @param {!proto.interface.ti.users.v1.DeleteConnectorRequest=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.DeleteConnectorRequest}
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.prototype.addRequests = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 2, opt_value, proto.interface.ti.users.v1.DeleteConnectorRequest, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchDeleteConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsRequest.prototype.clearRequestsList = function() {
  return this.setRequestsList([]);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchDeleteConnectorsResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
connectorsList: jspb.Message.toObjectList(msg.getConnectorsList(),
    proto.interface.ti.users.v1.Connector.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchDeleteConnectorsResponse}
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchDeleteConnectorsResponse;
  return proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchDeleteConnectorsResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchDeleteConnectorsResponse}
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.Connector;
      reader.readMessage(value,proto.interface.ti.users.v1.Connector.deserializeBinaryFromReader);
      msg.addConnectors(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchDeleteConnectorsResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getConnectorsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.Connector.serializeBinaryToWriter
    );
  }
};


/**
 * repeated Connector connectors = 1;
 * @return {!Array<!proto.interface.ti.users.v1.Connector>}
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.prototype.getConnectorsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.Connector>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.Connector, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.Connector>} value
 * @return {!proto.interface.ti.users.v1.BatchDeleteConnectorsResponse} returns this
*/
proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.prototype.setConnectorsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.Connector=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.Connector}
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.prototype.addConnectors = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.Connector, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchDeleteConnectorsResponse} returns this
 */
proto.interface.ti.users.v1.BatchDeleteConnectorsResponse.prototype.clearConnectorsList = function() {
  return this.setConnectorsList([]);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.repeatedFields_ = [2];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
parent: jspb.Message.getFieldWithDefault(msg, 1, ""),
requestsList: jspb.Message.toObjectList(msg.getRequestsList(),
    proto.interface.ti.users.v1.UndeleteConnectorRequest.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest}
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest;
  return proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest}
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setParent(value);
      break;
    case 2:
      var value = new proto.interface.ti.users.v1.UndeleteConnectorRequest;
      reader.readMessage(value,proto.interface.ti.users.v1.UndeleteConnectorRequest.deserializeBinaryFromReader);
      msg.addRequests(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getParent();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getRequestsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      2,
      f,
      proto.interface.ti.users.v1.UndeleteConnectorRequest.serializeBinaryToWriter
    );
  }
};


/**
 * optional string parent = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.prototype.getParent = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.prototype.setParent = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * repeated UndeleteConnectorRequest requests = 2;
 * @return {!Array<!proto.interface.ti.users.v1.UndeleteConnectorRequest>}
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.prototype.getRequestsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.UndeleteConnectorRequest>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.UndeleteConnectorRequest, 2));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.UndeleteConnectorRequest>} value
 * @return {!proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest} returns this
*/
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.prototype.setRequestsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 2, value);
};


/**
 * @param {!proto.interface.ti.users.v1.UndeleteConnectorRequest=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.UndeleteConnectorRequest}
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.prototype.addRequests = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 2, opt_value, proto.interface.ti.users.v1.UndeleteConnectorRequest, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsRequest.prototype.clearRequestsList = function() {
  return this.setRequestsList([]);
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
connectorsList: jspb.Message.toObjectList(msg.getConnectorsList(),
    proto.interface.ti.users.v1.Connector.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse}
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse;
  return proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse}
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.Connector;
      reader.readMessage(value,proto.interface.ti.users.v1.Connector.deserializeBinaryFromReader);
      msg.addConnectors(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getConnectorsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.Connector.serializeBinaryToWriter
    );
  }
};


/**
 * repeated Connector connectors = 1;
 * @return {!Array<!proto.interface.ti.users.v1.Connector>}
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.prototype.getConnectorsList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.Connector>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.Connector, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.Connector>} value
 * @return {!proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse} returns this
*/
proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.prototype.setConnectorsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.Connector=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.Connector}
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.prototype.addConnectors = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.Connector, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse} returns this
 */
proto.interface.ti.users.v1.BatchUndeleteConnectorsResponse.prototype.clearConnectorsList = function() {
  return this.setConnectorsList([]);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.StreamConnectorsRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.StreamConnectorsRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
parent: jspb.Message.getFieldWithDefault(msg, 1, ""),
view: jspb.Message.getFieldWithDefault(msg, 2, 0),
readMask: (f = msg.getReadMask()) && google_protobuf_field_mask_pb.FieldMask.toObject(includeInstance, f),
filter: jspb.Message.getFieldWithDefault(msg, 4, ""),
orderBy: jspb.Message.getFieldWithDefault(msg, 5, ""),
showDeleted: jspb.Message.getBooleanFieldWithDefault(msg, 6, false)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.StreamConnectorsRequest}
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.StreamConnectorsRequest;
  return proto.interface.ti.users.v1.StreamConnectorsRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.StreamConnectorsRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.StreamConnectorsRequest}
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setParent(value);
      break;
    case 2:
      var value = /** @type {!proto.interface.ti.users.v1.ConnectorView} */ (reader.readEnum());
      msg.setView(value);
      break;
    case 3:
      var value = new google_protobuf_field_mask_pb.FieldMask;
      reader.readMessage(value,google_protobuf_field_mask_pb.FieldMask.deserializeBinaryFromReader);
      msg.setReadMask(value);
      break;
    case 4:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setFilter(value);
      break;
    case 5:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setOrderBy(value);
      break;
    case 6:
      var value = /** @type {boolean} */ (reader.readBool());
      msg.setShowDeleted(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.StreamConnectorsRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.StreamConnectorsRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getParent();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getView();
  if (f !== 0.0) {
    writer.writeEnum(
      2,
      f
    );
  }
  f = message.getReadMask();
  if (f != null) {
    writer.writeMessage(
      3,
      f,
      google_protobuf_field_mask_pb.FieldMask.serializeBinaryToWriter
    );
  }
  f = message.getFilter();
  if (f.length > 0) {
    writer.writeString(
      4,
      f
    );
  }
  f = message.getOrderBy();
  if (f.length > 0) {
    writer.writeString(
      5,
      f
    );
  }
  f = message.getShowDeleted();
  if (f) {
    writer.writeBool(
      6,
      f
    );
  }
};


/**
 * optional string parent = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.getParent = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.StreamConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.setParent = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional ConnectorView view = 2;
 * @return {!proto.interface.ti.users.v1.ConnectorView}
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.getView = function() {
  return /** @type {!proto.interface.ti.users.v1.ConnectorView} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.ConnectorView} value
 * @return {!proto.interface.ti.users.v1.StreamConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.setView = function(value) {
  return jspb.Message.setProto3EnumField(this, 2, value);
};


/**
 * optional google.protobuf.FieldMask read_mask = 3;
 * @return {?proto.google.protobuf.FieldMask}
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.getReadMask = function() {
  return /** @type{?proto.google.protobuf.FieldMask} */ (
    jspb.Message.getWrapperField(this, google_protobuf_field_mask_pb.FieldMask, 3));
};


/**
 * @param {?proto.google.protobuf.FieldMask|undefined} value
 * @return {!proto.interface.ti.users.v1.StreamConnectorsRequest} returns this
*/
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.setReadMask = function(value) {
  return jspb.Message.setWrapperField(this, 3, value);
};


/**
 * Clears the message field making it undefined.
 * @return {!proto.interface.ti.users.v1.StreamConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.clearReadMask = function() {
  return this.setReadMask(undefined);
};


/**
 * Returns whether this field is set.
 * @return {boolean}
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.hasReadMask = function() {
  return jspb.Message.getField(this, 3) != null;
};


/**
 * optional string filter = 4;
 * @return {string}
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.getFilter = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.StreamConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.setFilter = function(value) {
  return jspb.Message.setProto3StringField(this, 4, value);
};


/**
 * optional string order_by = 5;
 * @return {string}
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.getOrderBy = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.StreamConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.setOrderBy = function(value) {
  return jspb.Message.setProto3StringField(this, 5, value);
};


/**
 * optional bool show_deleted = 6;
 * @return {boolean}
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.getShowDeleted = function() {
  return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 6, false));
};


/**
 * @param {boolean} value
 * @return {!proto.interface.ti.users.v1.StreamConnectorsRequest} returns this
 */
proto.interface.ti.users.v1.StreamConnectorsRequest.prototype.setShowDeleted = function(value) {
  return jspb.Message.setProto3BooleanField(this, 6, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.FetchAccessTokenRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.FetchAccessTokenRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.FetchAccessTokenRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.FetchAccessTokenRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
connector: jspb.Message.getFieldWithDefault(msg, 1, ""),
forceRefresh: jspb.Message.getBooleanFieldWithDefault(msg, 2, false)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.FetchAccessTokenRequest}
 */
proto.interface.ti.users.v1.FetchAccessTokenRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.FetchAccessTokenRequest;
  return proto.interface.ti.users.v1.FetchAccessTokenRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.FetchAccessTokenRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.FetchAccessTokenRequest}
 */
proto.interface.ti.users.v1.FetchAccessTokenRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setConnector(value);
      break;
    case 2:
      var value = /** @type {boolean} */ (reader.readBool());
      msg.setForceRefresh(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.FetchAccessTokenRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.FetchAccessTokenRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.FetchAccessTokenRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.FetchAccessTokenRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getConnector();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getForceRefresh();
  if (f) {
    writer.writeBool(
      2,
      f
    );
  }
};


/**
 * optional string connector = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.FetchAccessTokenRequest.prototype.getConnector = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.FetchAccessTokenRequest} returns this
 */
proto.interface.ti.users.v1.FetchAccessTokenRequest.prototype.setConnector = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional bool force_refresh = 2;
 * @return {boolean}
 */
proto.interface.ti.users.v1.FetchAccessTokenRequest.prototype.getForceRefresh = function() {
  return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 2, false));
};


/**
 * @param {boolean} value
 * @return {!proto.interface.ti.users.v1.FetchAccessTokenRequest} returns this
 */
proto.interface.ti.users.v1.FetchAccessTokenRequest.prototype.setForceRefresh = function(value) {
  return jspb.Message.setProto3BooleanField(this, 2, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.FetchAccessTokenResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.FetchAccessTokenResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.FetchAccessTokenResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.FetchAccessTokenResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
accessToken: jspb.Message.getFieldWithDefault(msg, 1, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.FetchAccessTokenResponse}
 */
proto.interface.ti.users.v1.FetchAccessTokenResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.FetchAccessTokenResponse;
  return proto.interface.ti.users.v1.FetchAccessTokenResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.FetchAccessTokenResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.FetchAccessTokenResponse}
 */
proto.interface.ti.users.v1.FetchAccessTokenResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setAccessToken(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.FetchAccessTokenResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.FetchAccessTokenResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.FetchAccessTokenResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.FetchAccessTokenResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getAccessToken();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
};


/**
 * optional string access_token = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.FetchAccessTokenResponse.prototype.getAccessToken = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.FetchAccessTokenResponse} returns this
 */
proto.interface.ti.users.v1.FetchAccessTokenResponse.prototype.setAccessToken = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.AuthorizeConnectorRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.AuthorizeConnectorRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.AuthorizeConnectorRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.AuthorizeConnectorRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
connector: jspb.Message.getFieldWithDefault(msg, 1, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.AuthorizeConnectorRequest}
 */
proto.interface.ti.users.v1.AuthorizeConnectorRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.AuthorizeConnectorRequest;
  return proto.interface.ti.users.v1.AuthorizeConnectorRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.AuthorizeConnectorRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.AuthorizeConnectorRequest}
 */
proto.interface.ti.users.v1.AuthorizeConnectorRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setConnector(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.AuthorizeConnectorRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.AuthorizeConnectorRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.AuthorizeConnectorRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.AuthorizeConnectorRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getConnector();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
};


/**
 * optional string connector = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.AuthorizeConnectorRequest.prototype.getConnector = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.AuthorizeConnectorRequest} returns this
 */
proto.interface.ti.users.v1.AuthorizeConnectorRequest.prototype.setConnector = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.AuthorizeConnectorMetadata.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.AuthorizeConnectorMetadata.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.AuthorizeConnectorMetadata} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.AuthorizeConnectorMetadata.toObject = function(includeInstance, msg) {
  var f, obj = {
connector: jspb.Message.getFieldWithDefault(msg, 1, ""),
progressNotes: jspb.Message.getFieldWithDefault(msg, 2, ""),
authCodeUrl: jspb.Message.getFieldWithDefault(msg, 3, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.AuthorizeConnectorMetadata}
 */
proto.interface.ti.users.v1.AuthorizeConnectorMetadata.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.AuthorizeConnectorMetadata;
  return proto.interface.ti.users.v1.AuthorizeConnectorMetadata.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.AuthorizeConnectorMetadata} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.AuthorizeConnectorMetadata}
 */
proto.interface.ti.users.v1.AuthorizeConnectorMetadata.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setConnector(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setProgressNotes(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setAuthCodeUrl(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.AuthorizeConnectorMetadata.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.AuthorizeConnectorMetadata.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.AuthorizeConnectorMetadata} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.AuthorizeConnectorMetadata.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getConnector();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getProgressNotes();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
  f = message.getAuthCodeUrl();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
};


/**
 * optional string connector = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.AuthorizeConnectorMetadata.prototype.getConnector = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.AuthorizeConnectorMetadata} returns this
 */
proto.interface.ti.users.v1.AuthorizeConnectorMetadata.prototype.setConnector = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional string progress_notes = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.AuthorizeConnectorMetadata.prototype.getProgressNotes = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.AuthorizeConnectorMetadata} returns this
 */
proto.interface.ti.users.v1.AuthorizeConnectorMetadata.prototype.setProgressNotes = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};


/**
 * optional string auth_code_url = 3;
 * @return {string}
 */
proto.interface.ti.users.v1.AuthorizeConnectorMetadata.prototype.getAuthCodeUrl = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.AuthorizeConnectorMetadata} returns this
 */
proto.interface.ti.users.v1.AuthorizeConnectorMetadata.prototype.setAuthCodeUrl = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.AuthorizeConnectorResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.AuthorizeConnectorResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.AuthorizeConnectorResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.AuthorizeConnectorResponse.toObject = function(includeInstance, msg) {
  var f, obj = {

  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.AuthorizeConnectorResponse}
 */
proto.interface.ti.users.v1.AuthorizeConnectorResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.AuthorizeConnectorResponse;
  return proto.interface.ti.users.v1.AuthorizeConnectorResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.AuthorizeConnectorResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.AuthorizeConnectorResponse}
 */
proto.interface.ti.users.v1.AuthorizeConnectorResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.AuthorizeConnectorResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.AuthorizeConnectorResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.AuthorizeConnectorResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.AuthorizeConnectorResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.RevokeConnectorRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.RevokeConnectorRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.RevokeConnectorRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RevokeConnectorRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
connector: jspb.Message.getFieldWithDefault(msg, 1, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.RevokeConnectorRequest}
 */
proto.interface.ti.users.v1.RevokeConnectorRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.RevokeConnectorRequest;
  return proto.interface.ti.users.v1.RevokeConnectorRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.RevokeConnectorRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.RevokeConnectorRequest}
 */
proto.interface.ti.users.v1.RevokeConnectorRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setConnector(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.RevokeConnectorRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.RevokeConnectorRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.RevokeConnectorRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RevokeConnectorRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getConnector();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
};


/**
 * optional string connector = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.RevokeConnectorRequest.prototype.getConnector = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.RevokeConnectorRequest} returns this
 */
proto.interface.ti.users.v1.RevokeConnectorRequest.prototype.setConnector = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.RevokeConnectorResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.RevokeConnectorResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.RevokeConnectorResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RevokeConnectorResponse.toObject = function(includeInstance, msg) {
  var f, obj = {

  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.RevokeConnectorResponse}
 */
proto.interface.ti.users.v1.RevokeConnectorResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.RevokeConnectorResponse;
  return proto.interface.ti.users.v1.RevokeConnectorResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.RevokeConnectorResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.RevokeConnectorResponse}
 */
proto.interface.ti.users.v1.RevokeConnectorResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.RevokeConnectorResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.RevokeConnectorResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.RevokeConnectorResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.RevokeConnectorResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest.toObject = function(includeInstance, msg) {
  var f, obj = {

  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest;
  return proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
};



/**
 * List of repeated fields within this message type.
 * @private {!Array<number>}
 * @const
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.repeatedFields_ = [1];



if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
connectorSummariesList: jspb.Message.toObjectList(msg.getConnectorSummariesList(),
    proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse;
  return proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = new proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary;
      reader.readMessage(value,proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.deserializeBinaryFromReader);
      msg.addConnectorSummaries(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getConnectorSummariesList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      1,
      f,
      proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.serializeBinaryToWriter
    );
  }
};





if (jspb.Message.GENERATE_TO_OBJECT) {
/**
 * Creates an object representation of this proto.
 * Field names that are reserved in JavaScript and will be renamed to pb_name.
 * Optional fields that are not set will be set to undefined.
 * To access a reserved field use, foo.pb_<name>, eg, foo.pb_default.
 * For the list of reserved names please see:
 *     net/proto2/compiler/js/internal/generator.cc#kKeyword.
 * @param {boolean=} opt_includeInstance Deprecated. whether to include the
 *     JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @return {!Object}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.prototype.toObject = function(opt_includeInstance) {
  return proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.toObject(opt_includeInstance, this);
};


/**
 * Static version of the {@see toObject} method.
 * @param {boolean|undefined} includeInstance Deprecated. Whether to include
 *     the JSPB instance for transitional soy proto support:
 *     http://goto/soy-param-migration
 * @param {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary} msg The msg instance to transform.
 * @return {!Object}
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.toObject = function(includeInstance, msg) {
  var f, obj = {
name: jspb.Message.getFieldWithDefault(msg, 1, ""),
description: jspb.Message.getFieldWithDefault(msg, 2, ""),
connectorStatus: jspb.Message.getFieldWithDefault(msg, 3, 0),
provider: jspb.Message.getFieldWithDefault(msg, 4, ""),
displayName: jspb.Message.getFieldWithDefault(msg, 5, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}


/**
 * Deserializes binary data (in protobuf wire format).
 * @param {jspb.binary.bytesource.ByteSource} bytes The bytes to deserialize.
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary;
  return proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.deserializeBinaryFromReader(msg, reader);
};


/**
 * Deserializes binary data (in protobuf wire format) from the
 * given reader into the given message object.
 * @param {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary} msg The message object to deserialize into.
 * @param {!jspb.BinaryReader} reader The BinaryReader to use.
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setName(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setDescription(value);
      break;
    case 3:
      var value = /** @type {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.ConnectorStatus} */ (reader.readEnum());
      msg.setConnectorStatus(value);
      break;
    case 4:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setProvider(value);
      break;
    case 5:
      var value = /** @type {string} */ (reader.readStringRequireUtf8());
      msg.setDisplayName(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


/**
 * Serializes the given message to binary data (in protobuf wire
 * format), writing to the given BinaryWriter.
 * @param {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary} message
 * @param {!jspb.BinaryWriter} writer
 * @suppress {unusedLocalVariables} f is only used for nested messages
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getName();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getDescription();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
  f = message.getConnectorStatus();
  if (f !== 0.0) {
    writer.writeEnum(
      3,
      f
    );
  }
  f = message.getProvider();
  if (f.length > 0) {
    writer.writeString(
      4,
      f
    );
  }
  f = message.getDisplayName();
  if (f.length > 0) {
    writer.writeString(
      5,
      f
    );
  }
};


/**
 * @enum {number}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.ConnectorStatus = {
  CONNECTOR_STATUS_UNSPECIFIED: 0,
  UNCONNECTED: 1,
  CONNECTED: 2,
  EXPIRED: 3
};

/**
 * optional string name = 1;
 * @return {string}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.prototype.getName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary} returns this
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.prototype.setName = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional string description = 2;
 * @return {string}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.prototype.getDescription = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary} returns this
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.prototype.setDescription = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};


/**
 * optional ConnectorStatus connector_status = 3;
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.ConnectorStatus}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.prototype.getConnectorStatus = function() {
  return /** @type {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.ConnectorStatus} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};


/**
 * @param {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.ConnectorStatus} value
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary} returns this
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.prototype.setConnectorStatus = function(value) {
  return jspb.Message.setProto3EnumField(this, 3, value);
};


/**
 * optional string provider = 4;
 * @return {string}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.prototype.getProvider = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 4, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary} returns this
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.prototype.setProvider = function(value) {
  return jspb.Message.setProto3StringField(this, 4, value);
};


/**
 * optional string display_name = 5;
 * @return {string}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.prototype.getDisplayName = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 5, ""));
};


/**
 * @param {string} value
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary} returns this
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary.prototype.setDisplayName = function(value) {
  return jspb.Message.setProto3StringField(this, 5, value);
};


/**
 * repeated ConnectorSummary connector_summaries = 1;
 * @return {!Array<!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary>}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.prototype.getConnectorSummariesList = function() {
  return /** @type{!Array<!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary, 1));
};


/**
 * @param {!Array<!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary>} value
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse} returns this
*/
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.prototype.setConnectorSummariesList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 1, value);
};


/**
 * @param {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary=} opt_value
 * @param {number=} opt_index
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary}
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.prototype.addConnectorSummaries = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 1, opt_value, proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.ConnectorSummary, opt_index);
};


/**
 * Clears the list making it empty but non-null.
 * @return {!proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse} returns this
 */
proto.interface.ti.users.v1.ListMyAvailableConnectorsResponse.prototype.clearConnectorSummariesList = function() {
  return this.setConnectorSummariesList([]);
};


/**
 * @enum {number}
 */
proto.interface.ti.users.v1.CredentialState = {
  CREDENTIAL_STATE_UNSPECIFIED: 0,
  CREDENTIAL_STATE_ACTIVE: 1,
  CREDENTIAL_STATE_REVOKED: 2
};

/**
 * @enum {number}
 */
proto.interface.ti.users.v1.IdentityProvider = {
  IDENTITY_PROVIDER_UNSPECIFIED: 0,
  GOOGLE: 1,
  MICROSOFT: 2,
  EMAIL: 3,
  LINKEDIN: 4,
  APPLE: 5
};

/**
 * @enum {number}
 */
proto.interface.ti.users.v1.UserView = {
  USER_VIEW_UNSPECIFIED: 0,
  USER_VIEW_BASIC: 1,
  USER_VIEW_FULL: 2
};

/**
 * @enum {number}
 */
proto.interface.ti.users.v1.ConnectorView = {
  CONNECTOR_VIEW_UNSPECIFIED: 0,
  CONNECTOR_VIEW_BASIC: 1,
  CONNECTOR_VIEW_FULL: 2
};

goog.object.extend(exports, proto.interface.ti.users.v1);

// Below is base64 encoded GeneratedCodeInfo proto
// CiwKAgQAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiSRSCWRQouCgQEAAMAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxilSyCzSwouCgQEAAMBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjDUSDUUQouCgQEAAMCEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjtVyD9VwouCgQEAAMDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiTXiCgXgouCgQEAAMFEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxitZCC0ZAowCgYEAAMFAwESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLdqILtqCiwKAgQBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjAcCDHcAosCgIEAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y3XYg6XYKLAoCBAMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGN98IPN8Ci4KAgQEEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiBgwEgiIMBCi4KAgQFEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjviAEg+IgBCi4KAgQGEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjljgEg9o4BCi4KAgQHEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxj7lAEgiZUBCi4KAgQIEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiFmwEglpsBCi4KAgQJEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiboQEgrKEBCi4KAgQKEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxixpwEgxKcBCi4KAgQLEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjPrQEg360BCi4KAgQMEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjhswEg8rMBCi4KAgQNEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiwugEgxLoBCi4KAgQOEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiOwQEgo8EBCi4KAgQPEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjxxwEgiMgBCi4KAgQQEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjezgEg9s4BCi4KAgQREiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjQ1QEg4tUBCi4KAgQSEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjq2wEghNwBCi4KAgQTEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxik4gEgw+IBCi4KAgQUEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi56QEg2ekBCi4KAgQVEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjT8AEg5PABCi4KAgQWEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjp9gEg+/YBCjAKBAQWAwASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGND9ASDW/QEKLgoCBBcSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPODAiCNhAIKLgoCBBgSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGK2KAiDIigIKLgoCBBkSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGK6RAiDHkQIKLgoCBBoSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKKYAiCsmAIKLgoCBBsSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJyeAiCvngIKLgoCBBwSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLqkAiDRpAIKLgoCBB0SIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOiqAiD9qgIKLgoCBB4SIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGI6xAiCfsQIKLgoCBB8SIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKS3AiC5twIKLgoCBCASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMq9AiDdvQIKLgoCBCESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOjDAiCAxAIKLgoCBCISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJrKAiCzygIKLgoCBCMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNDQAiDl0AIKLgoCBCQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPbWAiCM1wIKLgoCBCUSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKDdAiC23QIKLgoCBCYSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMrjAiDd4wIKLgoCBCcSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOjpAiD+6QIKLgoCBCgSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJLwAiCo8AIKLgoCBCkSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLz2AiDU9gIKLgoCBCoSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGO78AiCD/QIKLgoCBCsSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJSDAyCqgwMKLgoCBCwSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPyJAyCYigMKLgoCBC0SIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIKRAyCfkQMKLgoCBC4SIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGI2YAyCmmAMKLgoCBC8SIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGISfAyCenwMKLgoCBDASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGICmAyCcpgMKLgoCBDESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIatAyCjrQMKLgoCBDISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJG0AyCttAMKLgoCBDMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJe7AyC0uwMKLgoCBDQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKLCAyDAwgMKLgoCBDUSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLLJAyDRyQMKLgoCBDYSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMfQAyDe0AMKLgoCBDcSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPXWAyCM1wMKLgoCBDgSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKPdAyC73QMKLgoCBDkSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNXjAyDu4wMKLgoCBDoSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIvqAyCl6gMKLgoCBDsSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMXwAyDf8AMKLgoCBDwSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGP/2AyCV9wMKLgoCBD0SIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKn9AyDA/QMKLgoCBD4SIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNeDBCD3gwQKLgoCBD8SIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKmKBCDKigQKMAoEBD8DABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y6pEEIPqRBAoyCgYEAAMAAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIOoBSCIqAUKMgoGBAADAAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiTqgUgmKoFCjIKBgQAAwECABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y4sgFIOfIBQoyCgYEAAMBAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPjKBSD9ygUKMgoGBAADAgIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi36QUgvOkFCjIKBgQAAwICABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yy+sFINDrBQoyCgYEAAMDAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNqJBiDfiQYKMgoGBAADAwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjoiwYg7YsGCjQKCAQAAwUDAQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiZzAYgoMwGCjQKCAQAAwUDAQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bximzgYgrc4GCjQKCAQAAwUDAQIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjwzwYg988GCjQKCAQAAwUDAQIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxj90QYghNIGCjIKBgQAAwUCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y5tQGIPHUBgoyCgYEAAMFAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJrYBiCn2AYKMAoEBAACABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YzdkGINTZBgowCgQEAAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjB2wYgyNsGCjAKBAQAAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIPdBiCL3QYKMAoEBAACARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y+N4GIIDfBgowCgQEAAICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjA4AYgzOAGCjAKBAQAAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLniBiDF4gYKMAoEBAACAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YhuQGIJPkBgowCgQEAAIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiA5gYgjeYGCjAKBAQAAgQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMrnBiDU5wYKMAoEBAACBBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YwekGIMvpBgowCgQEAAIFEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiQ6wYgoOsGCjAKBAQAAgUSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGI7tBiCe7QYKMAoEBAACBhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y3u4GIOnuBgowCgQEAAIGEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjX8AYg4vAGCjAKBAQAAgcSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKPyBiCv8gYKMAoEBAACBxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YnfQGIKn0BgowCgQEAAIIEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjt9QYg+/UGCjAKBAQAAggSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOn3BiD39wYKMAoEBAACCRIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yu/kGIMv5BgowCgQEAAIJEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjE+wYg1PsGCjAKBAQAAgoSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGM39BiDg/QYKMAoEBAACChIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YmoAHIK2ABwowCgQEAAILEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjugQcg/IEHCjAKBAQAAgsSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOqDByD4gwcKMAoEBAACDBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y2YUHIOSFBwowCgQEAAIMEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxibiAcgpogHCjAKBAQAAgwSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJiKByCligcKMAoEBAACDBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YzosHINmLBwowCgQEAAINEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxizjQcgxo0HCjAKBAQAAg0SIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGP2PByCQkAcKMAoEBAACDRIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YgpIHIJeSBwowCgQEAAINEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjIkwcg25MHCjAKBAQAAg4SIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLqVByDHlQcKMAoEBAACDhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YlZgHIKKYBwowCgQEAAIOEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiTmgcgopoHCjAKBAQAAg4SIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGM2bByDamwcKMAoEBAACDxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YuJ0HIMWdBwowCgQEAAIPEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiToAcgoKAHCjAKBAQAAg8SIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJGiByCgogcKMAoEBAACDxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yy6MHINijBwowCgQEAAIQEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi9pQcgzqUHCjAKBAQAAhASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJ2oByCuqAcKMAoEBAACEBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YoKoHILOqBwowCgQEAAIQEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjiqwcg86sHCjAKBAQAAhESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNmtByDrrQcKMAoEBAACERIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YurAHIMywBwowCgQEAAIREiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi+sgcg0rIHCjAKBAQAAhESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIK0ByCUtAcKMAoEBAACEhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y/bUHII62BwowCgQEAAISEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiGuQcgl7kHCjAKBAQAAhISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIm7ByCcuwcKMAoEBAACEhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yy7wHINy8BwowCgQEAAITEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjOvgcg4r4HCjAKBAQAAhMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOPBByD3wQcKMAoEBAACExIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y6cMHIP/DBwowCgQEAAITEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxixxQcgxcUHCjAKBAQAAhQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLTHByDHxwcKMAoEBAACFBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YxcoHINjKBwowCgQEAAIUEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjKzAcg38wHCjAKBAQAAhQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJDOByCjzgcKMAoEBAACFRIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y3M8HIOvPBwowCgQEAAIVEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxji0Qcg8dEHCjAKBAQAAhUSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOjTByDz0wcKMAoEBAACFRIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y/tUHII/WBwowCgQEAAIWEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjm1wcg9tcHCjAKBAQAAhYSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOvaByD72gcKMAoEBAACFhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y7dwHIP/cBwowCgQEAAIWEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxit3gcgvd4HCjAKBAQAAhcSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPvfByCS4AcKMAoEBAACFxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YgOIHIJfiBwowCgQEAAIYEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjZ4wcg5eMHCjAKBAQAAhgSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNPlByDf5QcKMAoEBAACGRIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YoucHIK/nBwowCgQEAAIZEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxid6QcgqukHCjAKBAQAAhoSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIjrByCS6wcKMAoEBAACGhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y5u0HIPDtBwowCgQEAAIaEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxji7wcg7u8HCjAKBAQAAhoSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJbxByCg8QcKMAoEBAACGxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y8fMHIP/zBwowCgQEAAIbEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiP9wcgn/cHCjAKBAQAAhwSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMn4ByDQ+AcKMAoEBAACHBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YvvoHIMX6BwowCgQEAQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiqpAggvqQICjAKBAQBAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLSnCCDIpwgKMAoEBAECABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y7akIIP2pCAowCgQEAQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjGrAgg3KwICjAKBAQBAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNOuCCDvrggKMAoEBAECARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y/bEIIJmyCAowCgQEAQIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjOtAgg5rQICjAKBAQBAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLe3CCDVtwgKMAoEBAECAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YrbkIILy5CAowCgQEAQICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxijvAggsrwICjAKBAQBAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGM2+CCDYvggKMAoEBAECAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YnMEIIK3BCAowCgQEAgIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiT6gggpeoICjAKBAQCAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKLsCCC07AgKMAoEBAICARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YhO4IIJfuCAowCgQEAgIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiU8Aggp/AICjAKBAQCAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIDyCCCb8ggKMAoEBAICAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YmPQIILP0CAowCgQEAgIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxio9gggtPYICjAKBAQCAgMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJL5CCCe+QgKMAoEBAICAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yn/sIIK37CAowCgQEAgIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjf/Agg6/wICjAKBAQCAgQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGM3+CCDV/ggKMAoEBAICBBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YnYEJIKWBCQowCgQEAwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxinqwkguasJCjAKBAQDAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMatCSDYrQkKMAoEBAMCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YsK8JIMOvCQowCgQEAwIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjQsQkg47EJCjAKBAQDAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMSzCSDfswkKMAoEBAMCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y7LUJIIe2CQowCgQEAwIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiEuAkgkLgJCjAKBAQDAgMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGP66CSCKuwkKMAoEBAMCAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Ym70JIKm9CQowCgQEAwIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjjvgkg774JCjAKBAQDAgQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNnACSDhwAkKMAoEBAMCBBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YucMJIMHDCQowCgQEBAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiq6wkgvOsJCjAKBAQEAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGK/tCSDB7QkKMAoEBAQCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YjO8JIJ/vCQowCgQEBAIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiS8QkgpfEJCjAKBAQEAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOPyCSDs8gkKMAoEBAQCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y3vQJIOf0CQowCgQEBAIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjU9gkg4PYJCjAKBAQEAgMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLT5CSDA+QkKMAoEBAQCAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yt/sJIMX7CQowCgQEBAIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjy/Akg/vwJCjAKBAQEAgQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNv+CSDj/gkKMAoEBAQCBBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YoYEKIKmBCgowCgQEBQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi5twogwLcKCjAKBAQFAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLe5CiC+uQoKMAoEBAUCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YhbsKIJO7CgowCgQEBQIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiKvQogmL0KCjAKBAQFAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOO+CiD0vgoKMAoEBAUCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y68AKIPzACgowCgQEBQIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjDwgog0cIKCjAKBAQFAgMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMjECiDWxAoKMAoEBAUCBBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YnsYKIK3GCgowCgQEBQIEEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxikyAogs8gKCjAKBAQFAgUSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKbKCiCzygoKMAoEBAUCBRIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yi80KIJjNCgowCgQEBQIFEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiTzwogos8KCjAKBAQFAgUSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNLQCiDf0AoKMAoEBAUCBhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yw9IKINDSCgowCgQEBQIGEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxip1QogttUKCjAKBAQFAgYSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLLXCiDB1woKMAoEBAUCBhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y8dgKIP7YCgowCgQEBQIHEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjj2gog8NoKCjAKBAQFAgcSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMndCiDW3QoKMAoEBAUCBxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y0t8KIOHfCgowCgQEBQIHEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiR4QognuEKCjAKBAQFAggSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGITjCiCR4woKMAoEBAUCCBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y6+UKIPjlCgowCgQEBQIIEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxj15woghOgKCjAKBAQFAggSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLTpCiDB6QoKMAoEBAYCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YgIkLIIeJCwowCgQEBgIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjriwsg8osLCjAKBAQGAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGP2NCyCGjgsKMAoEBAYCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YuI8LIL+PCwowCgQEBwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiTswsgmrMLCjAKBAQHAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJu1CyCitQsKMAoEBAcCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yh7cLII63CwowCgQEBwIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjMuQsg07kLCjAKBAQHAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMe7CyDSuwsKMAoEBAcCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Ytb4LIMC+CwowCgQEBwICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjFwAsg0sALCjAKBAQHAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIXCCyCQwgsKMAoEBAgCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y5OcLIOvnCwowCgQECAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjP6gsg1uoLCjAKBAQIAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOHsCyDq7AsKMAoEBAgCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YnO4LIKPuCwowCgQECAIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiO8Asgm/ALCjAKBAQIAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGITzCyCR8wsKMAoEBAgCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YnPULIKv1CwowCgQECAIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjj9gsg8PYLCjAKBAQIAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGK/4CyC++AsKMAoEBAgCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y0foLIOD6CwowCgQECQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxj3mgwg/poMCjAKBAQJAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIWdDCCMnQwKMAoEBAkCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y054MINqeDAowCgQECQIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjhoAwg6KAMCjAKBAQKAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJ7BDCClwQwKMAoEBAoCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YsMMMILfDDAowCgQECgIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiAxQwgh8UMCjAKBAQKAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJLHDCCZxwwKMAoEBAsCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YjvQMIJn0DAowCgQECwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxid9gwgqPYMCjAKBAQLAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPH3DCD99wwKMAoEBAsCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YgvoMII76DAowCgQECwICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxj1+wwg/PsMCjAKBAQLAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGL7+DCDF/gwKMAoEBAsCAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yu4ANIMaADQowCgQECwIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxitgw0guIMNCjAKBAQLAgMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMGFDSDOhQ0KMAoEBAsCAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yg4cNII6HDQowCgQECwIEEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjGiA0gz4gNCjAKBAQLAgQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNSKDSDdig0KMAoEBAsCBRIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yp4wNILGMDQowCgQECwIFEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi2jg0gwI4NCjAKBAQLAgYSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGI2QDSCbkA0KMAoEBAsCBhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YrJINILqSDQowCgQEDAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiZtg0gpbYNCjAKBAQMAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJe5DSCjuQ0KMAoEBAwCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YwrsNIMq7DQowCgQEDAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxifvg0grb4NCjAKBAQMAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGN6/DSDuvw0KMAoEBAwCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y9cENIIXCDQowCgQEDQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxip6A0gtegNCjAKBAQNAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMvqDSDX6g0KMAoEBA0CABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y7ewNIPXsDQowCgQEDQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxif7w0gre8NCjAKBAQNAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPfwDSD+8A0KMAoEBA0CARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YyPMNIM/zDQowCgQEDQICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjJ9Q0g1PUNCjAKBAQNAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMP4DSDO+A0KMAoEBA0CAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y3/oNIOz6DQowCgQEDQICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxil/A0gsPwNCjAKBAQOAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJOeDiCfng4KMAoEBA4CABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YmaEOIKWhDgowCgQEDgIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjIow4g0KMOCjAKBAQOAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGK2mDiC7pg4KMAoEBA8CABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YjMkOIJvJDgowCgQEDwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjAzA4gz8wOCjAKBAQPAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGI7PDiCZzw4KMAoEBA8CABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yh9IOIJjSDgowCgQEEAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxig9A4grPQOCjAKBAQQAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKz3DiC49w4KMAoEBBACABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y3vkOIOb5DgowCgQEEAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjJ/A4g1/wOCjAKBAQRAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLilDyC/pQ8KMAoEBBECABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YhagPIIyoDwowCgQEEQIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiEqg8gj6oPCjAKBAQRAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPqsDyCFrQ8KMAoEBBECARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Ykq8PIJ+vDwowCgQEEQIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjWsA8g4bAPCjAKBAQRAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJuyDyCksg8KMAoEBBECAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YrbQPILa0DwowCgQEEQIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiCtg8gjLYPCjAKBAQRAgMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJW4DyCfuA8KMAoEBBECBBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y7rkPIPy5DwowCgQEEQIEEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiRvA8gn7wPCjAKBAQSAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKjfDyCw3w8KMAoEBBICABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YyeEPINHhDwowCgQEEgIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjT4w8g3uMPCjAKBAQSAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNnmDyDk5g8KMAoEBBICARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YgekPII7pDwowCgQEEgIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjN6g8g2OoPCjAKBAQTAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIeQECCTkBAKMAoEBBMCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yv5IQIMuSEAowCgQEEwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxj3lBAg/5QQCjAKBAQTAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGL+XECDNlxAKMAoEBBMCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Ys5kQIL6ZEAowCgQEEwIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjDnBAgzpwQCjAKBAQTAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPWeECCCnxAKMAoEBBMCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YxqAQINGgEAowCgQEFAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiyxBAgxMQQCjAKBAQUAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGObHECD4xxAKMAoEBBQCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YssoQIMDKEAowCgQEFAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi5zRAgzc0QCjAKBAQVAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGM3rECDa6xAKMAoEBBUCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y4e0QIO7tEAoyCgYEFgMAAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPSxESD7sREKMgoGBBYDAAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiStBEgmbQRCjIKBgQWAwACARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y8LURIP61EQoyCgYEFgMAAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJW4ESCjuBEKMgoGBBYDAAICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxj6uREgiLoRCjIKBgQWAwACAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yn7wRIK28EQowCgQEFgIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiwvhEgvr4RCjAKBAQWAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPHBESD/wREKMAoEBBYCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YycQRINPEEQowCgQEFgIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi/xxEgz8cRCjAKBAQXAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGO7uESD57hEKMAoEBBcCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YkfERIJzxEQowCgQEFwIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjv8hEg+/IRCjAKBAQXAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJT1ESCg9REKMAoEBBcCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YovcRIK33EQowCgQEFwICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxio+hEgs/oRCjAKBAQXAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGND8ESDd/BEKMAoEBBcCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YnP4RIKf+EQowCgQEFwIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjp/xEg8v8RCjAKBAQXAgMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIuCEiCUghIKMAoEBBgCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YwKcSIMynEgowCgQEGAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjkqhIg8KoSCjAKBAQYAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKWtEiCtrRIKMAoEBBgCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YnLASIKqwEgowCgQEGAIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjlsRIg9bESCjAKBAQYAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJC0EiCgtBIKMAoEBBkCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YrbkSILG5EgowCgQEGQIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi4uRIgvbkSCjAKBAQZAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPfdEiD+3RIKMAoEBBkCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YleASIJzgEgowCgQEGQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxj04hIg/eISCjAKBAQZAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJXlEiCc5RIKMAoEBBkCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y3OYSIOTmEgowCgQEGQIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxj76BIgg+kSCjAKBAQZAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNvrEiDl6xIKMAoEBBkCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y/e0SIIXuEgowCgQEGgIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjDpRMgyqUTCjAKBAQaAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMOnEyDKpxMKMAoEBBoCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YvqkTIMupEwowCgQEGgIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxilrBMgsqwTCjAKBAQaAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGK+uEyC+rhMKMAoEBBoCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y768TIPyvEwowCgQEGgICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjgsRMg7bETCjAKBAQaAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMe0EyDUtBMKMAoEBBoCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y0bYTIOC2EwowCgQEGgICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiRuBMgnrgTCjAKBAQaAgMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNa5EyDkuRMKMAoEBBoCAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y3bsTIOu7EwowCgQEGgIEEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjpvRMg/L0TCjAKBAQaAgQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMLAEyDVwBMKMAoEBBoCBRIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YmcITIKXCEwowCgQEGgIFEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiexBMgqsQTCjAKBAQaAgYSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPHFEyD+xRMKMAoEBBoCBhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y98cTIITIEwowCgQEGgIHEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjHyRMg0ckTCjAKBAQaAgcSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMrLEyDUyxMKMAoEBBoCCBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Ymc0TIKTNEwowCgQEGgIIEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiezxMgqc8TCjAKBAQaAgkSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPDQEyD80BMKMAoEBBoCCRIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y9tITIILTEwowCgQEGgIKEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjM1BMg2tQTCjAKBAQaAgoSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNTWEyDi1hMKMAoEBBsCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YgokUIImJFAowCgQEGwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiUixQgm4sUCjAKBAQbAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOqMFCD2jBQKMAoEBBsCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YgY8UII2PFAowCgQEGwICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjdkBQg6pAUCjAKBAQbAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPWSFCCCkxQKMAoEBBsCAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YzpQUINiUFAowCgQEGwIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjjlhQg7ZYUCjAKBAQbAgQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMCYFCDQmBQKMAoEBBsCBBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y25oUIOuaFAowCgQEGwIFEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi4nBQgw5wUCjAKBAQbAgUSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGM6eFCDZnhQKMAoEBBsCBhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yp6AUILOgFAowCgQEGwIGEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi+ohQgyqIUCjAKBAQbAgcSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJukFCCppBQKMAoEBBsCBxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YtKYUIMKmFAowCgQEGwIIEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjAqBQgzagUCjAKBAQbAggSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLurFCDIqxQKMAoEBBsCCBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y2K0UIOetFAowCgQEGwIIEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxihrxQgrq8UCjAKBAQcAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGL/RFCDG0RQKMAoEBBwCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y2dMUIODTFAowCgQEHAIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjS1RQg3dUUCjAKBAQcAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLnYFCDE2BQKMAoEBBwCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y29oUIOjaFAowCgQEHAIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxik3BQgr9wUCjAKBAQeAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPWmFSCBpxUKMAoEBB4CABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YiKkVIJSpFQowCgQEHgIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjiqhUg76oVCjAKBAQeAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPasFSCDrRUKMAoEBB4CAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yza4VINeuFQowCgQEHgICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjesBUg6LAVCjAKBAQeAgMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLmyFSDJshUKMAoEBB4CAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y0LQVIOC0FQowCgQEHgIEEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxirthUgtrYVCjAKBAQeAgQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGL24FSDIuBUKMAoEBB4CBRIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YlLoVIKC6FQowCgQEHgIFEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxinvBUgs7wVCjAKBAQeAgYSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIK+FSCQvhUKMAoEBB4CBhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yl8AVIKXAFQowCgQEHgIHEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxihwhUgrsIVCjAKBAQeAgcSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJjFFSClxRUKMAoEBB4CBxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YsccVIMDHFQowCgQEHgIHEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxj4yBUghckVCjAKBAQfAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIfpFSCS6RUKMAoEBB8CABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y6usVIPXrFQowCgQEHwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiI7hUgle4VCjAKBAQfAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGM/vFSDa7xUKMAoEBCICABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YrsYWILjGFgowCgQEIgIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjOyBYg2MgWCjAKBAQiAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKnKFiC1yhYKMAoEBCICARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yy8wWINfMFgowCgQEIwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiu7xYgte8WCjAKBAQjAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMTxFiDL8RYKMAoEBCMCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yo/MWIKrzFgowCgQEIwIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxj7+hYggvsWCjAKBAQjAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNH8FiDc/BYKMAoEBCMCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y6/4WIPb+FgowCgQEJAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjdnRcg6Z0XCjAKBAQkAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPqfFyCGoBcKMAoEBCUCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y98QXIIDFFwowCgQEJQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiRxxcgmscXCjAKBAQlAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGI7JFyCayRcKMAoEBCUCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yl8wXIKPMFwowCgQEJQIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi4zhcgxs4XCjAKBAQlAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGILQFyCO0BcKMAoEBCUCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y0tEXIODRFwowCgQEJQICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjx0xcg/9MXCjAKBAQmAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLj4FyC/+BcKMAoEBCYCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YyvoXINH6FwowCgQEJgIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjF/BcgzPwXCjAKBAQmAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJ7/FyCl/xcKMAoEBCYCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YnoEYIKmBGAowCgQEJgICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiWhBggoYQYCjAKBAQmAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLCGGCC9hhgKMAoEBCYCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y9YcYIICIGAowCgQEJwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjbrhgg564YCjAKBAQnAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOSxGCDwsRgKMAoEBCcCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YhbQYIJO0GAowCgQEJwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjPtRgg27UYCjAKBAQnAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMu3GCDYtxgKMAoEBCcCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yy7oYINi6GAowCgQEJwIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjtvBgg/LwYCjAKBAQnAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLm+GCDGvhgKMAoEBCcCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YisAYIJnAGAowCgQEJwICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi2whggxcIYCjAKBAQoAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJjhGCCf4RgKMAoEBCgCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YsOMYILfjGAowCgQEKQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxipghkgsIIZCjAKBAQpAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMWEGSDMhBkKMAoEBCoCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YrrQZILe0GQowCgQEKgIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjGthkgz7YZCjAKBAQqAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJ64GSCpuBkKMAoEBCoCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yt7oZIMK6GQowCgQEKgICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiQvBkgnLwZCjAKBAQqAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKu+GSC3vhkKMAoEBCoCAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YrcAZILTAGQowCgQEKgIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiKwxkgkcMZCjAKBAQqAgQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIzFGSCXxRkKMAoEBCoCBBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YiMgZIJPIGQowCgQEKgIEEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bximyhkgs8oZCjAKBAQqAgQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGO3LGSD4yxkKMAoEBCoCBRIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Ytc0ZIL7NGQowCgQEKgIFEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjNzxkg1s8ZCjAKBAQqAgYSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKXRGSCv0RkKMAoEBCoCBhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YvtMZIMjTGQowCgQEKgIHEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxia1RkgqNUZCjAKBAQqAgcSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMPXGSDR1xkKMAoEBCsCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YvPwZIM38GQowCgQEKwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjY/xkg6f8ZCjAKBAQrAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJeCGiCkghoKMAoEBCsCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YiIUaIJuFGgowCgQEKwIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjWhhog5oYaCjAKBAQrAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPeIGiCHiRoKMAoEBCwCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yv64aIMiuGgowCgQELAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjlsBog7rAaCjAKBAQsAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGImzGiCYsxoKMAoEBCwCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y1rYaIOW2GgowCgQELAIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxizuRogvrkaCjAKBAQsAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLu8GiDMvBoKMAoEBC0CABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y4N8aIPHfGgowCgQELQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiK4xogm+MaCjAKBAQtAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNDlGiDd5RoKMAoEBC0CABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yz+gaIOLoGgowCgQELgIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjXkRsg4JEbCjAKBAQuAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPeTGyCAlBsKMAoEBC4CARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y2JUbIOSVGwowCgQELgIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiEmBsgkJgbCjAKBAQuAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLCaGyC4mhsKMAoEBC4CARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y7JwbIPqcGwowCgQELgICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjTnhsg2p4bCjAKBAQuAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLihGyC/oRsKMAoEBC4CAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YvqMbIMmjGwowCgQELgIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjCphsgzaYbCjAKBAQuAgMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOioGyD1qBsKMAoEBC4CAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Ys6obIL6qGwowCgQELwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxitzRsgvs0bCjAKBAQvAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNHQGyDi0BsKMAoEBC8CABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YlNMbIKHTGwowCgQELwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiN1hsgoNYbCjAKBAQwAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNOBHCDcgRwKMAoEBDACABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y+YMcIIKEHAowCgQEMAIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxidhhwgrIYcCjAKBAQwAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOqJHCD5iRwKMAoEBDACARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yx4wcINKMHAowCgQEMAIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjPjxwg4I8cCjAKBAQwAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMiRHCDVkRwKMAoEBDACAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y1JQcIOGUHAowCgQEMAICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiClxwgkZccCjAKBAQwAgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNSYHCDhmBwKMAoEBDACAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yq5ocILqaHAowCgQEMAIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjjnBwg8pwcCjAKBAQxAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKXAHCC2wBwKMAoEBDECABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yz8McIODDHAowCgQEMQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiVxhwgosYcCjAKBAQxAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJTJHCCnyRwKMAoEBDICABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yw+4cIMzuHAowCgQEMgIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjp8Bwg8vAcCjAKBAQyAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGI3zHCCc8xwKMAoEBDICARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y2vYcIOn2HAowCgQEMgIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi3+RwgwvkcCjAKBAQyAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGL/8HCDQ/BwKMAoEBDMCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y5J8dIPWfHQowCgQEMwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiOox0gn6MdCjAKBAQzAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNSlHSDhpR0KMAoEBDMCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y06gdIOaoHQowCgQENAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiszh0gtc4dCjAKBAQ0AgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNbQHSDf0B0KMAoEBDQCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YgNMdII/THQowCgQENAIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjX1h0g5tYdCjAKBAQ0AgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLrZHSDF2R0KMAoEBDQCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YyNwdINncHQowCgQENQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiPgB4goIAeCjAKBAQ1AgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGL2DHiDOgx4KMAoEBDUCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YhYYeIJKGHgowCgQENQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiIiR4gm4keCjAKBAQ2AgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNG0HiDatB4KMAoEBDYCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y7bYeIPa2HgowCgQENgIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjuuB4g9bgeCjAKBAQ2AgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGM+7HiDWux4KMAoEBDYCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y070eIN69HgowCgQENgICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjTwB4g3sAeCjAKBAQ2AgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPXCHiCCwx4KMAoEBDYCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YvsQeIMnEHgowCgQENgIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiIxh4gkcYeCjAKBAQ2AgMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKTIHiCtyB4KMAoEBDYCBBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y/skeIIjKHgowCgQENgIEEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxibzB4gpcweCjAKBAQ2AgUSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPnNHiCHzh4KMAoEBDYCBRIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YptAeILTQHgowCgQENwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjI8R4g1PEeCjAKBAQ3AgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGOfzHiDz8x4KMAoEBDcCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YyPUeINf1HgowCgQENwIBEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxj29x4ghfgeCjAKBAQ4AgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJWXHyCjlx8KMAoEBDgCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YuJkfIMaZHwowCgQEOQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjcuB8g6LgfCjAKBAQ5AgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGP+6HyCLux8KMAoEBDoCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yid8fIJXfHwowCgQEOgIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiu4R8guuEfCjAKBAQ6AgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGJTjHyCk4x8KMAoEBDoCARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YveUfIM3lHwowCgQEOgICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxim5x8gtOcfCjAKBAQ6AgISIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGM3pHyDb6R8KMAoEBDwCABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y8aMgIP2jIAowCgQEPAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiOpiAgmqYgCjIKBgQ/AwAEABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yr6whIL6sIQo0CggEPwMABAACABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YxawhIOGsIQo0CggEPwMABAACARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y6KwhIPOsIQo0CggEPwMABAACAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y+qwhIIOtIQo0CggEPwMABAACAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yiq0hIJGtIQoyCgYEPwMAAgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGKuuISCyriEKMgoGBD8DAAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxj7sCEggrEhCjIKBgQ/AwACARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y8bIhIP+yIQoyCgYEPwMAAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGMi1ISDWtSEKMgoGBD8DAAICEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxisuCEgvrghCjIKBgQ/AwACAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YuLwhIMq8IQoyCgYEPwMAAgMSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLS+ISC/viEKMgoGBD8DAAIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiIwSEgk8EhCjIKBgQ/AwACBBIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Yg8MhIJHDIQoyCgYEPwMAAgQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNrFISDoxSEKMAoEBD8CABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YqcghIMLIIQowCgQEPwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjezCEg98whCjAKBAQ/AgASIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGILQISCX0CEKMAoEBD8CABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YutMhINXTIQouCgIFABIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YzdQhINzUIQowCgQFAAIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjj1CEg/9QhCjAKBAUAAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGIbVISCd1SEKMAoEBQACAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YpNUhILzVIQouCgIFARIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y+tUhIIrWIQowCgQFAQIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxiR1iEgrtYhCjAKBAUBAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGLXWISC71iEKMAoEBQECAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YwtYhIMvWIQowCgQFAQIDEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjS1iEg19YhCjAKBAUBAgQSIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGN7WISDm1iEKMAoEBQECBRIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y7dYhIPLWIQouCgIFAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YsNchILjXIQowCgQFAgIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxi/1yEg1NchCjAKBAUCAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGNvXISDq1yEKMAoEBQICAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8Y8dchIP/XIQouCgIFAxIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YvdghIMrYIQowCgQFAwIAEiBpbnRlcmZhY2UvdGkvdXNlcnMvdjEvdXNlci5wcm90bxjR2CEg69ghCjAKBAUDAgESIGludGVyZmFjZS90aS91c2Vycy92MS91c2VyLnByb3RvGPLYISCG2SEKMAoEBQMCAhIgaW50ZXJmYWNlL3RpL3VzZXJzL3YxL3VzZXIucHJvdG8YjdkhIKDZIQ==