import * as grpcWeb from 'grpc-web';

import * as interface_ti_users_v1_refresh_token_pb from '../../../../interface/ti/users/v1/refresh_token_pb'; // proto import: "interface/ti/users/v1/refresh_token.proto"


export class RefreshTokensServiceClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  createRefreshToken(
    request: interface_ti_users_v1_refresh_token_pb.CreateRefreshTokenRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_refresh_token_pb.RefreshToken) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_refresh_token_pb.RefreshToken>;

  getRefreshToken(
    request: interface_ti_users_v1_refresh_token_pb.GetRefreshTokenRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_refresh_token_pb.RefreshToken) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_refresh_token_pb.RefreshToken>;

  updateRefreshToken(
    request: interface_ti_users_v1_refresh_token_pb.UpdateRefreshTokenRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_refresh_token_pb.RefreshToken) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_refresh_token_pb.RefreshToken>;

  listRefreshTokens(
    request: interface_ti_users_v1_refresh_token_pb.ListRefreshTokensRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_refresh_token_pb.ListRefreshTokensResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_refresh_token_pb.ListRefreshTokensResponse>;

  deleteRefreshToken(
    request: interface_ti_users_v1_refresh_token_pb.DeleteRefreshTokenRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_refresh_token_pb.RefreshToken) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_refresh_token_pb.RefreshToken>;

  batchGetRefreshTokens(
    request: interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensResponse>;

  batchDeleteRefreshTokens(
    request: interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensResponse>;

  streamRefreshTokens(
    request: interface_ti_users_v1_refresh_token_pb.StreamRefreshTokensRequest,
    metadata?: grpcWeb.Metadata
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_refresh_token_pb.RefreshToken>;

}

export class RefreshTokensServicePromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  createRefreshToken(
    request: interface_ti_users_v1_refresh_token_pb.CreateRefreshTokenRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_refresh_token_pb.RefreshToken>;

  getRefreshToken(
    request: interface_ti_users_v1_refresh_token_pb.GetRefreshTokenRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_refresh_token_pb.RefreshToken>;

  updateRefreshToken(
    request: interface_ti_users_v1_refresh_token_pb.UpdateRefreshTokenRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_refresh_token_pb.RefreshToken>;

  listRefreshTokens(
    request: interface_ti_users_v1_refresh_token_pb.ListRefreshTokensRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_refresh_token_pb.ListRefreshTokensResponse>;

  deleteRefreshToken(
    request: interface_ti_users_v1_refresh_token_pb.DeleteRefreshTokenRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_refresh_token_pb.RefreshToken>;

  batchGetRefreshTokens(
    request: interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_refresh_token_pb.BatchGetRefreshTokensResponse>;

  batchDeleteRefreshTokens(
    request: interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_refresh_token_pb.BatchDeleteRefreshTokensResponse>;

  streamRefreshTokens(
    request: interface_ti_users_v1_refresh_token_pb.StreamRefreshTokensRequest,
    metadata?: grpcWeb.Metadata
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_refresh_token_pb.RefreshToken>;

}
