import * as grpcWeb from 'grpc-web';

import * as interface_ti_users_v1_auth_code_pb from '../../../../interface/ti/users/v1/auth_code_pb'; // proto import: "interface/ti/users/v1/auth_code.proto"


export class AuthCodesServiceClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  createAuthCode(
    request: interface_ti_users_v1_auth_code_pb.CreateAuthCodeRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_code_pb.AuthCode) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_code_pb.AuthCode>;

  getAuthCode(
    request: interface_ti_users_v1_auth_code_pb.GetAuthCodeRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_code_pb.AuthCode) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_code_pb.AuthCode>;

  updateAuthCode(
    request: interface_ti_users_v1_auth_code_pb.UpdateAuthCodeRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_code_pb.AuthCode) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_code_pb.AuthCode>;

  listAuthCodes(
    request: interface_ti_users_v1_auth_code_pb.ListAuthCodesRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_code_pb.ListAuthCodesResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_code_pb.ListAuthCodesResponse>;

  deleteAuthCode(
    request: interface_ti_users_v1_auth_code_pb.DeleteAuthCodeRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_code_pb.AuthCode) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_code_pb.AuthCode>;

  batchGetAuthCodes(
    request: interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesResponse>;

  batchDeleteAuthCodes(
    request: interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesResponse>;

  streamAuthCodes(
    request: interface_ti_users_v1_auth_code_pb.StreamAuthCodesRequest,
    metadata?: grpcWeb.Metadata
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_code_pb.AuthCode>;

}

export class AuthCodesServicePromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  createAuthCode(
    request: interface_ti_users_v1_auth_code_pb.CreateAuthCodeRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_code_pb.AuthCode>;

  getAuthCode(
    request: interface_ti_users_v1_auth_code_pb.GetAuthCodeRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_code_pb.AuthCode>;

  updateAuthCode(
    request: interface_ti_users_v1_auth_code_pb.UpdateAuthCodeRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_code_pb.AuthCode>;

  listAuthCodes(
    request: interface_ti_users_v1_auth_code_pb.ListAuthCodesRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_code_pb.ListAuthCodesResponse>;

  deleteAuthCode(
    request: interface_ti_users_v1_auth_code_pb.DeleteAuthCodeRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_code_pb.AuthCode>;

  batchGetAuthCodes(
    request: interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_code_pb.BatchGetAuthCodesResponse>;

  batchDeleteAuthCodes(
    request: interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_users_v1_auth_code_pb.BatchDeleteAuthCodesResponse>;

  streamAuthCodes(
    request: interface_ti_users_v1_auth_code_pb.StreamAuthCodesRequest,
    metadata?: grpcWeb.Metadata
  ): grpcWeb.ClientReadableStream<interface_ti_users_v1_auth_code_pb.AuthCode>;

}
