import * as grpcWeb from 'grpc-web';

import * as interface_ti_profiles_v1_mirror_pb from '../../../../interface/ti/profiles/v1/mirror_pb'; // proto import: "interface/ti/profiles/v1/mirror.proto"


export class MirrorServiceClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  getHederaAccount(
    request: interface_ti_profiles_v1_mirror_pb.GetHederaAccountRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_profiles_v1_mirror_pb.HederaAccount) => void
  ): grpcWeb.ClientReadableStream<interface_ti_profiles_v1_mirror_pb.HederaAccount>;

  listTokenHoldings(
    request: interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsResponse>;

  getToken(
    request: interface_ti_profiles_v1_mirror_pb.GetTokenRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_profiles_v1_mirror_pb.Token) => void
  ): grpcWeb.ClientReadableStream<interface_ti_profiles_v1_mirror_pb.Token>;

  listCredentials(
    request: interface_ti_profiles_v1_mirror_pb.ListCredentialsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_profiles_v1_mirror_pb.ListCredentialsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_profiles_v1_mirror_pb.ListCredentialsResponse>;

  listPositions(
    request: interface_ti_profiles_v1_mirror_pb.ListPositionsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_profiles_v1_mirror_pb.ListPositionsResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_profiles_v1_mirror_pb.ListPositionsResponse>;

  searchProfiles(
    request: interface_ti_profiles_v1_mirror_pb.SearchProfilesRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: interface_ti_profiles_v1_mirror_pb.SearchProfilesResponse) => void
  ): grpcWeb.ClientReadableStream<interface_ti_profiles_v1_mirror_pb.SearchProfilesResponse>;

}

export class MirrorServicePromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  getHederaAccount(
    request: interface_ti_profiles_v1_mirror_pb.GetHederaAccountRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_profiles_v1_mirror_pb.HederaAccount>;

  listTokenHoldings(
    request: interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsResponse>;

  getToken(
    request: interface_ti_profiles_v1_mirror_pb.GetTokenRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_profiles_v1_mirror_pb.Token>;

  listCredentials(
    request: interface_ti_profiles_v1_mirror_pb.ListCredentialsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_profiles_v1_mirror_pb.ListCredentialsResponse>;

  listPositions(
    request: interface_ti_profiles_v1_mirror_pb.ListPositionsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_profiles_v1_mirror_pb.ListPositionsResponse>;

  searchProfiles(
    request: interface_ti_profiles_v1_mirror_pb.SearchProfilesRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<interface_ti_profiles_v1_mirror_pb.SearchProfilesResponse>;

}
