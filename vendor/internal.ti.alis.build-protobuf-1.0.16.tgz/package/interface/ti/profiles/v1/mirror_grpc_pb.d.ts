// GENERATED CODE -- DO NOT EDIT!

// package: interface.ti.profiles.v1
// file: interface/ti/profiles/v1/mirror.proto

import * as interface_ti_profiles_v1_mirror_pb from "../../../../interface/ti/profiles/v1/mirror_pb";
import * as grpc from "@grpc/grpc-js";

interface IMirrorServiceService extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
  getHederaAccount: grpc.MethodDefinition<interface_ti_profiles_v1_mirror_pb.GetHederaAccountRequest, interface_ti_profiles_v1_mirror_pb.HederaAccount>;
  listTokenHoldings: grpc.MethodDefinition<interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsRequest, interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsResponse>;
  getToken: grpc.MethodDefinition<interface_ti_profiles_v1_mirror_pb.GetTokenRequest, interface_ti_profiles_v1_mirror_pb.Token>;
  listCredentials: grpc.MethodDefinition<interface_ti_profiles_v1_mirror_pb.ListCredentialsRequest, interface_ti_profiles_v1_mirror_pb.ListCredentialsResponse>;
  listPositions: grpc.MethodDefinition<interface_ti_profiles_v1_mirror_pb.ListPositionsRequest, interface_ti_profiles_v1_mirror_pb.ListPositionsResponse>;
  searchProfiles: grpc.MethodDefinition<interface_ti_profiles_v1_mirror_pb.SearchProfilesRequest, interface_ti_profiles_v1_mirror_pb.SearchProfilesResponse>;
}

export const MirrorServiceService: IMirrorServiceService;

export interface IMirrorServiceServer extends grpc.UntypedServiceImplementation {
  getHederaAccount: grpc.handleUnaryCall<interface_ti_profiles_v1_mirror_pb.GetHederaAccountRequest, interface_ti_profiles_v1_mirror_pb.HederaAccount>;
  listTokenHoldings: grpc.handleUnaryCall<interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsRequest, interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsResponse>;
  getToken: grpc.handleUnaryCall<interface_ti_profiles_v1_mirror_pb.GetTokenRequest, interface_ti_profiles_v1_mirror_pb.Token>;
  listCredentials: grpc.handleUnaryCall<interface_ti_profiles_v1_mirror_pb.ListCredentialsRequest, interface_ti_profiles_v1_mirror_pb.ListCredentialsResponse>;
  listPositions: grpc.handleUnaryCall<interface_ti_profiles_v1_mirror_pb.ListPositionsRequest, interface_ti_profiles_v1_mirror_pb.ListPositionsResponse>;
  searchProfiles: grpc.handleUnaryCall<interface_ti_profiles_v1_mirror_pb.SearchProfilesRequest, interface_ti_profiles_v1_mirror_pb.SearchProfilesResponse>;
}

export class MirrorServiceClient extends grpc.Client {
  constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
  getHederaAccount(argument: interface_ti_profiles_v1_mirror_pb.GetHederaAccountRequest, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.HederaAccount>): grpc.ClientUnaryCall;
  getHederaAccount(argument: interface_ti_profiles_v1_mirror_pb.GetHederaAccountRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.HederaAccount>): grpc.ClientUnaryCall;
  getHederaAccount(argument: interface_ti_profiles_v1_mirror_pb.GetHederaAccountRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.HederaAccount>): grpc.ClientUnaryCall;
  listTokenHoldings(argument: interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsRequest, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsResponse>): grpc.ClientUnaryCall;
  listTokenHoldings(argument: interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsResponse>): grpc.ClientUnaryCall;
  listTokenHoldings(argument: interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsResponse>): grpc.ClientUnaryCall;
  getToken(argument: interface_ti_profiles_v1_mirror_pb.GetTokenRequest, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.Token>): grpc.ClientUnaryCall;
  getToken(argument: interface_ti_profiles_v1_mirror_pb.GetTokenRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.Token>): grpc.ClientUnaryCall;
  getToken(argument: interface_ti_profiles_v1_mirror_pb.GetTokenRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.Token>): grpc.ClientUnaryCall;
  listCredentials(argument: interface_ti_profiles_v1_mirror_pb.ListCredentialsRequest, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.ListCredentialsResponse>): grpc.ClientUnaryCall;
  listCredentials(argument: interface_ti_profiles_v1_mirror_pb.ListCredentialsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.ListCredentialsResponse>): grpc.ClientUnaryCall;
  listCredentials(argument: interface_ti_profiles_v1_mirror_pb.ListCredentialsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.ListCredentialsResponse>): grpc.ClientUnaryCall;
  listPositions(argument: interface_ti_profiles_v1_mirror_pb.ListPositionsRequest, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.ListPositionsResponse>): grpc.ClientUnaryCall;
  listPositions(argument: interface_ti_profiles_v1_mirror_pb.ListPositionsRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.ListPositionsResponse>): grpc.ClientUnaryCall;
  listPositions(argument: interface_ti_profiles_v1_mirror_pb.ListPositionsRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.ListPositionsResponse>): grpc.ClientUnaryCall;
  searchProfiles(argument: interface_ti_profiles_v1_mirror_pb.SearchProfilesRequest, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.SearchProfilesResponse>): grpc.ClientUnaryCall;
  searchProfiles(argument: interface_ti_profiles_v1_mirror_pb.SearchProfilesRequest, metadataOrOptions: grpc.Metadata | grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.SearchProfilesResponse>): grpc.ClientUnaryCall;
  searchProfiles(argument: interface_ti_profiles_v1_mirror_pb.SearchProfilesRequest, metadata: grpc.Metadata | null, options: grpc.CallOptions | null, callback: grpc.requestCallback<interface_ti_profiles_v1_mirror_pb.SearchProfilesResponse>): grpc.ClientUnaryCall;
}