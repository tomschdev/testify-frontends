// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('@grpc/grpc-js');
var interface_ti_profiles_v1_mirror_pb = require('../../../../interface/ti/profiles/v1/mirror_pb.js');
var interface_ti_positions_v1_positions_pb = require('../../../../interface/ti/positions/v1/positions_pb.js');

function serialize_interface_ti_profiles_v1_GetHederaAccountRequest(arg) {
  if (!(arg instanceof interface_ti_profiles_v1_mirror_pb.GetHederaAccountRequest)) {
    throw new Error('Expected argument of type interface.ti.profiles.v1.GetHederaAccountRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_profiles_v1_GetHederaAccountRequest(buffer_arg) {
  return interface_ti_profiles_v1_mirror_pb.GetHederaAccountRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_profiles_v1_GetTokenRequest(arg) {
  if (!(arg instanceof interface_ti_profiles_v1_mirror_pb.GetTokenRequest)) {
    throw new Error('Expected argument of type interface.ti.profiles.v1.GetTokenRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_profiles_v1_GetTokenRequest(buffer_arg) {
  return interface_ti_profiles_v1_mirror_pb.GetTokenRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_profiles_v1_HederaAccount(arg) {
  if (!(arg instanceof interface_ti_profiles_v1_mirror_pb.HederaAccount)) {
    throw new Error('Expected argument of type interface.ti.profiles.v1.HederaAccount');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_profiles_v1_HederaAccount(buffer_arg) {
  return interface_ti_profiles_v1_mirror_pb.HederaAccount.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_profiles_v1_ListPositionsRequest(arg) {
  if (!(arg instanceof interface_ti_profiles_v1_mirror_pb.ListPositionsRequest)) {
    throw new Error('Expected argument of type interface.ti.profiles.v1.ListPositionsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_profiles_v1_ListPositionsRequest(buffer_arg) {
  return interface_ti_profiles_v1_mirror_pb.ListPositionsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_profiles_v1_ListPositionsResponse(arg) {
  if (!(arg instanceof interface_ti_profiles_v1_mirror_pb.ListPositionsResponse)) {
    throw new Error('Expected argument of type interface.ti.profiles.v1.ListPositionsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_profiles_v1_ListPositionsResponse(buffer_arg) {
  return interface_ti_profiles_v1_mirror_pb.ListPositionsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_profiles_v1_ListTokenHoldingsRequest(arg) {
  if (!(arg instanceof interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsRequest)) {
    throw new Error('Expected argument of type interface.ti.profiles.v1.ListTokenHoldingsRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_profiles_v1_ListTokenHoldingsRequest(buffer_arg) {
  return interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_profiles_v1_ListTokenHoldingsResponse(arg) {
  if (!(arg instanceof interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsResponse)) {
    throw new Error('Expected argument of type interface.ti.profiles.v1.ListTokenHoldingsResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_profiles_v1_ListTokenHoldingsResponse(buffer_arg) {
  return interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_profiles_v1_SearchProfilesRequest(arg) {
  if (!(arg instanceof interface_ti_profiles_v1_mirror_pb.SearchProfilesRequest)) {
    throw new Error('Expected argument of type interface.ti.profiles.v1.SearchProfilesRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_profiles_v1_SearchProfilesRequest(buffer_arg) {
  return interface_ti_profiles_v1_mirror_pb.SearchProfilesRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_profiles_v1_SearchProfilesResponse(arg) {
  if (!(arg instanceof interface_ti_profiles_v1_mirror_pb.SearchProfilesResponse)) {
    throw new Error('Expected argument of type interface.ti.profiles.v1.SearchProfilesResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_profiles_v1_SearchProfilesResponse(buffer_arg) {
  return interface_ti_profiles_v1_mirror_pb.SearchProfilesResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_interface_ti_profiles_v1_Token(arg) {
  if (!(arg instanceof interface_ti_profiles_v1_mirror_pb.Token)) {
    throw new Error('Expected argument of type interface.ti.profiles.v1.Token');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_interface_ti_profiles_v1_Token(buffer_arg) {
  return interface_ti_profiles_v1_mirror_pb.Token.deserializeBinary(new Uint8Array(buffer_arg));
}


// MirrorService resolves on-chain profiles live from the public Hedera mirror
// node and answers eligibility-style queries over them — the read/match
// counterpart to the hedera write side.
//
// Tier 1 (GetHederaAccount, ListTokenHoldings, GetToken) are raw mirror-node
// reads: no operator credentials, no platform state. Tier 2 (ListPositions,
// SearchProfiles) compose the raw reads with the positions and users neurons
// to answer the discover → match questions of the issue → post → discover →
// match loop.
var MirrorServiceService = exports.MirrorServiceService = {
  // Resolves a Hedera account from the mirror node.
//
// Returns NOT_FOUND for a well-formed account id that does not exist on the
// network, and INVALID_ARGUMENT for a malformed id.
getHederaAccount: {
    path: '/interface.ti.profiles.v1.MirrorService/GetHederaAccount',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_profiles_v1_mirror_pb.GetHederaAccountRequest,
    responseType: interface_ti_profiles_v1_mirror_pb.HederaAccount,
    requestSerialize: serialize_interface_ti_profiles_v1_GetHederaAccountRequest,
    requestDeserialize: deserialize_interface_ti_profiles_v1_GetHederaAccountRequest,
    responseSerialize: serialize_interface_ti_profiles_v1_HederaAccount,
    responseDeserialize: deserialize_interface_ti_profiles_v1_HederaAccount,
  },
  // Lists the token holdings of a Hedera account from the mirror node.
//
// An account holding no tokens yields an empty list, not an error.
listTokenHoldings: {
    path: '/interface.ti.profiles.v1.MirrorService/ListTokenHoldings',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsRequest,
    responseType: interface_ti_profiles_v1_mirror_pb.ListTokenHoldingsResponse,
    requestSerialize: serialize_interface_ti_profiles_v1_ListTokenHoldingsRequest,
    requestDeserialize: deserialize_interface_ti_profiles_v1_ListTokenHoldingsRequest,
    responseSerialize: serialize_interface_ti_profiles_v1_ListTokenHoldingsResponse,
    responseDeserialize: deserialize_interface_ti_profiles_v1_ListTokenHoldingsResponse,
  },
  // Gets a token by its id from the mirror node.
getToken: {
    path: '/interface.ti.profiles.v1.MirrorService/GetToken',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_profiles_v1_mirror_pb.GetTokenRequest,
    responseType: interface_ti_profiles_v1_mirror_pb.Token,
    requestSerialize: serialize_interface_ti_profiles_v1_GetTokenRequest,
    requestDeserialize: deserialize_interface_ti_profiles_v1_GetTokenRequest,
    responseSerialize: serialize_interface_ti_profiles_v1_Token,
    responseDeserialize: deserialize_interface_ti_profiles_v1_Token,
  },
  // Lists all existing positions across organisations — the demand side of the
// market. Proxies the positions neuron's unscoped list.
listPositions: {
    path: '/interface.ti.profiles.v1.MirrorService/ListPositions',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_profiles_v1_mirror_pb.ListPositionsRequest,
    responseType: interface_ti_profiles_v1_mirror_pb.ListPositionsResponse,
    requestSerialize: serialize_interface_ti_profiles_v1_ListPositionsRequest,
    requestDeserialize: deserialize_interface_ti_profiles_v1_ListPositionsRequest,
    responseSerialize: serialize_interface_ti_profiles_v1_ListPositionsResponse,
    responseDeserialize: deserialize_interface_ti_profiles_v1_ListPositionsResponse,
  },
  // Returns per-profile eligibility for a position.
//
// A profile qualifies iff it holds BOTH an XP Credential AND a Reputation
// Credential issued by the position's organisation, resolved from the
// credential HCS topic. Eligibility is a boolean; further disclosure is the
// candidate's.
searchProfiles: {
    path: '/interface.ti.profiles.v1.MirrorService/SearchProfiles',
    requestStream: false,
    responseStream: false,
    requestType: interface_ti_profiles_v1_mirror_pb.SearchProfilesRequest,
    responseType: interface_ti_profiles_v1_mirror_pb.SearchProfilesResponse,
    requestSerialize: serialize_interface_ti_profiles_v1_SearchProfilesRequest,
    requestDeserialize: deserialize_interface_ti_profiles_v1_SearchProfilesRequest,
    responseSerialize: serialize_interface_ti_profiles_v1_SearchProfilesResponse,
    responseDeserialize: deserialize_interface_ti_profiles_v1_SearchProfilesResponse,
  },
};

exports.MirrorServiceClient = grpc.makeGenericClientConstructor(MirrorServiceService, 'MirrorService');